/* ============================================================
   IMSGC Portal — data layer.
   Everything that talks to the server lives here and nowhere else.
   The screens never touch the network directly; they call sb.from(...)
   or the api* helpers below. Keeping this separate means the interface
   can be rebuilt (in React or anything else) without touching any of it.
   ============================================================ */

/* All data goes through this site's own address. The _redirects file beside
   this page forwards /sb/* to the backend, so the backend is never named here. */
const DATA_URL = "/sb";
/* =====================================================
   SECURE API CLIENT
   The browser holds no database key. Every read and write goes
   through the server, which checks who you are and what you may
   touch before it goes anywhere near the database.
   Keeps the same .from(...).select().eq() shape the portal already
   uses, so existing screens work unchanged.
   ===================================================== */
const API_URL = DATA_URL + "/functions/v1/api";
const TOKEN_KEY = 'ims_token_v1';
const COOKIE_FLAG = 'ims_cookie_v1';
let API_TOKEN = null;
let USING_COOKIE = false;
try {
  API_TOKEN = localStorage.getItem(TOKEN_KEY);
  USING_COOKIE = localStorage.getItem(COOKIE_FLAG) === '1';
} catch(e){}

// When the server hands back a cookie, the session lives there and nothing
// sensitive is kept where page scripts could read it. The token is only kept
// as a fallback for the case where a cookie never arrives.
function setApiToken(t, viaCookie){
  USING_COOKIE = !!viaCookie;
  API_TOKEN = viaCookie ? null : (t || null);
  try {
    if(viaCookie){
      localStorage.setItem(COOKIE_FLAG, '1');
      localStorage.removeItem(TOKEN_KEY);
    } else {
      localStorage.removeItem(COOKIE_FLAG);
      t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY);
    }
  } catch(e){}
}
function haveSession(){ return USING_COOKIE || !!API_TOKEN; }

/* ---- traffic scrambling (on top of HTTPS) ----
   Each session gets its own key from the server. What travels between this
   page and the server is not readable in the browser's network panel. If
   anything about it fails we simply fall back to ordinary requests. */
let PAYLOAD_KEY = null;        // CryptoKey, memory only
const PK_FLAG = 'ims_pk_v1';
const _b64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)))
  .replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const _unb64u = (str) => Uint8Array.from(
  atob(String(str).replace(/-/g,'+').replace(/_/g,'/')), c => c.charCodeAt(0));

async function setPayloadKey(raw){
  PAYLOAD_KEY = null;
  if(!raw){ try{ sessionStorage.removeItem(PK_FLAG); }catch(e){} return; }
  try{
    PAYLOAD_KEY = await crypto.subtle.importKey('raw', _unb64u(raw),
      { name:'AES-GCM' }, false, ['encrypt','decrypt']);
    try{ sessionStorage.setItem(PK_FLAG, raw); }catch(e){}
  }catch(e){ PAYLOAD_KEY = null; }
}
async function restorePayloadKey(){
  if(PAYLOAD_KEY) return;
  let raw = null;
  try{ raw = sessionStorage.getItem(PK_FLAG); }catch(e){}
  if(raw) await setPayloadKey(raw);
}
async function sealPayload(obj){
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name:'AES-GCM', iv }, PAYLOAD_KEY,
    new TextEncoder().encode(JSON.stringify(obj)));
  const joined = new Uint8Array(iv.length + ct.byteLength);
  joined.set(iv); joined.set(new Uint8Array(ct), iv.length);
  return _b64u(joined);
}
async function openPayload(packed){
  const raw = _unb64u(packed);
  const pt = await crypto.subtle.decrypt({ name:'AES-GCM', iv: raw.slice(0,12) },
    PAYLOAD_KEY, raw.slice(12));
  return JSON.parse(new TextDecoder().decode(pt));
}
// Sign-in and the public application form run before any key exists.
const PLAIN_ACTIONS = ['login','apply','apply_upload_url'];

let sessionExpiredShown = false;
function onSessionExpired(){
  if(sessionExpiredShown) return;
  sessionExpiredShown = true;
  setApiToken(null, false);
  try{ clearSavedSession(); }catch(e){}
  alert('Your session has expired. Please sign in again.');
  location.reload();
}

async function apiCall(payload, opts){
  let res;
  let wire = payload;
  if(!PLAIN_ACTIONS.includes(payload.action)){
    await restorePayloadKey();
    if(PAYLOAD_KEY){
      try { wire = { e: await sealPayload(payload) }; } catch(e){ wire = payload; }
    }
  }
  try{
    res = await fetch(API_URL, {
      method:'POST',
      credentials: 'same-origin',
      headers: Object.assign(
        { 'Content-Type':'application/json', 'X-IMS-Client':'portal' },
        API_TOKEN ? { 'Authorization':'Bearer ' + API_TOKEN } : {}
      ),
      body: JSON.stringify(wire)
    });
  } catch(e){
    return { data:null, error:{ message:'Cannot reach the server. Check your internet connection.' } };
  }
  let body = {};
  try { body = await res.json(); } catch(e){}
  // The reply comes back scrambled whenever the request was.
  if(body && typeof body.e === 'string' && PAYLOAD_KEY){
    try { body = await openPayload(body.e); } catch(e){ body = {}; }
  }
  if(!res.ok){
    if(res.status === 401 && haveSession() && !(opts && opts.noExpiry)) onSessionExpired();
    // A refused read just means this role doesn't have that section. The menu
    // already hides it, so hand back an empty list rather than an error popup.
    if(res.status === 403 && body.mustChangePassword){
      onMustChangePassword();
      return { data:null, error:{ message: body.error }, mustChange:true };
    }
    if(res.status === 403 && payload.action === 'query' && (payload.op || 'select') === 'select'){
      return { data: [], error: null, denied: true };
    }
    return { data:null, error:{ message: body.error || ('Request failed (' + res.status + ')') } };
  }
  return { data: ('data' in body ? body.data : body), error:null };
}

/* ---- login / password, through the server ---- */
async function apiLogin(role, identifier, password){
  const r = await apiCall({ action:'login', role, identifier, password }, { noExpiry:true });
  if(r.error) return { user:null, error:r.error };
  const d = r.data || {};
  setApiToken(d.token, d.cookie);
  await setPayloadKey(d.pk);
  return { user:d.user, role:d.role, permissions:d.permissions || [], defaultPassword:!!d.defaultPassword, error:null };
}
async function apiChangePassword(oldPass, newPass){
  const r = await apiCall({ action:'change_password', old:oldPass, next:newPass }, { noExpiry:true });
  if(r.error) return { ok:false, error:r.error };
  if(r.data && r.data.token){ setApiToken(r.data.token, r.data.cookie); await setPayloadKey(r.data.pk); }
  mustChangeShown = false;
  return { ok:true };
}

// Shown when the server refuses to go further until a real password is set.
let mustChangeShown = false;
function onMustChangePassword(){
  if(mustChangeShown) return;
  mustChangeShown = true;
  try{
    if(typeof openPasswordPrompt === 'function'){ openPasswordPrompt(true); return; }
    if(typeof maybeAskPasswordChange === 'function'){ maybeAskPasswordChange(); return; }
  }catch(e){}
  alert('For your safety you need to choose a new password before using the portal. Your current password is your roll number, which other people can guess.');
}
// Re-checks the signed-in person's own password (used before sensitive actions).
async function apiVerifyOwnPassword(role, identifier, password){
  const r = await apiCall({ action:'login', role, identifier, password }, { noExpiry:true });
  if(r.error) return false;
  if(r.data && r.data.token) setApiToken(r.data.token, r.data.cookie);
  return true;
}

/* ---- query builder: same shape as before ---- */
function ApiQuery(table){
  const st = { action:'query', table, op:'select', columns:'*', filters:[] };
  let shape = null;              // 'single' | 'maybe' | null

  function run(){
    return apiCall(st).then(function(r){
      if(r.error) return r;
      let d = r.data;
      if(shape){
        const arr = Array.isArray(d) ? d : (d == null ? [] : [d]);
        if(shape === 'single' && arr.length !== 1){
          return { data:null, error:{ message:'Expected exactly one row, got ' + arr.length } };
        }
        return { data: arr.length ? arr[0] : null, error:null };
      }
      return { data: Array.isArray(d) ? d : (d == null ? [] : d), error:null };
    });
  }

  const q = {
    select: function(cols){ if(st.op === 'select') st.columns = cols || '*'; return q; },
    insert: function(v){ st.op='insert'; st.values=v; return q; },
    upsert: function(v,o){ st.op='upsert'; st.values=v; if(o && o.onConflict) st.onConflict=o.onConflict; return q; },
    update: function(v){ st.op='update'; st.values=v; return q; },
    delete: function(){ st.op='delete'; return q; },
    eq:     function(c,v){ st.filters.push([c,v]); return q; },
    order:  function(c,o){ st.order = { col:c, asc: !o || o.ascending !== false }; return q; },
    limit:  function(n){ st.limit = n; return q; },
    single:      function(){ shape='single'; return run(); },
    maybeSingle: function(){ shape='maybe';  return run(); },
    then:   function(res,rej){ return run().then(res,rej); },
    catch:  function(rej){ return run().catch(rej); }
  };
  return q;
}

/* ---- live sync: polling, since the browser no longer has
        direct database access for realtime subscriptions ---- */
const POLL_MS = 25000;
const pollers = [];
let pollTimer = null;
function startPolling(){
  if(pollTimer) return;
  pollTimer = setInterval(function(){
    if(document.hidden || !SESSION) return;
    pollers.forEach(function(fn){ try{ fn(); }catch(e){} });
  }, POLL_MS);
}
function ApiChannel(){
  const self = {
    on: function(_evt, _cfg, cb){ if(typeof cb === 'function') pollers.push(cb); return self; },
    subscribe: function(){ startPolling(); return self; },
    unsubscribe: function(){ return self; }
  };
  return self;
}

const sb = {
  from: ApiQuery,
  channel: ApiChannel,
  removeChannel: function(){},
  rpc: function(){ return Promise.resolve({ data:null, error:{ message:'Not available' } }); }
};
const DATA_READY = true;
