/* PDF reader, loaded only when a PDF is actually opened.
   Served from this site on a version without the flaw that let a crafted PDF
   run its own code in the reader's browser. */
let _pdfLib = null, _pdfLoading = null;
function getPdfLib(){
  if(_pdfLib) return Promise.resolve(_pdfLib);
  if(!_pdfLoading){
    _pdfLoading = import('./pdf.min.mjs').then(mod => {
      mod.GlobalWorkerOptions.workerSrc = '/assets/pdf.worker.min.mjs';
      _pdfLib = mod;
      window.pdfjsLib = mod;
      return mod;
    }).catch(err => {
      _pdfLoading = null;
      throw new Error('Could not load the PDF reader. Please refresh and try again.');
    });
  }
  return _pdfLoading;
}

/* ================= DATA LAYER ================= */

function seedData(){
  return {
    admin: { username:'admin', password:'admin123' },
    students: [],
    materials: [
      {id:1, title:'AC Circuits — Part 1', subject:'Physics', cls:'All Classes', fileData:null, uploadedDate:'2026-06-10'},
      {id:2, title:'Electromagnetic Induction — Worksheet', subject:'Physics', cls:'XI (Pre-Engineering)', fileData:null, uploadedDate:'2026-06-18'}
    ],
    expenses: [
      {id:1, date:'2026-06-05', category:'Salaries', description:'June staff salaries', amount:180000},
      {id:2, date:'2026-06-10', category:'Utilities', description:'Electricity bill', amount:15000}
    ]
  };
}





/* =====================================================
   EMAIL SETUP — sends automatic admission-approval emails
   through a secure server function that calls the mail provider
   server-side, keeping the API key private.
   ===================================================== */
const MAIL_URL = "/mail";   // forwarded on by the _redirects file
const EMAIL_CONFIGURED = true;
// Sends the admission-approval email. Never throws — approval must succeed even if email fails.
async function sendApprovalEmail(app, roll){
  if(!app.email){ return { sent:false, reason:'no-email' }; }
  try{
    const htmlContent = `
      <div style="font-family:Arial,sans-serif; max-width:520px; margin:0 auto; color:#2A211C;">
        <h2 style="color:#82182B;">Welcome to Inspired Model School &amp; Girl College Larkana!</h2>
        <p>Dear ${app.name},</p>
        <p>Congratulations — your admission application has been <b>approved</b>. Here are your login details for the Student Portal:</p>
        <div style="background:#F6EFE1; border:1px solid #e5d9ba; border-radius:10px; padding:16px; margin:16px 0;">
          <div><b>Roll Number:</b> ${roll}</div>
          <div><b>Password:</b> ${roll}</div>
          <div><b>Class:</b> ${app.classApplied}</div>
        </div>
        <p>Please log in and change your password after your first login.</p>
        <p style="color:#5b4f45; font-size:13px;">— Inspired Model School &amp; Girl College Larkana</p>
      </div>`;
    const res = await fetch(MAIL_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        to: app.email,
        toName: app.name,
        subject: 'Your Inspired Model School &amp; GC Admission Has Been Approved!',
        htmlContent
      })
    });
    const result = await res.json();
    if(!res.ok){ console.error('Approval email failed:', result); return { sent:false, reason:'send-error', error:result }; }
    return { sent:true };
  } catch(err){
    console.error('Approval email failed to send:', err);
    return { sent:false, reason:'send-error', error:err };
  }
}

/* database client replaced by the secure API client above */

let DB = { admin:{username:'admin', password:'admin123'}, students:[], materials:[], expenses:[], teachers:[], admins:[], liveClasses:[], admissionApplications:[], assignments:[], answerKeys:[], quizzes:[], quizAttempts:[] };
let dbLoaded = { students:false, materials:false, expenses:false, teachers:false, admins:false, liveClasses:false };

function attendanceByDay(attendanceArray){
  const grouped = {};
  attendanceArray.forEach(rec => {
    const date = rec.date || new Date().toISOString().split('T')[0];
    if(!grouped[date]) grouped[date] = [];
    grouped[date].push(rec);
  });
  let html = '<h3 style="margin-top:20px;">📊 Attendance by Day</h3>';
  Object.entries(grouped).sort().reverse().forEach(([date, records]) => {
    const present = records.filter(r => r.status === 'Present').length;
    const total = records.length || 100;
    const pct = Math.round((present / total) * 100);
    const dateObj = new Date(date);
    const dateStr = dateObj.toLocaleDateString('en-US', {weekday:'short', month:'short', day:'numeric'});
    html += `<div class="attendance-day-row" style="--fill:${pct}%">
      <div class="att-day-date">${dateStr}</div>
      <div class="att-day-bar"></div>
      <div class="att-day-count">${present}/${total}</div>
    </div>`;
  });
  return html;
}

function showStudentProfile(student){
  const canSeeFees = SESSION.role==='teacher' ? false
    : SESSION.role==='staff' ? (SESSION.permissions||[]).includes('fees')
    : true;
  const modal = document.createElement('div');
  modal.className = 'modal-fullprofile show';
  modal.innerHTML = `<div class="profile-modal-content" onclick="event.stopPropagation()">
    <span class="profile-modal-close" onclick="this.closest('.modal-fullprofile').remove()">&times;</span>
    <h2 style="color:var(--maroon); margin-top:0;">${student.name}</h2>
    <div class="profile-section">
      <h3>Basic Info</h3>
      <div class="profile-field"><span class="profile-field-label">Roll</span><span>${student.roll}</span></div>
      <div class="profile-field"><span class="profile-field-label">Class</span><span>${student.class}</span></div>
      <div class="profile-field"><span class="profile-field-label">Father</span><span>${student.father || '—'}</span></div>
      <div class="profile-field"><span class="profile-field-label">Phone</span><span>${student.phone || '—'}</span></div>
    </div>
    <div class="profile-section">
      <h3>Academic</h3>
      <div class="profile-field"><span class="profile-field-label">Status</span><span>Active</span></div>
      ${canSeeFees ? `<div class="profile-field"><span class="profile-field-label">Total Fee</span><span>Rs. ${student.feeAmount || student.fee_amount || 0}</span></div>` : ''}
    </div>
    ${canSeeFees ? `<div class="profile-section">
      <h3>Fee History</h3>
      ${(student.fees && student.fees.length) ? student.fees.map(f => `<div style="padding:8px; background:var(--light-gray); color:var(--ink); margin:5px 0; border-radius:10px;"><strong>${f.month}</strong> — Rs. ${f.amount} <span style="color:${f.status === 'Paid' ? '#3f7d4a' : '#a83232'}">(${f.status})</span></div>`).join('') : '<p>No records</p>'}
    </div>` : `<div class="profile-section"><div style="padding:14px; background:#fff3cd; border:1px solid #ffc107; border-radius:10px; color:#856404; font-size:13.5px;">📋 Fee information is only visible to the Director.</div></div>`}
  </div>`;
  modal.onclick = () => modal.remove();
  document.body.appendChild(modal);
}

function autoGradeAnswers(studentAnswerStr, keyStr){
  const parseAnswers = (str) => {
    const result = {};
    str.split(/[,;\n]+/).forEach(pair => {
      const trimmed = pair.trim();
      const match = trimmed.match(/(\d+)\s*[.\-:)]?\s*([A-Da-d])/);
      if(match) result[match[1]] = match[2].toUpperCase();
    });
    return result;
  };
  const key = parseAnswers(keyStr);
  const student = parseAnswers(studentAnswerStr);
  let correct = 0, total = Object.keys(key).length;
  let details = [];
  Object.entries(key).forEach(([q, ans]) => {
    const studentAns = student[q];
    const isMatch = studentAns === ans;
    if(isMatch) correct++;
    details.push({q, ans, studentAns: studentAns || '—', match: isMatch});
  });
  return { correct, total, pct: total ? Math.round((correct/total)*100) : 0, details };
}
// Detects whether submitted text is just a list of answer choices (e.g. "1A, 2B, 3C")
// with no prose/explanation — used to skip AI review and grade locally instead.
function isAnswerOnlyFormat(text){
  if(!text) return false;
  const trimmed = text.trim();
  if(!trimmed || trimmed.length > 500) return false;
  const pairs = trimmed.split(/[,;\n]+/).map(p=>p.trim()).filter(Boolean);
  if(!pairs.length) return false;
  const matching = pairs.filter(p => /^\d+\s*[.\-:)]?\s*[A-Da-d]$/.test(p));
  return matching.length / pairs.length >= 0.8; // at least 80% of entries look like "1A" pairs
}

/* ================= ADMISSION FEE INSTALLMENTS =================
   Fee structure: 9th/10th/Entrance pay monthly (Rs. 4500/month, no installment choice needed).
   XI and above pay yearly (Rs. 45,000/year), split into at most 2 installments. */
const YEARLY_FEE_CLASSES_KEYWORD = ['XI','XII'];
let admSelectedInstallments = 1;
function isYearlyFeeClass(cls){
  return YEARLY_FEE_CLASSES_KEYWORD.some(k => (cls||'').toUpperCase().includes(k));
}
/* ================= 2ND INSTALLMENT ENFORCEMENT =================
   For students on the 2-installment plan: 2nd payment is due 2 months after admission.
   After that due date, a 3-month grace period applies. If still unpaid once the grace
   period ends, the student is blocked from logging in. During the grace period, a
   warning is shown at login instead. Nothing happens for students not on this plan,
   or whose 2nd installment is already marked Paid. */
function getInstallment2Status(student){
  if(!student || student.installmentPlan !== 2) return null;
  const inst2 = (student.fees||[]).find(f => f.month === 'Installment 2');
  if(!inst2 || inst2.status === 'Paid') return null;
  const dueDate = new Date((inst2.dueDate || inst2.date) + 'T00:00:00');
  if(isNaN(dueDate)) return null;
  const graceEnd = new Date(dueDate); graceEnd.setMonth(graceEnd.getMonth()+3);
  const now = new Date();
  const blocked = now > graceEnd;
  const daysUntilBlock = Math.ceil((graceEnd - now) / (1000*60*60*24));
  const isOverdue = now > dueDate;
  return { dueDate, graceEnd, blocked, daysUntilBlock: Math.max(0,daysUntilBlock), isOverdue, pendingReceiptUrl: inst2.pendingReceiptUrl || null };
}
function updateAdmInstallmentVisibility(){
  const clsEl = document.getElementById('adm_class');
  const section = document.getElementById('adm_installment_section');
  if(!clsEl || !section) return;
  if(isYearlyFeeClass(clsEl.value)){
    section.classList.remove('section-hidden');
    admSelectedInstallments = 1;
    document.getElementById('admInstallmentCards').innerHTML = renderInstallmentCards(45000, [1, 2]);
  } else {
    section.classList.add('section-hidden');
  }
}
function renderInstallmentCards(totalAmount, options){
  let html = '';
  options.forEach(count => {
    const amt = Math.round(totalAmount / count);
    html += `<div class="installment-card ${count===admSelectedInstallments?'selected':''}" onclick="selectInstallment(this, ${count})">
      <input type="radio" name="inst" value="${count}" ${count===admSelectedInstallments?'checked':''}>
      <div class="installment-amount">Rs. ${amt.toLocaleString()}</div>
      <div class="installment-desc">${count} payment${count > 1 ? 's' : ''}${count>1?' of Rs. '+amt.toLocaleString()+' each':' (full amount)'}</div>
    </div>`;
  });
  return html;
}
function selectInstallment(el, count){
  admSelectedInstallments = count;
  document.querySelectorAll('#admInstallmentCards .installment-card').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
  el.querySelector('input').checked = true;
}

let chStudents=null, chMaterials=null, chExpenses=null, chMyStudent=null, chTeachers=null, chAdmins=null, chLiveClasses=null, chAdmissions=null, chSettings=null, chAssignments=null, chAnswerKeys=null, chQuizzes=null, chQuizAttempts=null;
let academySettings = { bankName:'', bankBranch:'', accountTitle:'', accountNumber:'', easypaisaNumber:'', admissionNote:'', attendanceNote:'', assignmentsNote:'', liveClassNote:'' };
function settingsRowToObj(r){
  return {
    bankName: r.bank_name||'', bankBranch: r.bank_branch||'', accountTitle: r.account_title||'',
    accountNumber: r.account_number||'', easypaisaNumber: r.easypaisa_number||'', admissionNote: r.admission_note||'',
    attendanceNote: r.attendance_note||'', assignmentsNote: r.assignments_note||'', liveClassNote: r.live_class_note||''
  };
}
function renderDirectorNote(noteText){
  if(!noteText || !noteText.trim()) return '';
  return `<div class="notes-box">
    <h4>📌 Note from the Director</h4>
    <div style="font-size:14px; line-height:1.6; color:var(--ink);">${noteText.trim().split('\n').map(line=>`<div>${line}</div>`).join('')}</div>
  </div>`;
}
function renderBankDetailsBlock(){
  const el = document.getElementById('admissionBankDetails');
  if(!el) return;
  const s = academySettings;
  const hasBank = s.bankName || s.accountNumber;
  const hasEasypaisa = s.easypaisaNumber;
  const hasNote = s.admissionNote && s.admissionNote.trim();

  let noteHtml = '';
  if(hasNote){
    noteHtml = `
    <div style="background:var(--light-gray); border:1px solid var(--maroon); border-radius:14px; padding:12px 14px; margin-bottom:14px; font-size:13.5px; line-height:1.6; color:var(--ink);">
      ${s.admissionNote.trim().split('\n').map(line=>`<div>${line}</div>`).join('')}
    </div>`;
  }

  if(!hasBank && !hasEasypaisa){
    el.innerHTML = noteHtml;
    return;
  }
  let rows = '';
  if(hasBank){
    rows += `
      ${s.bankName ? `<div><b>Bank:</b> ${s.bankName}</div>` : ''}
      ${s.bankBranch ? `<div><b>Branch:</b> ${s.bankBranch}</div>` : ''}
      ${s.accountTitle ? `<div><b>Account Title:</b> ${s.accountTitle}</div>` : ''}
      ${s.accountNumber ? `<div><b>Account Number / IBAN:</b> ${s.accountNumber}</div>` : ''}`;
  }
  if(hasEasypaisa){
    rows += `<div><b>Easypaisa Number:</b> ${s.easypaisaNumber}</div>`;
  }
  el.innerHTML = noteHtml + `
    <div style="background:var(--light-gray); border:1px solid var(--gold); border-radius:14px; padding:12px 14px; margin-bottom:16px; font-size:13.5px; line-height:1.7; color:var(--ink);">
      <div style="font-weight:700; color:var(--maroon); margin-bottom:6px;">Deposit your fee to:</div>
      ${rows}
      <div style="margin-top:6px; color:var(--ink-soft); font-size:12.5px;">Deposit the required fee here first, then upload your stamped receipt or transaction screenshot below.</div>
    </div>`;
}
async function refreshAcademySettings(){
  if(!DATA_READY) return;
  const { data, error } = await sb.from('academy_settings').select('*').eq('id', 1).maybeSingle();
  if(error){ console.error('academy_settings fetch error', error); return; }
  if(data) academySettings = settingsRowToObj(data);
  renderBankDetailsBlock();
  if(SESSION) renderPage();
}
function startSettingsListener(){
  refreshAcademySettings();
  if(!chSettings) chSettings = sb.channel('settings-all')
    .on('postgres_changes', {event:'*', schema:'public', table:'academy_settings'}, refreshAcademySettings)
    .subscribe();
}
if(DATA_READY) startSettingsListener();

/* Attempt to restore a saved login when the app opens (stay signed in) */
if(DATA_READY){
  window.addEventListener('DOMContentLoaded', function(){
    setTimeout(function(){ restoreSession(); }, 300);
  });
  // DOMContentLoaded may have already fired if script is at end of body
  if(document.readyState !== 'loading'){
    setTimeout(function(){ if(!SESSION) restoreSession(); }, 350);
  }
}

function studentRowToObj(r){
  return {
    roll: r.roll, password: r.password, name: r.name, class: r.class,
    father: r.father||'', phone: r.phone||'', email: r.email||'', feeAmount: r.fee_amount||0,
    cardId: r.card_id||'',
    fees: r.fees||[], attendance: r.attendance||[], results: r.results||[], installmentPlan: r.installment_plan||null
  };
}
function materialRowToObj(r){
  return { id:r.id, title:r.title, subject:r.subject, cls:r.cls, fileURL:r.file_url, fileName:r.file_name, uploadedDate:r.uploaded_date };
}
function expenseRowToObj(r){
  return { id:r.id, date:r.date, category:r.category, description:r.description, amount:r.amount };
}
function teacherRowToObj(r){
  return { username:r.username, password:r.password, name:r.name, subject:r.subject||'', phone:r.phone||'', cardId:r.card_id||'', attendance:r.attendance||[], permissions:r.permissions||TEACHER_DEFAULT_PERMISSIONS };
}
function staffRowToObj(r){
  return { username:r.username, password:r.password, name:r.name, permissions:r.permissions||[] };
}
function liveClassRowToObj(r){
  return { id:r.id, class:r.class, subject:r.subject, roomName:r.room_name, hostName:r.host_name, startedAt:r.started_at, active:r.active };
}
function admissionRowToObj(r){
  return {
    id:r.id, name:r.name, fatherName:r.father_name, phone:r.phone, email:r.email, classApplied:r.class_applied,
    previousSchool:r.previous_school, address:r.address, notes:r.notes,
    status:r.status, submittedAt:r.submitted_at, receiptUrl:r.receipt_url, approvedRoll:r.approved_roll, installmentPlan:r.installment_plan
  };
}
function assignmentRowToObj(r){
  return {
    id:r.id, studentRoll:r.student_roll, studentName:r.student_name, class:r.class, subject:r.subject, title:r.title,
    fileUrl:r.file_url, fileName:r.file_name, submittedAt:r.submitted_at,
    aiFeedback:r.ai_feedback, aiMarks:r.ai_marks, aiPercentage:r.ai_percentage,
    aiPlagiarismFlag:r.ai_plagiarism_flag, aiPlagiarismNote:r.ai_plagiarism_note,
    status:r.status, teacherComment:r.teacher_comment, reviewedBy:r.reviewed_by
  };
}
function answerKeyRowToObj(r){
  return { id:r.id, subject:r.subject, title:r.title, answerKey:r.answer_key, createdBy:r.created_by, createdAt:r.created_at };
}
function quizRowToObj(r){
  return {
    id:r.id, title:r.title, subject:r.subject, cls:r.class, durationMinutes:r.duration_minutes,
    questions: r.questions||[], createdBy:r.created_by, createdAt:r.created_at, status:r.status||'published'
  };
}
function quizAttemptRowToObj(r){
  return {
    id:r.id, quizId:r.quiz_id, studentRoll:r.student_roll, studentName:r.student_name,
    answers:r.answers||[], score:r.score, total:r.total, percentage:r.percentage, submittedAt:r.submitted_at
  };
}

/* One-time migration: pushes the sample/seed data baked into this file up
   into the server. Safe to click more than once — it warns if data already
   exists. Only relevant the first time you connect a fresh project. */
async function migrateSeedData(){
  if(!DATA_READY){ alert('Database not configured.'); return; }
  if(!confirm('This uploads the built-in student/expense/material list into your the server project. Only do this once per project. Continue?')) return;
  const { count } = await sb.from('students').select('*', {count:'exact', head:true});
  if(count && count > 0){
    if(!confirm('Your the server project already has student records. Uploading again may create duplicates. Continue anyway?')) return;
  }
  const seed = seedData();
  const studentRows = seed.students.map(s => ({
    roll:s.roll, password:s.password, name:s.name, class:s.class,
    father:s.father, phone:s.phone, fee_amount:s.feeAmount,
    fees:s.fees, attendance:s.attendance, results:s.results
  }));
  for(let i=0;i<studentRows.length;i+=200){
    const chunk = studentRows.slice(i, i+200);
    const { error } = await sb.from('students').upsert(chunk, {onConflict:'roll'});
    if(error){ console.error(error); alert('Error uploading students: ' + error.message); return; }
  }
  const expenseRows = seed.expenses.map(e => ({ date:e.date, category:e.category, description:e.description, amount:e.amount }));
  if(expenseRows.length){
    const { error } = await sb.from('expenses').insert(expenseRows);
    if(error){ console.error(error); alert('Error uploading expenses: ' + error.message); return; }
  }
  const materialRows = seed.materials.map(m => ({ title:m.title, subject:m.subject, cls:m.cls, file_url:null, file_name:null, uploaded_date:m.uploadedDate }));
  if(materialRows.length){
    const { error } = await sb.from('materials').insert(materialRows);
    if(error){ console.error(error); alert('Error uploading materials: ' + error.message); return; }
  }
  const { error: adminErr } = await sb.from('admin_meta').upsert({ id:1, username:seed.admin.username, password:seed.admin.password });
  if(adminErr){ console.error(adminErr); alert('Error uploading admin credentials: ' + adminErr.message); return; }
  alert('Upload complete! Your data is now live in the server.');
}

function hideAppLoadingOverlay(){
  const el = document.getElementById('appLoadingOverlay');
  if(el) el.classList.add('hide');
}
async function refreshStudentsFromServer(){
  const { data, error } = await sb.from('students').select('*').order('roll');
  if(error){ console.error('students fetch error', error); return; }
  DB.students = data.map(studentRowToObj);
  dbLoaded.students = true;
  if(SESSION) renderPage();
  hideAppLoadingOverlay();
}
async function refreshMaterialsFromServer(){
  const { data, error } = await sb.from('materials').select('*').order('uploaded_date', {ascending:false});
  if(error){ console.error('materials fetch error', error); return; }
  DB.materials = data.map(materialRowToObj);
  dbLoaded.materials = true;
  if(SESSION) renderPage();
}
async function refreshExpensesFromServer(){
  const { data, error } = await sb.from('expenses').select('*').order('date', {ascending:false});
  if(error){ console.error('expenses fetch error', error); return; }
  DB.expenses = data.map(expenseRowToObj);
  dbLoaded.expenses = true;
  if(SESSION) renderPage();
}
async function refreshTeachersFromServer(){
  const { data, error } = await sb.from('teachers').select('*').order('username');
  if(error){ console.error('teachers fetch error', error); return; }
  DB.teachers = data.map(teacherRowToObj);
  dbLoaded.teachers = true;
  if(SESSION) renderPage();
}
async function refreshAdminsFromServer(){
  const { data, error } = await sb.from('admins').select('*').order('username');
  if(error){ console.error('admins fetch error', error); return; }
  DB.admins = data.map(staffRowToObj);
  dbLoaded.admins = true;
  if(SESSION) renderPage();
}
async function refreshLiveClassesFromServer(){
  const { data, error } = await sb.from('live_classes').select('*').eq('active', true).order('started_at', {ascending:false});
  if(error){ console.error('live_classes fetch error', error); return; }
  DB.liveClasses = data.map(liveClassRowToObj);
  dbLoaded.liveClasses = true;
  if(SESSION) renderPage();
}
function startLiveClassListener(){
  if(!chLiveClasses) chLiveClasses = sb.channel('live-classes-all')
    .on('postgres_changes', {event:'*', schema:'public', table:'live_classes'}, refreshLiveClassesFromServer)
    .subscribe();
  refreshLiveClassesFromServer();
}
async function refreshAdmissionsFromServer(){
  const { data, error } = await sb.from('admission_applications').select('*').order('submitted_at', {ascending:false});
  if(error){ console.error('admission_applications fetch error', error); return; }
  DB.admissionApplications = data.map(admissionRowToObj);
  if(SESSION) renderPage();
}
async function refreshAssignmentsFromServer(){
  const { data, error } = await sb.from('assignments').select('*').order('submitted_at', {ascending:false});
  if(error){ console.error('assignments fetch error', error); return; }
  DB.assignments = data.map(assignmentRowToObj);
  if(SESSION) renderPage();
}
async function refreshMyAssignments(roll){
  const { data, error } = await sb.from('assignments').select('*').eq('student_roll', roll).order('submitted_at', {ascending:false});
  if(error){ console.error('my assignments fetch error', error); return; }
  DB.assignments = data.map(assignmentRowToObj);
  if(SESSION) renderPage();
}
async function refreshAnswerKeysFromServer(){
  const { data, error } = await sb.from('answer_keys').select('*').order('created_at', {ascending:false});
  if(error){ console.error('answer_keys fetch error', error); return; }
  DB.answerKeys = data.map(answerKeyRowToObj);
  if(SESSION) renderPage();
}
async function refreshQuizzesFromServer(){
  const { data, error } = await sb.from('quizzes').select('*').order('created_at', {ascending:false});
  if(error){ console.error('quizzes fetch error', error); return; }
  DB.quizzes = data.map(quizRowToObj);
  if(SESSION) renderPage();
}
async function refreshAllQuizAttemptsFromServer(){
  const { data, error } = await sb.from('quiz_attempts').select('*').order('submitted_at', {ascending:false});
  if(error){ console.error('quiz_attempts fetch error', error); return; }
  DB.quizAttempts = data.map(quizAttemptRowToObj);
  if(SESSION) renderPage();
}
async function refreshMyQuizAttempts(roll){
  const { data, error } = await sb.from('quiz_attempts').select('*').eq('student_roll', roll).order('submitted_at', {ascending:false});
  if(error){ console.error('my quiz_attempts fetch error', error); return; }
  DB.quizAttempts = data.map(quizAttemptRowToObj);
  if(SESSION) renderPage();
}

function startAdminListeners(){
  refreshStudentsFromServer();
  refreshExpensesFromServer();
  refreshMaterialsFromServer();
  refreshTeachersFromServer();
  refreshAdminsFromServer();
  refreshAdmissionsFromServer();
  refreshAssignmentsFromServer();
  refreshAnswerKeysFromServer();
  refreshQuizzesFromServer();
  refreshAllQuizAttemptsFromServer();
  if(!chStudents) chStudents = sb.channel('students-admin')
    .on('postgres_changes', {event:'*', schema:'public', table:'students'}, refreshStudentsFromServer)
    .subscribe();
  if(!chExpenses) chExpenses = sb.channel('expenses-admin')
    .on('postgres_changes', {event:'*', schema:'public', table:'expenses'}, refreshExpensesFromServer)
    .subscribe();
  if(!chTeachers) chTeachers = sb.channel('teachers-admin')
    .on('postgres_changes', {event:'*', schema:'public', table:'teachers'}, refreshTeachersFromServer)
    .subscribe();
  if(!chAdmins) chAdmins = sb.channel('admins-admin')
    .on('postgres_changes', {event:'*', schema:'public', table:'admins'}, refreshAdminsFromServer)
    .subscribe();
  if(!chAdmissions) chAdmissions = sb.channel('admissions-admin')
    .on('postgres_changes', {event:'*', schema:'public', table:'admission_applications'}, refreshAdmissionsFromServer)
    .subscribe();
  if(!chAssignments) chAssignments = sb.channel('assignments-admin')
    .on('postgres_changes', {event:'*', schema:'public', table:'assignments'}, refreshAssignmentsFromServer)
    .subscribe();
  if(!chAnswerKeys) chAnswerKeys = sb.channel('answer-keys-admin')
    .on('postgres_changes', {event:'*', schema:'public', table:'answer_keys'}, refreshAnswerKeysFromServer)
    .subscribe();
  if(!chQuizzes) chQuizzes = sb.channel('quizzes-admin')
    .on('postgres_changes', {event:'*', schema:'public', table:'quizzes'}, refreshQuizzesFromServer)
    .subscribe();
  if(!chQuizAttempts) chQuizAttempts = sb.channel('quiz-attempts-admin')
    .on('postgres_changes', {event:'*', schema:'public', table:'quiz_attempts'}, refreshAllQuizAttemptsFromServer)
    .subscribe();
  startMaterialsListener();
  startLiveClassListener();
}
function startMaterialsListener(){
  if(!chMaterials) chMaterials = sb.channel('materials-all')
    .on('postgres_changes', {event:'*', schema:'public', table:'materials'}, refreshMaterialsFromServer)
    .subscribe();
  refreshMaterialsFromServer();
}
async function startStudentListener(roll){
  if(chMyStudent) sb.removeChannel(chMyStudent);
  const refreshMine = async () => {
    const { data, error } = await sb.from('students').select('*').eq('roll', roll).single();
    if(!error && data){ DB.myStudent = studentRowToObj(data); if(SESSION) renderPage(); }
  };
  chMyStudent = sb.channel('student-'+roll)
    .on('postgres_changes', {event:'*', schema:'public', table:'students', filter:`roll=eq.${roll}`}, refreshMine)
    .subscribe();
  refreshMyAssignments(roll);
  refreshAnswerKeysFromServer();
  refreshQuizzesFromServer();
  refreshMyQuizAttempts(roll);
  if(!chAssignments) chAssignments = sb.channel('assignments-student-'+roll)
    .on('postgres_changes', {event:'*', schema:'public', table:'assignments', filter:`student_roll=eq.${roll}`}, () => refreshMyAssignments(roll))
    .subscribe();
  if(!chQuizzes) chQuizzes = sb.channel('quizzes-student')
    .on('postgres_changes', {event:'*', schema:'public', table:'quizzes'}, refreshQuizzesFromServer)
    .subscribe();
  if(!chQuizAttempts) chQuizAttempts = sb.channel('quiz-attempts-student-'+roll)
    .on('postgres_changes', {event:'*', schema:'public', table:'quiz_attempts', filter:`student_roll=eq.${roll}`}, () => refreshMyQuizAttempts(roll))
    .subscribe();
  startMaterialsListener();
  startLiveClassListener();
}
function stopAllListeners(){
  if(chStudents){ sb.removeChannel(chStudents); chStudents=null; }
  if(chMaterials){ sb.removeChannel(chMaterials); chMaterials=null; }
  if(chExpenses){ sb.removeChannel(chExpenses); chExpenses=null; }
  if(chTeachers){ sb.removeChannel(chTeachers); chTeachers=null; }
  if(chAdmins){ sb.removeChannel(chAdmins); chAdmins=null; }
  if(chLiveClasses){ sb.removeChannel(chLiveClasses); chLiveClasses=null; }
  if(chAdmissions){ sb.removeChannel(chAdmissions); chAdmissions=null; }
  if(chAnswerKeys){ sb.removeChannel(chAnswerKeys); chAnswerKeys=null; }
  if(chQuizzes){ sb.removeChannel(chQuizzes); chQuizzes=null; }
  if(chQuizAttempts){ sb.removeChannel(chQuizAttempts); chQuizAttempts=null; }
  if(chMyStudent){ sb.removeChannel(chMyStudent); chMyStudent=null; }
  DB.myStudent = null;
}

let SESSION = null; // {role:'student'|'admin', roll?:string}

/* ===== Persistent login (stay signed in until logout) =====
   Saves enough to silently restore the session when the app reopens.
   Stored locally on the device only. Cleared on logout. */
const SESSION_KEY = 'ia_session_v1';
function saveSession(extra){
  try{
    const payload = Object.assign({}, SESSION, extra||{});
    delete payload.pass; delete payload.password;   // never store a password on the device
    localStorage.setItem(SESSION_KEY, JSON.stringify(payload));
  }catch(e){ /* storage unavailable — silent */ }
}
function clearSavedSession(){
  try{ localStorage.removeItem(SESSION_KEY); }catch(e){}
  try{ if(haveSession()) apiCall({ action:'logout' }, { noExpiry:true }); }catch(e){}
  try{ setApiToken(null, false); }catch(e){}
  try{ setPayloadKey(null); }catch(e){}
}
function getSavedSession(){
  try{ return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); }catch(e){ return null; }
}
async function restoreSession(){
  const saved = getSavedSession();
  if(!saved || !saved.role) return false;
  // The signed token is the proof of identity. No password is kept on the device.
  if(!haveSession()){ clearSavedSession(); return false; }
  try{
    if(saved.role === 'student'){
      SESSION = { role:'student', roll:saved.roll, defaultPassword: !!saved.defaultPassword };
      const { data: row, error } = await sb.from('students').select('*').eq('roll', saved.roll).maybeSingle();
      if(error || !row){ SESSION=null; setApiToken(null, false); clearSavedSession(); return false; }
      DB.myStudent = studentRowToObj(row);
      startStudentListener(saved.roll);
      setTimeout(maybeAskPasswordChange, 900);
    } else if(saved.role === 'teacher'){
      SESSION = { role:'teacher', username:saved.username, name:saved.name, permissions:saved.permissions||TEACHER_DEFAULT_PERMISSIONS };
      const { data: row, error } = await sb.from('teachers').select('*').eq('username', saved.username).maybeSingle();
      if(error || !row){ SESSION=null; setApiToken(null, false); clearSavedSession(); return false; }
      SESSION.name = row.name;
      startAdminListeners();
    } else if(saved.role === 'staff'){
      SESSION = { role:'staff', username:saved.username, name:saved.name, permissions:saved.permissions||[] };
      const { data: row, error } = await sb.from('admins').select('*').eq('username', saved.username).maybeSingle();
      if(error || !row){ SESSION=null; setApiToken(null, false); clearSavedSession(); return false; }
      SESSION.name = row.name;
      startAdminListeners();
    } else if(saved.role === 'admin'){
      SESSION = { role:'admin', username:saved.username };
      const { data: row, error } = await sb.from('admin_meta').select('*').eq('id', 1).maybeSingle();
      if(error){ SESSION=null; setApiToken(null, false); clearSavedSession(); return false; }
      DB.admin = { username: (row && row.username) || saved.username };
      startAdminListeners();
    } else { return false; }

    // show the app UI
    document.getElementById('loginScreen').style.display='none';
    document.getElementById('app').style.display='block';
    document.getElementById('app').classList.add('post-login');
    const ov = document.getElementById('appLoadingOverlay');
    if(ov) ov.classList.remove('hide');
    currentTab='dashboard';
    buildNav();
    renderPage();
    if(SESSION.role==='student'){ startAnnouncementsListener(); loadAnnouncements(); }
    if(SESSION.role==='student') hideAppLoadingOverlay();
    setTimeout(hideAppLoadingOverlay, 4000);
    return true;
  }catch(e){ console.error('restoreSession failed', e); return false; }
}
let loginFeeWarning = null; // set at login if a student's 2nd installment is overdue but not yet blocked
let currentTab = 'dashboard';
let loginRole = 'student';

/* ================= LOGIN ================= */
function setLoginRole(role){
  loginRole = role;
  document.getElementById('roleStudentBtn').classList.toggle('active', role==='student');
  document.getElementById('roleTeacherBtn').classList.toggle('active', role==='teacher');
  document.getElementById('roleStaffBtn').classList.toggle('active', role==='staff');
  document.getElementById('roleAdminBtn').classList.toggle('active', role==='admin');
  document.getElementById('studentLoginFields').classList.toggle('section-hidden', role!=='student');
  document.getElementById('teacherLoginFields').classList.toggle('section-hidden', role!=='teacher');
  document.getElementById('staffLoginFields').classList.toggle('section-hidden', role!=='staff');
  document.getElementById('adminLoginFields').classList.toggle('section-hidden', role!=='admin');
  document.getElementById('loginError').textContent='';
}

async function checkReceiptImage(imageUrl, expectedAmount){
  if(typeof puter === 'undefined'){ console.warn('Receipt check: puter is not available'); return null; }
  try{
    const prompt = `You are checking a document upload for a school admission system. Look at this image and determine if it is EITHER of these two things:

1. An Easypaisa mobile wallet transaction receipt/slip — a digital screenshot showing a money transfer or payment confirmation from the Easypaisa app or Easypaisa SMS. IMPORTANT: for this to count, the receiver / recipient name shown on the transaction must be "Mukhtiar Ahmed" (allow for minor spelling variations like "Mukhtiar Ahmad" or "Mukhtiar Ahmed"). If the receiver is anyone else, or if the receiver's name isn't visible/legible in the image, this does NOT count as valid.

2. The physical "Inspired Model School &amp; GC" fee receipt slip used by Inspired Model School &amp; Girl College Larkana (Science Coaching & Pre-Entrance Academy Larkana). This is a small printed carbon-copy paper slip with these specific distinguishing features:
   - A header reading "Inspired Model School &amp; GC" next to a logo icon (a graduation cap over a DNA double-helix shape)
   - The text "SCIENCE COACHING & PRE-ENTRANCE ACADEMY LARKANA" in a dark banner below the header
   - A tagline like "Quality, Innovation, Inspiration & Innovation" near the top
   - Handwritten fields labeled: "S No.", "Seat No.", "Dated", "Name of Student", "Father's Name", "Month", a circled class indicator like "IX" or "X", "Admission Fee", "Fees", an "Rs." amount box, "Cell" with phone numbers, and a "Signature" line
   - The printed note "Fees is not refundable"
   - It typically has a torn/perforated left edge, since it's torn from a carbon-copy receipt book

Also read the amount of money shown on the receipt (the Rs. amount for the transaction or fee payment).

Respond with ONLY a JSON object, no other text, in exactly this format: {"valid": true or false, "amount": the numeric Rs. amount shown on the receipt (just the number, no commas or currency symbol), or null if no amount is visible, "reason": "one short sentence explaining why"}

If the image is unclear, blurry, or unrelated to either of these two specific things (e.g. a random photo, a selfie, a screenshot of something else, an Easypaisa payment to someone other than Mukhtiar Ahmed, a receipt from a different institution or bank, or any other document), respond with valid: false. Be reasonably strict — only accept images that clearly match one of these two specific requirements.`;

    let response;
    try{
      response = await puter.ai.chat(prompt, imageUrl, { model: 'gpt-5.4-nano' });
    } catch(modelErr){
      console.warn('Vision model gpt-5.4-nano failed, retrying with default model:', modelErr);
      response = await puter.ai.chat(prompt, imageUrl);
    }

    let text = '';
    if(typeof response === 'string'){
      text = response;
    } else if(response && response.message && response.message.content){
      const c = response.message.content;
      text = Array.isArray(c) ? c.map(b=>b.text||'').filter(Boolean).join('') : String(c);
    } else if(response && typeof response.toString === 'function'){
      text = response.toString();
    }

    const match = text.match(/\{[\s\S]*\}/);
    if(!match){ console.warn('Receipt check: could not find JSON in response, failing open.'); return null; }
    const parsed = JSON.parse(match[0]);
    if(parsed.valid !== true) return { valid:false, amount:parsed.amount, reason:parsed.reason };
    // Receipt looks legitimate — now check the amount matches what this payment plan requires.
    if(expectedAmount && typeof parsed.amount === 'number'){
      const amountMatches = Math.abs(parsed.amount - expectedAmount) <= 5; // small tolerance for rounding
      if(!amountMatches){
        return { valid:false, amount:parsed.amount, amountMismatch:true, reason:`Receipt shows Rs. ${parsed.amount.toLocaleString()}, but Rs. ${expectedAmount.toLocaleString()} was expected for the selected payment plan.` };
      }
    }
    return { valid:true, amount:parsed.amount, reason:parsed.reason };
  } catch(err){
    console.error('Receipt check failed:', err);
    return null; // fail open — don't block a genuine applicant over a technical hiccup
  }
}
async function submitAdmissionApplication(){
  const errBox = document.getElementById('admissionSubmitError');
  errBox.textContent = '';
  if(!DATA_READY){ errBox.textContent = 'The portal database is not configured yet. Please contact the academy directly.'; return; }
  const name = document.getElementById('adm_name').value.trim();
  const father = document.getElementById('adm_father').value.trim();
  const phone = document.getElementById('adm_phone').value.trim();
  const email = document.getElementById('adm_email').value.trim();
  const cls = document.getElementById('adm_class').value;
  const prevSchool = document.getElementById('adm_prevschool').value.trim();
  const address = document.getElementById('adm_address').value.trim();
  const notes = document.getElementById('adm_notes').value.trim();
  const receiptInput = document.getElementById('adm_receipt');
  if(!name || !father || !phone){ errBox.textContent = 'Please fill in the student name, father\'s name, and phone number.'; return; }
  if(!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){ errBox.textContent = 'Please enter a valid email address — this is how you\'ll receive your login details once approved.'; return; }
  // Check both camera and gallery inputs
  const galleryInput = document.getElementById('adm_receipt_gallery');
  const hasReceipt = (receiptInput.files && receiptInput.files[0]) || (galleryInput && galleryInput.files && galleryInput.files[0]);
  if(!hasReceipt){ errBox.textContent = 'Please upload your fee/transaction receipt to complete the application.'; return; }
  const btn = document.querySelector('#admissionApplyOverlay .btn.gold');
  const progWrap = document.getElementById('adm_receipt_progress_wrap');
  const progBar = document.getElementById('adm_receipt_progress_bar');
  const progText = document.getElementById('adm_receipt_progress_text');
  btn.disabled = true; btn.textContent = 'Submitting...';
  try{
    const installmentPlan = isYearlyFeeClass(cls) ? admSelectedInstallments : null;
    const expectedAmount = isYearlyFeeClass(cls) ? Math.round(45000 / admSelectedInstallments) : 4500;
    let receiptUrl = null;
    if(receiptInput.files && receiptInput.files[0]){
      const file = receiptInput.files[0];
      const path = `${Date.now()}_${file.name}`;
      progWrap.classList.remove('section-hidden');
      const storedPath = await uploadWithProgress(path, file, (pct) => {
        progBar.style.width = pct + '%';
        progText.textContent = pct + '% uploaded' + (pct===100 ? ' — finishing up...' : '');
      }, 'receipts', true);
      receiptUrl = `${DATA_URL}/storage/v1/object/public/receipts/${storedPath}`;

      progText.textContent = 'Verifying receipt...';
      const checkResult = await checkReceiptImage(receiptUrl, expectedAmount);
      if(checkResult && checkResult.valid === false){
        errBox.textContent = checkResult.amountMismatch
          ? checkResult.reason + ' Please upload a receipt for the correct amount, or go back and change your payment plan.'
          : 'This doesn\'t look like a valid Easypaisa transaction slip or Inspired Model School &amp; GC fee receipt. Please upload a clear photo or screenshot of one of those specifically.';
        btn.disabled = false; btn.textContent = 'Submit Application';
        progWrap.classList.add('section-hidden'); progBar.style.width='0%'; progText.textContent='0%';
        return;
      }
      // checkResult === null (check itself failed) — proceed anyway, letting the Director review it.
    }
    const applyRes = await apiCall({ action:'apply', values:{
      name, father_name:father, phone, email, class_applied:cls,
      previous_school:prevSchool, address, notes, receipt_url:receiptUrl, installment_plan:installmentPlan
    }}, { noExpiry:true });
    if(applyRes.error) throw new Error(applyRes.error.message);
    closeModal('admissionApplyOverlay');
    alert('Your application has been submitted successfully! You will receive an email with your login details once the academy approves your application.');
    ['adm_name','adm_father','adm_phone','adm_email','adm_prevschool','adm_address','adm_notes'].forEach(id => document.getElementById(id).value = '');
    receiptInput.value = '';
    document.getElementById('adm_class').selectedIndex = 0;
    updateAdmInstallmentVisibility();
    progWrap.classList.add('section-hidden'); progBar.style.width='0%'; progText.textContent='0%';
  } catch(err){
    console.error(err);
    errBox.textContent = 'Could not submit your application. Please check your internet connection and try again.';
  } finally {
    btn.disabled = false; btn.textContent = 'Submit Application';
  }
}

async function attemptLogin(){
  const errBox = document.getElementById('loginError');
  errBox.textContent='';
  if(!DATA_READY){ errBox.textContent='Database not configured yet — see the notice above.'; return; }
  const signInBtn = document.querySelector('.btn-primary');
  signInBtn.disabled = true; signInBtn.textContent='Checking...';
  try{
    if(loginRole==='student'){
      const rollInput = document.getElementById('rollInput').value.trim();
      const pass = document.getElementById('passInput').value;
      if(!rollInput || !pass){ errBox.textContent='Please enter roll number and password.'; return; }
      let roll = rollInput;
      let res = await apiLogin('student', roll, pass);
      if(res.error && rollInput !== rollInput.toUpperCase()){
        roll = rollInput.toUpperCase();
        res = await apiLogin('student', roll, pass);
      }
      if(res.error){ errBox.textContent = res.error.message; return; }
      const row = res.user;
      const studentObj = studentRowToObj(row);
      const inst2Status = getInstallment2Status(studentObj);
      if(inst2Status && inst2Status.blocked){
        errBox.textContent = `Your account is temporarily blocked because the 2nd installment fee (due ${inst2Status.dueDate.toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'})}) has not been paid. Please contact the academy directly, or pay and upload your receipt, to restore access.`;
        return;
      }
      loginFeeWarning = (inst2Status && inst2Status.isOverdue) ? inst2Status : null;
      SESSION = { role:'student', roll, defaultPassword: !!res.defaultPassword };
      saveSession({ defaultPassword: !!res.defaultPassword });
      DB.myStudent = studentObj;
      startStudentListener(roll);
      setTimeout(maybeAskPasswordChange, 900);
    } else if(loginRole==='teacher'){
      const u = document.getElementById('teacherUserInput').value.trim();
      const p = document.getElementById('teacherPassInput').value;
      if(!u || !p){ errBox.textContent='Please enter username and password.'; return; }
      const tRes = await apiLogin('teacher', u, p);
      if(tRes.error){ errBox.textContent = tRes.error.message; return; }
      const teacherRow = tRes.user;
      SESSION = { role:'teacher', username:u, name:teacherRow.name, permissions:tRes.permissions.length?tRes.permissions:TEACHER_DEFAULT_PERMISSIONS };
      saveSession({ username:u });
      startAdminListeners();
    } else if(loginRole==='staff'){
      const u = document.getElementById('staffUserInput').value.trim();
      const p = document.getElementById('staffPassInput').value;
      if(!u || !p){ errBox.textContent='Please enter username and password.'; return; }
      const sRes = await apiLogin('staff', u, p);
      if(sRes.error){ errBox.textContent = sRes.error.message; return; }
      const staffRow = sRes.user;
      SESSION = { role:'staff', username:u, name:staffRow.name, permissions:sRes.permissions||[] };
      saveSession({ username:u });
      startAdminListeners();
    } else {
      const u = document.getElementById('adminUserInput').value.trim();
      const p = document.getElementById('adminPassInput').value;
      const aRes = await apiLogin('admin', u, p);
      if(aRes.error){ errBox.textContent = aRes.error.message; return; }
      DB.admin = { username:u };
      SESSION = { role:'admin', username:u };
      // Encrypt any personal details still stored in plain form. Safe to repeat.
      setTimeout(() => { apiCall({ action:'encrypt_existing' }).catch(()=>{}); }, 4000);
      saveSession({ username:u });
      startAdminListeners();
    }
    document.getElementById('loginScreen').style.display='none';
    document.getElementById('app').style.display='block';
    document.getElementById('app').classList.add('post-login');
    document.getElementById('appLoadingOverlay').classList.remove('hide');
    currentTab='dashboard';
    buildNav();
    renderPage();
    showWelcomeBanner();
    if(SESSION.role==='student'){ startAnnouncementsListener(); loadAnnouncements(); }
    if(SESSION.role==='student') hideAppLoadingOverlay();
    setTimeout(hideAppLoadingOverlay, 4000); // safety net — never leave the user stuck on the loading screen
  } catch(err){
    console.error(err);
    errBox.textContent='Could not reach the database. Check your internet connection and try again.';
  } finally{
    signInBtn.disabled = false; signInBtn.textContent='Sign In';
  }
}

function logout(){
  SESSION = null;
  clearSavedSession();
  stopAllListeners();
  document.getElementById('app').style.display='none';
  document.getElementById('app').classList.remove('post-login');
  document.getElementById('loginScreen').style.display='flex';
  document.getElementById('rollInput').value='';
  document.getElementById('passInput').value='';
  document.getElementById('teacherUserInput').value='';
  document.getElementById('teacherPassInput').value='';
  document.getElementById('staffUserInput').value='';
  document.getElementById('staffPassInput').value='';
  document.getElementById('adminUserInput').value='';
  document.getElementById('adminPassInput').value='';
}

function showWelcomeBanner(){
  const main = document.querySelector('.main');
  if(!main || !SESSION) return;
  
  const roleNames = { student:'Student', teacher:'Teacher', admin:'Director', staff:'Admin' };
  const roleName = roleNames[SESSION.role] || SESSION.role;
  const icons = { student:'🎓', teacher:'👨‍🏫', admin:'👔', staff:'📋' };
  const icon = icons[SESSION.role] || '👋';
  
  const banner = document.createElement('div');
  banner.className = 'welcome-banner';
  banner.innerHTML = `
    <div class="icon">${icon}</div>
    <div class="welcome-banner-content">
      <h3>Welcome to Inspired Model School &amp; GC Portal!</h3>
      <p>You're logged in as <strong>${roleName}</strong>. Your interface is ready to use.</p>
      <div class="role-badge ${SESSION.role}">${roleName} Access</div>
    </div>
  `;
  
  main.insertBefore(banner, main.firstChild);
  
  setTimeout(() => {
    banner.style.animation = 'fadeOut 0.5s var(--ease) forwards';
    setTimeout(() => banner.remove(), 500);
  }, 5000);
}

/* ================= NAV ================= */
const NAV_ICONS = {
  dashboard:'🏠', students:'👥', fees:'💰', attendance:'🗓️', results:'📊',
  materials:'📚', expenses:'💵', logins:'🔑', teachers:'🧑‍🏫', admins:'🛡️', account:'⚙️', profile:'👤', liveclass:'📹', studybuddy:'🤖', admissions:'📝', assignments:'📄', quizzes:'📝', gatescan:'📟', announce:'📢', reports:'📋', teachergate:'🏫'
};
const STAFF_PERMISSION_ITEMS = [
  ['students','Manage Students'],['fees','Fee Ledger'],['attendance','Attendance'],['gatescan','Gate Scanner'],
  ['results','Results'],['materials','Study Material'],['expenses','Expenses'],
  ['logins','Login Data'],['teachers','Manage Teachers'],['liveclass','Live Class'],['admins','Manage Admins'],['admissions','Admissions'],['assignments','Assignments'],['announce','Announcements'],
  ['quizzes','Online Quiz'],['reports','Reports'],['teachergate','Teacher Attendance']
];
const TEACHER_PERMISSION_ITEMS = STAFF_PERMISSION_ITEMS;
const TEACHER_DEFAULT_PERMISSIONS = ['students','attendance','results','materials','liveclass'];
/* Grouped navigation. Each group: [groupLabel, groupIcon, [ [key,label], ... ]].
   A plain [key,label] (not a group) renders as a standalone top-level item. */
let navGroupsOpen = JSON.parse(localStorage.getItem('ia_nav_open')||'{}');
function toggleNavGroup(id){
  navGroupsOpen[id] = !navGroupsOpen[id];
  localStorage.setItem('ia_nav_open', JSON.stringify(navGroupsOpen));
  buildNav();
}

function buildNav(){
  const nav = document.getElementById('navItems');
  const isMobile = window.matchMedia('(max-width:768px)').matches;

  // Build the allowed flat item list per role (same logic as before)
  let flat = [];
  if(SESSION.role==='student'){
    flat = [
      ['dashboard','Dashboard'],['fees','Fee Ledger'],['attendance','Attendance'],
      ['results','Results'],['materials','Study Material'],['assignments','Assignments'],['quizzes','Online Quiz'],['liveclass','Live Class'],['announce','Announcements'],['studybuddy','Inspired AI'],['profile','My Profile']
    ];
  } else if(SESSION.role==='teacher'){
    const allowedT = SESSION.permissions || TEACHER_DEFAULT_PERMISSIONS;
    flat = [['dashboard','Dashboard'], ...TEACHER_PERMISSION_ITEMS.filter(([key]) => allowedT.includes(key)), ['profile','My Profile']];
  } else if(SESSION.role==='staff'){
    const allowed = SESSION.permissions || [];
    flat = [['dashboard','Dashboard'], ...STAFF_PERMISSION_ITEMS.filter(([key]) => allowed.includes(key)), ['profile','My Profile']];
  } else {
    flat = [
      ['dashboard','Dashboard'],['students','Manage Students'],['fees','Fee Ledger'],
      ['attendance','Attendance'],['gatescan','Gate Scanner'],['results','Results'],['materials','Study Material'],['assignments','Assignments'],['quizzes','Online Quiz'],['liveclass','Live Class'],['announce','Announcements'],['expenses','Expenses'],['reports','Reports'],['teachergate','Teacher Attendance'],['logins','Login Data'],['teachers','Manage Teachers'],['admins','Manage Admins'],['admissions','Admissions'],['account','My Account']
    ];
  }

  // Phone: 4 primary tabs + More (everything else lives in a slide-up sheet)
  if(isMobile){
    const PREFERRED = {
      student: ['dashboard','fees','attendance','results'],
      teacher: ['dashboard','attendance','students','results'],
      staff:   ['dashboard','students','attendance','fees'],
      admin:   ['dashboard','students','fees','attendance']
    };
    const keys = flat.map(([k])=>k);
    const wanted = PREFERRED[SESSION.role] || PREFERRED.admin;
    let primary = wanted.filter(k => keys.includes(k)).slice(0,4);
    // if the role has fewer matches, top up in list order
    for(const k of keys){ if(primary.length>=4) break; if(!primary.includes(k)) primary.push(k); }

    const SHORT = { dashboard:'Home', students:'Students', fees:'Fees', attendance:'Attendance',
                    results:'Results', materials:'Material', assignments:'Tasks', quizzes:'Quiz',
                    liveclass:'Live', announce:'Notices', studybuddy:'AI', profile:'Profile',
                    gatescan:'Scanner', teachergate:'Staff', reports:'Reports', expenses:'Expenses',
                    teachers:'Teachers', admins:'Admins', admissions:'Admissions',
                    logins:'Logins', account:'Account' };

    // If everything fits in 5 slots, show them all and skip the More tab
    if(flat.length <= 5){
      primary = keys.slice(0,5);
      moreNavItems = [];
    } else {
      moreNavItems = flat.filter(([k]) => !primary.includes(k));
    }
    const inMore = moreNavItems.some(([k]) => k === currentTab);

    nav.innerHTML = primary.map(k => {
      const it = flat.find(([kk]) => kk === k) || [k,k];
      return `<div class="nav-item ${currentTab===k?'active':''}" onclick="goTab('${k}')">
        <span class="nav-icon">${NAV_ICONS[k]||'\u2022'}</span><span class="nav-label">${SHORT[k]||it[1]}</span>
      </div>`;
    }).join('') +
    (moreNavItems.length ? `<div class="nav-item ${inMore?'active':''}" onclick="openMoreSheet()">
       <span class="nav-icon">\u2630</span><span class="nav-label">More</span>
     </div>` : '');
    // fewer than 5 tabs? let them share the width evenly
    nav.style.gridTemplateColumns = 'repeat(' + (primary.length + (moreNavItems.length?1:0)) + ',1fr)';
    return;
  }

  // Desktop: organize into collapsible groups. Define the structure per role.
  const allowedKeys = new Set(flat.map(([k])=>k));
  const has = k => allowedKeys.has(k);
  const item = k => flat.find(([kk])=>kk===k);

  let structure;
  if(SESSION.role==='student'){
    structure = [
      item('dashboard'),
      ['Academics','📚', [item('results'),item('materials'),item('assignments'),item('quizzes'),item('liveclass')]],
      ['Attendance & Fees','🗓️', [item('attendance'),item('fees')]],
      item('announce'),
      item('studybuddy'),
      item('profile')
    ];
  } else if(SESSION.role==='admin' || (SESSION.role!=='student' && SESSION.role!=='teacher' && SESSION.role!=='staff')){
    structure = [
      item('dashboard'),
      ['Students','🧑‍🎓', [item('students'),item('fees'),item('admissions')]],
      ['Academics','📚', [item('results'),item('materials'),item('assignments'),item('quizzes'),item('liveclass')]],
      ['Attendance','🗓️', [item('attendance'),item('gatescan')]],
      item('announce'),
      ['Reports & Admin','📋', [item('reports'),item('teachergate'),item('expenses'),item('logins'),item('teachers'),item('admins')]],
      item('account')
    ];
  } else {
    // teacher / staff — group only what they're allowed to see
    const acads = [item('results'),item('materials'),item('assignments'),item('quizzes'),item('liveclass')].filter(Boolean);
    const stu = [item('students'),item('admissions')].filter(Boolean);
    const att = [item('attendance'),item('gatescan')].filter(Boolean);
    const admin = [item('reports'),item('teachergate'),item('expenses'),item('logins'),item('teachers'),item('admins')].filter(Boolean);
    structure = [ item('dashboard') ];
    if(stu.length) structure.push(['Students','🧑‍🎓', stu]);
    if(acads.length) structure.push(['Academics','📚', acads]);
    if(att.length) structure.push(['Attendance','🗓️', att]);
    if(has('announce')) structure.push(item('announce'));
    if(admin.length) structure.push(['Administration','🛡️', admin]);
    structure.push(item('profile'));
  }

  // Render
  const renderItem = ([key,label], nested) =>
    `<div class="nav-item ${nested?'nav-sub':''} ${currentTab===key?'active':''}" onclick="goTab('${key}')">
      <span class="nav-icon">${NAV_ICONS[key]||'•'}</span><span class="nav-label">${label}</span>
    </div>`;

  nav.innerHTML = structure.map(entry => {
    if(!entry) return '';
    // group?
    if(entry.length===3 && Array.isArray(entry[2])){
      const [glabel, gicon, children] = entry;
      const kids = children.filter(Boolean);
      if(!kids.length) return '';
      const gid = 'g_'+glabel.replace(/\W+/g,'');
      const childActive = kids.some(([k])=>k===currentTab);
      const open = navGroupsOpen[gid] !== undefined ? navGroupsOpen[gid] : childActive; // auto-open if a child is active
      return `<div class="nav-group ${open?'open':''}">
        <div class="nav-group-head" onclick="toggleNavGroup('${gid}')">
          <span class="nav-icon">${gicon}</span>
          <span class="nav-label">${glabel}</span>
          <span class="nav-caret">${open?'▾':'▸'}</span>
        </div>
        <div class="nav-group-body" style="${open?'':'display:none;'}">
          ${kids.map(it=>renderItem(it,true)).join('')}
        </div>
      </div>`;
    }
    // standalone item
    return renderItem(entry, false);
  }).join('');
  updateFloatingAi();
}
function goTab(tab){
  currentTab = tab;
  buildNav();
  renderPage();
  if(tab === 'announce') markAnnouncementsSeen();
  refreshBell();
  // land at the top of the new page instead of mid-scroll
  const m = document.querySelector('.main');
  if(m) m.scrollTop = 0;
  window.scrollTo(0, 0);
}
function openAiQuick(){ goTab('studybuddy'); }
function updateFloatingAi(){
  const btn = document.getElementById('floatingAiBtn');
  if(!btn) return;
  // Show the AI button for anyone who has the Inspired AI feature (students),
  // and hide it while already on the AI page.
  const hasAi = SESSION && SESSION.role==='student';
  if(hasAi && currentTab!=='studybuddy') btn.classList.add('show');
  else btn.classList.remove('show');
}
let __navResizeTimer=null;
window.addEventListener('resize', function(){
  clearTimeout(__navResizeTimer);
  __navResizeTimer = setTimeout(function(){ if(SESSION) buildNav(); }, 200);
});
/* ================= HELPERS ================= */
function fmtMoney(n){ return 'Rs. ' + Number(n||0).toLocaleString(); }
function getStudent(roll){
  if(SESSION && SESSION.role==='student' && DB.myStudent && DB.myStudent.roll===roll) return DB.myStudent;
  return DB.students.find(s=>s.roll===roll);
}
function attendancePct(student){
  if(!student.attendance.length) return 0;
  const present = student.attendance.filter(a=>a.status==='Present').length;
  return Math.round((present/student.attendance.length)*100);
}
function totalDue(student){
  return student.fees.filter(f=>f.status==='Due').reduce((sum,f)=>sum+Number(f.amount||0),0);
}
function resultPct(r){ return r.total ? Math.round((r.obtained/r.total)*100) : 0; }

/* ================= RENDER ROUTER ================= */
function feeWarningBannerHtml(status){
  return `<div class="card" style="background:#fff3cd; border:1px solid #ffc107; margin-bottom:16px;">
    <div style="color:#856404; font-size:14px;">
      <b>⚠️ 2nd Installment Fee Overdue</b><br>
      Your 2nd installment (Rs. 22,500) was due on ${status.dueDate.toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'})}.
      Your account will be <b>automatically blocked in ${status.daysUntilBlock} day${status.daysUntilBlock!==1?'s':''}</b> if this isn't paid.
      ${status.pendingReceiptUrl ? ' Your receipt has been submitted and is awaiting confirmation from the Director.' : ' Please pay and upload your receipt from the Fee Ledger page.'}
    </div>
  </div>`;
}
function renderPage(){
  const __c = document.getElementById('content');
  if(__c){ __c.classList.toggle('no-replay', renderPage._lastTab === currentTab); }
  renderPage._lastTab = currentTab;
  document.getElementById('whoBox').innerHTML = SESSION.role==='student'
    ? `Signed in as<br><b>${getStudent(SESSION.roll).name}</b>`
    : SESSION.role==='teacher'
    ? `Signed in as<br><b>${SESSION.name || SESSION.username}</b>`
    : SESSION.role==='staff'
    ? `Signed in as<br><b>${SESSION.name || SESSION.username}</b>`
    : `Signed in as<br><b>Director</b>`;

  const titles = {
    dashboard:'Dashboard', fees:'Fee Ledger', attendance:'Attendance', results:'Results',
    materials:'Study Material', profile:'My Profile', students:'Manage Students',
    expenses:'School Expenses', logins:'Login Data', teachers:'Manage Teachers', admins:'Manage Admins', account:'My Account', liveclass:'Live Class', studybuddy:'Inspired AI', admissions:'Admissions', assignments:'Assignments', quizzes:'Online Quiz', reports:'📋 Reports', announce:'Announcements', teachergate:'🏫 Teacher Attendance'
  };
  document.getElementById('pageTitle').textContent = titles[currentTab] || 'Dashboard';
  document.getElementById('breadcrumb').textContent =
    SESSION.role==='student' ? 'Student Portal' : SESSION.role==='teacher' ? 'Teacher Panel' : SESSION.role==='staff' ? 'Admin Panel' : 'Director Panel';
  document.getElementById('printPageBtn').classList.toggle('section-hidden', SESSION.role!=='admin' && SESSION.role!=='staff');

  const c = document.getElementById('content');
  if(SESSION.role==='student'){
    if(currentTab==='dashboard') c.innerHTML = renderStudentDashboard();
    else if(currentTab==='fees') c.innerHTML = renderStudentFees();
    else if(currentTab==='attendance') c.innerHTML = renderStudentAttendance();
    else if(currentTab==='results') c.innerHTML = renderStudentResults();
    else if(currentTab==='materials') c.innerHTML = renderMaterials(false);
    else if(currentTab==='assignments') c.innerHTML = renderStudentAssignments();
    else if(currentTab==='quizzes') c.innerHTML = renderStudentQuizzes();
    else if(currentTab==='liveclass') c.innerHTML = renderStudentLiveClass();
    else if(currentTab==='studybuddy') c.innerHTML = renderStudyBuddy();
    else if(currentTab==='announce') c.innerHTML = renderStudentAnnouncements();
    else if(currentTab==='profile') c.innerHTML = renderStudentProfile();
    if(loginFeeWarning) c.innerHTML = feeWarningBannerHtml(loginFeeWarning) + c.innerHTML;
  } else if(SESSION.role==='teacher'){
    const allowedT = SESSION.permissions || TEACHER_DEFAULT_PERMISSIONS;
    const canSeeT = (key) => allowedT.includes(key);
    if(currentTab==='dashboard') c.innerHTML = renderAdminDashboard();
    else if(currentTab==='students' && canSeeT('students')) c.innerHTML = renderAdminStudents();
    else if(currentTab==='fees') c.innerHTML = `<div class="card"><h3>Access Restricted</h3><p>Fee information is only visible to students and the Director.</p></div>`;
    else if(currentTab==='attendance' && canSeeT('attendance')) c.innerHTML = renderAdminAttendance();
    else if(currentTab==='gatescan' && canSeeT('attendance')) { c.innerHTML = renderGateScanner(); gateStartFocus(); }
    else if(currentTab==='results' && canSeeT('results')) c.innerHTML = renderAdminResults();
    else if(currentTab==='materials' && canSeeT('materials')) c.innerHTML = renderMaterials(true);
    else if(currentTab==='liveclass' && canSeeT('liveclass')) c.innerHTML = renderHostLiveClass();
    else if(currentTab==='expenses' && canSeeT('expenses')) c.innerHTML = renderAdminExpenses();
    else if(currentTab==='reports' && canSeeT('reports')) c.innerHTML = renderReports();
    else if(currentTab==='teachergate' && canSeeT('teachergate')) { c.innerHTML = renderTeacherGate(); teacherGateStartFocus(); }
    else if(currentTab==='quizzes' && canSeeT('quizzes')) c.innerHTML = renderAdminQuizzes();
    else if(currentTab==='logins' && canSeeT('logins')) c.innerHTML = renderAdminLogins();
    else if(currentTab==='teachers' && canSeeT('teachers')) c.innerHTML = renderAdminTeachers();
    else if(currentTab==='admins' && canSeeT('admins')) c.innerHTML = renderAdminAdmins();
    else if(currentTab==='admissions' && canSeeT('admissions')) c.innerHTML = renderAdminAdmissions();
    else if(currentTab==='assignments' && canSeeT('assignments')) c.innerHTML = renderAdminAssignments();
    else if(currentTab==='announce' && canSeeT('announce')) c.innerHTML = renderAdminAnnouncements();
    else if(currentTab==='quizzes') c.innerHTML = `<div class="card"><h3>Access Restricted</h3><p>You don't have permission to manage Online Quiz. Ask the Director to enable it.</p></div>`;
    else if(currentTab==='profile') c.innerHTML = renderTeacherProfile();
    else c.innerHTML = `<div class="card"><h3>Access Restricted</h3><p>You don't have permission to view this section. Contact the Director if you need access.</p></div>`;
  } else if(SESSION.role==='staff'){
    const allowed = SESSION.permissions || [];
    const canSee = (key) => allowed.includes(key);
    if(currentTab==='dashboard') c.innerHTML = renderAdminDashboard();
    else if(currentTab==='students' && canSee('students')) c.innerHTML = renderAdminStudents();
    else if(currentTab==='fees' && canSee('fees')) c.innerHTML = renderAdminFees();
    else if(currentTab==='fees') c.innerHTML = `<div class="card"><h3>Access Restricted</h3><p>You don't have permission to view fee information. Ask the Director to enable it.</p></div>`;
    else if(currentTab==='attendance' && canSee('attendance')) c.innerHTML = renderAdminAttendance();
    else if(currentTab==='gatescan' && canSee('attendance')) { c.innerHTML = renderGateScanner(); gateStartFocus(); }
    else if(currentTab==='results' && canSee('results')) c.innerHTML = renderAdminResults();
    else if(currentTab==='materials' && canSee('materials')) c.innerHTML = renderMaterials(true);
    else if(currentTab==='liveclass' && canSee('liveclass')) c.innerHTML = renderHostLiveClass();
    else if(currentTab==='expenses' && canSee('expenses')) c.innerHTML = renderAdminExpenses();
    else if(currentTab==='logins' && canSee('logins')) c.innerHTML = renderAdminLogins();
    else if(currentTab==='teachers' && canSee('teachers')) c.innerHTML = renderAdminTeachers();
    else if(currentTab==='admins' && canSee('admins')) c.innerHTML = renderAdminAdmins();
    else if(currentTab==='admissions' && canSee('admissions')) c.innerHTML = renderAdminAdmissions();
    else if(currentTab==='assignments' && canSee('assignments')) c.innerHTML = renderAdminAssignments();
    else if(currentTab==='announce' && canSee('announce')) c.innerHTML = renderAdminAnnouncements();
    else if(currentTab==='quizzes' && canSee('quizzes')) c.innerHTML = renderAdminQuizzes();
    else if(currentTab==='reports' && canSee('reports')) c.innerHTML = renderReports();
    else if(currentTab==='teachergate' && canSee('teachergate')) { c.innerHTML = renderTeacherGate(); teacherGateStartFocus(); }
    else if(currentTab==='profile') c.innerHTML = renderStaffProfile();
    else c.innerHTML = `<div class="card"><h3>Access Restricted</h3><p>You don't have permission to view this section. Contact the Director if you need access.</p></div>`;
  } else {
    if(currentTab==='dashboard') c.innerHTML = renderAdminDashboard();
    else if(currentTab==='students') c.innerHTML = renderAdminStudents();
    else if(currentTab==='fees') c.innerHTML = renderAdminFees();
    else if(currentTab==='attendance') c.innerHTML = renderAdminAttendance();
    else if(currentTab==='gatescan') { c.innerHTML = renderGateScanner(); gateStartFocus(); }
    else if(currentTab==='results') c.innerHTML = renderAdminResults();
    else if(currentTab==='materials') c.innerHTML = renderMaterials(true);
    else if(currentTab==='liveclass') c.innerHTML = renderHostLiveClass();
    else if(currentTab==='expenses') c.innerHTML = renderAdminExpenses();
    else if(currentTab==='logins') c.innerHTML = renderAdminLogins();
    else if(currentTab==='teachers') c.innerHTML = renderAdminTeachers();
    else if(currentTab==='admins') c.innerHTML = renderAdminAdmins();
    else if(currentTab==='admissions') c.innerHTML = renderAdminAdmissions();
    else if(currentTab==='assignments') c.innerHTML = renderAdminAssignments();
    else if(currentTab==='announce') c.innerHTML = renderAdminAnnouncements();
    else if(currentTab==='quizzes') c.innerHTML = renderAdminQuizzes();
    else if(currentTab==='account') c.innerHTML = renderAdminAccount();
    else if(currentTab==='reports') c.innerHTML = renderReports();
    else if(currentTab==='teachergate') { c.innerHTML = renderTeacherGate(); teacherGateStartFocus(); }
  }
}

/* ================= STUDENT VIEWS ================= */
function renderStudentDashboard(){
  const s = getStudent(SESSION.roll);
  const pct = attendancePct(s);
  const due = totalDue(s);
  const avgResult = s.results.length ? Math.round(s.results.reduce((sum,r)=>sum+resultPct(r),0)/s.results.length) : 0;

  const att = s.attendance || [];
  const total = att.length;
  const countOf = (st) => total ? Math.round((att.filter(a=>a.status===st).length/total)*100) : 0;
  const presentPct = countOf('Present'), absentPct = countOf('Absent'), leavePct = countOf('Leave');
  const presentDays = att.filter(a=>a.status==='Present').length;

  // initials for the avatar
  const initials = (s.name||'').trim().split(/\s+/).slice(0,2).map(w=>w[0]||'').join('').toUpperCase() || '—';

  // unpaid months -> subtitle under Fee Status
  const dueFees = (s.fees||[]).filter(f=>f.status==='Due');
  const feeSub = due > 0
    ? fmtMoney(due) + (dueFees.length ? ' \u00b7 ' + dueFees.length + ' month' + (dueFees.length>1?'s':'') : '')
    : 'All dues cleared';

  // rank within the same class (only students who have results)
  let rankSub = 'No results yet';
  if(s.results.length){
    const peers = (DB.students||[])
      .filter(x => x.class === s.class && (x.results||[]).length)
      .map(x => ({ roll:x.roll, avg: x.results.reduce((sum,r)=>sum+resultPct(r),0)/x.results.length }))
      .sort((a,b) => b.avg - a.avg);
    const pos = peers.findIndex(x => x.roll === s.roll) + 1;
    if(pos > 0) rankSub = 'Rank ' + pos + ' of ' + peers.length;
  }

  const attLabel = total ? presentDays + ' of ' + total + ' days' : 'No records yet';

  const quickLinks = [
    ['fees','\u{1F4B0}','Fee Ledger'], ['attendance','\u{1F5D3}\uFE0F','Attendance'], ['results','\u{1F4CA}','Results'],
    ['materials','\u{1F4DA}','Study Material'], ['announce','\u{1F4E2}','Announcements'], ['profile','\u{1F464}','My Profile']
  ];

  return `
  <div class="sd-wrap">
    <div class="sd-user">
      <div style="min-width:0;">
        <div class="sd-label">Signed in as</div>
        <div class="sd-name">${s.name}</div>
        <div class="sd-sub">${s.class} \u00b7 ${s.roll}</div>
      </div>
      <div class="sd-avatar">${initials}</div>
    </div>

    <div class="sd-grid">
      <div class="sd-cell">
        <div class="sd-label">Roll Number</div>
        <div class="sd-big sd-green sd-mono">${s.roll}</div>
        <div class="sd-sub">Session 2026</div>
      </div>
      <div class="sd-cell">
        <div class="sd-label">Fee Status</div>
        <div class="sd-big ${due>0?'sd-orange':'sd-green'}">${due>0?'Due':'Paid'}</div>
        <div class="sd-sub">${feeSub}</div>
      </div>
      <div class="sd-cell">
        <div class="sd-label">Attendance</div>
        <div class="sd-big sd-green">${pct}%</div>
        <div class="sd-sub">${attLabel}</div>
      </div>
      <div class="sd-cell">
        <div class="sd-label">Average Score</div>
        <div class="sd-big sd-green">${avgResult}%</div>
        <div class="sd-sub">${rankSub}</div>
      </div>
    </div>

    <div class="sd-section">
      <div class="sd-label" style="margin-bottom:6px;">Attendance breakdown</div>
      <div class="sd-bd"><span class="sq" style="background:var(--primary);"></span>Present<b>${presentPct}%</b></div>
      <div class="sd-bd"><span class="sq" style="background:#FF8A65;"></span>Absent<b>${absentPct}%</b></div>
      <div class="sd-bd"><span class="sq" style="background:#4DD0E1;"></span>Leave<b>${leavePct}%</b></div>
    </div>
  </div>

  <div class="card">
    <h3>Quick Access</h3>
    <div class="quick-grid">
      ${quickLinks.map(([key,icon,label]) => `
        <div class="quick-tile" onclick="goTab('${key}')">
          <div class="quick-icon">${icon}</div>
          <div class="quick-label">${label}</div>
        </div>`).join('')}
    </div>
  </div>`;
}

function renderStudentFees(){
  const s = getStudent(SESSION.roll);
  const rows = s.fees.map(f => `
    <tr class="ledger-row">
      <td>${f.month}</td>
      <td><span class="tag ${f.status==='Paid'?'paid':'due'}">${f.status}</span>${f.pendingReceiptUrl ? ' <span class="tag" style="background:#fff3cd;color:#856404;">Receipt Pending Review</span>' : ''}</td>
      <td>${f.date || '—'}</td>
    </tr>`).join('');
  const feeDisplay = ['teacher', 'staff'].includes(SESSION.role) ? '<div style="padding:20px; background:#fff3cd; border:1px solid #ffc107; border-radius:10px; text-align:center; color:#856404;">📋 Fee information is only visible to students and the Director.</div>' : `<table><thead><tr><th>Month / Installment</th><th>Status</th><th>Paid On</th></tr></thead><tbody>${rows || '<tr><td colspan="3" class="empty-state">No fee records yet.</td></tr>'}</tbody></table>`;
  let inst2Section = '';
  if(SESSION.role==='student'){
    const status = getInstallment2Status(s);
    if(status){
      inst2Section = `<div class="card">
        <h3>2nd Installment Payment</h3>
        ${status.pendingReceiptUrl
          ? `<p style="color:#856404;">✅ Your receipt has been uploaded and is awaiting confirmation from the Director. You'll see the status update here once it's reviewed.</p>`
          : `<p style="font-size:13.5px; color:var(--ink-soft);">Amount due: <b>Rs. 22,500</b> · Due date: <b>${status.dueDate.toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'})}</b>${status.isOverdue ? ` · <span style="color:var(--due);">Overdue — account will be blocked in ${status.daysUntilBlock} day${status.daysUntilBlock!==1?'s':''} if unpaid</span>` : ''}</p>
          <label>Upload Receipt for 2nd Installment (Rs. 22,500)</label>
          <input type="file" id="inst2_receipt" accept="image/*,.pdf" capture="environment">
          <div id="inst2_status" style="margin-top:10px; font-size:13.5px;"></div>
          <button class="btn gold" style="margin-top:10px;" onclick="uploadInstallment2Receipt()">Submit Receipt</button>`}
      </div>`;
    }
  }
  return `<div class="card"><h3>Fee Ledger</h3>${feeDisplay}</div>${inst2Section}`;
}
async function uploadInstallment2Receipt(){
  const fileInput = document.getElementById('inst2_receipt');
  const statusEl = document.getElementById('inst2_status');
  if(!fileInput.files || !fileInput.files[0]){ statusEl.textContent = 'Please choose a file first.'; return; }
  const file = fileInput.files[0];
  statusEl.textContent = 'Uploading...';
  try{
    const path = `inst2_${SESSION.roll}_${Date.now()}_${file.name}`;
    const storedPath = await uploadWithProgress(path, file, (pct) => { statusEl.textContent = `Uploading… ${pct}%`; }, 'receipts');
    const receiptUrl = `${DATA_URL}/storage/v1/object/public/receipts/${storedPath}`;
    statusEl.textContent = 'Verifying receipt...';
    const checkResult = await checkReceiptImage(receiptUrl, 22500);
    if(checkResult && checkResult.valid === false){
      statusEl.textContent = checkResult.amountMismatch
        ? checkResult.reason
        : 'This doesn\'t look like a valid Easypaisa transaction slip or Inspired Model School &amp; GC fee receipt. Please upload a clear photo or screenshot of one of those specifically.';
      return;
    }
    const s = getStudent(SESSION.roll);
    const updatedFees = s.fees.map(f => f.month==='Installment 2' ? { ...f, pendingReceiptUrl:receiptUrl } : f);
    const { error } = await sb.from('students').update({ fees: updatedFees }).eq('roll', SESSION.roll);
    if(error) throw error;
    statusEl.textContent = '✅ Receipt submitted! Awaiting confirmation from the Director.';
    setTimeout(() => renderPage(), 1200);
  } catch(err){
    console.error(err);
    statusEl.textContent = '⚠️ Could not upload receipt. Please check your connection and try again.';
  }
}

function renderStudentAttendance(){
  const s = getStudent(SESSION.roll);
  const rows = s.attendance.slice().reverse().map(a => `
    <tr class="ledger-row"><td>${a.date}</td><td><span class="tag ${a.status.toLowerCase()}">${a.status}</span></td></tr>`).join('');
  const dayBreakdown = attendanceByDay(s.attendance);
  return `<div class="card"><h3>Attendance Record — ${attendancePct(s)}% Present</h3>
    <table><thead><tr><th>Date</th><th>Status</th></tr></thead>
    <tbody>${rows || '<tr><td colspan="2" class="empty-state">No attendance marked yet.</td></tr>'}</tbody></table>
    ${dayBreakdown}
    ${renderDirectorNote(academySettings.attendanceNote)}
  </div>`;
}

function renderStudentResults(){
  const s = getStudent(SESSION.roll);
  const rows = s.results.map(r => `
    <tr class="ledger-row"><td>${r.exam}</td><td>${r.subject}</td><td>${r.obtained}/${r.total}</td><td>${resultPct(r)}%</td></tr>`).join('');
  const myQuizAttempts = (DB.quizAttempts||[]).slice().sort((a,b)=>new Date(b.submittedAt)-new Date(a.submittedAt));
  const quizRows = myQuizAttempts.map(a => {
    const quiz = (DB.quizzes||[]).find(q=>q.id===a.quizId);
    return `<tr class="ledger-row">
      <td>${quiz ? quiz.title : 'Quiz'}</td><td>${quiz ? quiz.subject : '—'}</td>
      <td>${a.score}/${a.total}</td><td>${a.percentage}%</td>
      <td>${new Date(a.submittedAt).toLocaleDateString()}</td>
    </tr>`;
  }).join('');
  return `<div class="card"><h3>Results</h3>
    <table><thead><tr><th>Exam</th><th>Subject</th><th>Marks</th><th>%</th></tr></thead>
    <tbody>${rows || '<tr><td colspan="4" class="empty-state">No results published yet.</td></tr>'}</tbody></table>
    <div class="actions-row" style="margin-top:14px;"><button class="btn gold" onclick="generateReportCard('${SESSION.roll}')">🖨 Download / Print Report Card</button></div>
  </div>
  <div class="card"><h3>Online Quiz Results</h3>
    <table><thead><tr><th>Quiz</th><th>Subject</th><th>Score</th><th>%</th><th>Date</th></tr></thead>
    <tbody>${quizRows || '<tr><td colspan="5" class="empty-state">No quizzes attempted yet.</td></tr>'}</tbody></table>
  </div>`;
}

function changeUsernameFormHtml(role, currentUsername){
  return `
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Current Username</label>
    <input value="${currentUsername||''}" disabled style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:12px;background:var(--cream-2);color:var(--ink-soft);">
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">New Username</label>
    <input id="un_new" style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:12px;">
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Current Password (to confirm it's you)</label>
    <input id="un_password" type="password" style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:14px;">
    <div id="un_error" style="color:#a4302a;font-size:13px;margin-bottom:10px;"></div>
    <div class="actions-row"><button class="btn gold" onclick="submitUsernameChange('${role}')">Update Username</button></div>
  `;
}
async function submitUsernameChange(role){
  const errBox = document.getElementById('un_error');
  errBox.textContent='';
  const newUsername = document.getElementById('un_new').value.trim();
  const password = document.getElementById('un_password').value;
  if(!newUsername || !password){ errBox.textContent='Please fill in both fields.'; return; }
  if(/\s/.test(newUsername)){ errBox.textContent='Username cannot contain spaces.'; return; }
  try{
    const whoami = (role==='admin') ? (DB.admin.username || SESSION.username) : SESSION.username;
    const confirmed = await apiVerifyOwnPassword(role, whoami, password);
    if(!confirmed){ errBox.textContent='Password is incorrect.'; return; }
    if(role==='teacher'){
      if(newUsername !== SESSION.username && DB.teachers.some(x=>x.username.toLowerCase()===newUsername.toLowerCase())){
        errBox.textContent='That username is already taken by another teacher.'; return;
      }
      const { error } = await sb.from('teachers').update({ username: newUsername }).eq('username', SESSION.username);
      if(error) throw error;
      SESSION.username = newUsername;
    } else if(role==='staff'){
      if(newUsername !== SESSION.username && DB.admins.some(x=>x.username.toLowerCase()===newUsername.toLowerCase())){
        errBox.textContent='That username is already taken by another admin.'; return;
      }
      const { error } = await sb.from('admins').update({ username: newUsername }).eq('username', SESSION.username);
      if(error) throw error;
      SESSION.username = newUsername;
    } else {
      const { error } = await sb.from('admin_meta').update({ username: newUsername }).eq('id', 1);
      if(error) throw error;
      DB.admin.username = newUsername;
    }
    alert(`Username updated to "${newUsername}". Use this the next time you log in.`);
    renderPage();
  } catch(err){ console.error(err); errBox.textContent = 'Could not update username: ' + err.message; }
}
function changePasswordFormHtml(role){
  return `
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Current Password</label>
    <input id="cp_current" type="password" style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:12px;">
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">New Password</label>
    <input id="cp_new" type="password" style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:12px;">
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Confirm New Password</label>
    <input id="cp_confirm" type="password" style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:14px;">
    <div id="cp_error" style="color:#a4302a;font-size:13px;margin-bottom:10px;"></div>
    <div class="actions-row"><button class="btn gold" onclick="submitPasswordChange('${role}')">Update Password</button></div>
  `;
}
async function submitPasswordChange(role){
  const errBox = document.getElementById('cp_error');
  errBox.textContent='';
  const current = document.getElementById('cp_current').value;
  const next = document.getElementById('cp_new').value;
  const confirm_ = document.getElementById('cp_confirm').value;
  if(!current || !next || !confirm_){ errBox.textContent='Please fill in all fields.'; return; }
  if(next !== confirm_){ errBox.textContent='New password and confirmation do not match.'; return; }
  if(next.length < 6){ errBox.textContent='New password should be at least 6 characters.'; return; }
  try{
    // The server checks the current password and writes the new one. The
    // browser never sees any stored password.
    const r = await apiChangePassword(current, next);
    if(!r.ok){ errBox.textContent = r.error.message; return; }
    document.getElementById('cp_current').value='';
    document.getElementById('cp_new').value='';
    document.getElementById('cp_confirm').value='';
    if(SESSION) SESSION.defaultPassword = false;
    saveSession({ defaultPassword:false });
    alert('Password updated successfully.');
  } catch(err){
    console.error(err);
    errBox.textContent='Could not update password: ' + err.message;
  }
}

/* ================= INSPIRED AI (Puter.js powered) ================= */
let sbHistory = [];
let sbSending = false;

function sbBuildSystemPrompt(){
  return `You are "Inspired AI", a friendly and patient AI tutor for students of Inspired Model School &amp; Girl College Larkana (pre-medical and pre-engineering coaching, MDCAT/ECAT preparation), two educational institutions in Larkana, Sindh, Pakistan. Your students range from young school children to Class XII intermediate students.

You help with any subject in the curriculum, including Physics, Chemistry, Biology, Mathematics, English, Computer Science, and Urdu/Islamiyat, at levels from matriculation through MDCAT/ECAT preparation, as well as general study skills, exam preparation strategy, and time management.

Guidelines:
- Explain concepts clearly and step by step, using simple language and relatable, everyday examples familiar to a Pakistani audience.
- Match your explanation depth to the student's apparent level - simpler for younger school students, more rigorous for intermediate/MDCAT-ECAT students.
- If a student pastes a full MCQ or numerical/problem and just wants the final answer, do not simply give the answer. Instead, guide them through the reasoning and ask them to attempt the next step themselves. Give the final answer only after they've engaged with the reasoning, or if they explicitly say they've tried and are still stuck.
- Use short paragraphs and occasional simple formulas or diagrams described in words. Avoid overly long responses - aim for clarity over length.
- Be encouraging and warm, like a supportive teacher.
- You may use both English and simple Urdu/Roman Urdu phrasing if a student writes in Roman Urdu or Urdu, to make explanations more relatable.`;
}

function sbMessagesHtml(){
  if(!sbHistory.length){
    return `<div class="sb-msg sb-note">Ask any question from your syllabus to get started.</div>`;
  }
  return sbHistory.map(m => {
    if(m.role==='user'){
      return `<div class="sb-msg sb-student">${escapeHtml(m.content)}</div>`;
    } else {
      return `<div class="sb-msg sb-buddy"><span class="sb-label">Inspired AI</span>${escapeHtml(m.content)}</div>`;
    }
  }).join('');
}
function escapeHtml(str){
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
function renderStudyBuddy(){
  return `
  <div class="card sb-fullscreen-card">
    <h3>Inspired AI</h3>
    <div class="sb-chat-window sb-fullscreen-chat" id="sbChatWindow">${sbMessagesHtml()}</div>
    <div class="sb-footer">
      <textarea class="sb-input" id="sbUserInput" placeholder="Type your question here..."></textarea>
      <button class="sb-send-btn" id="sbSendBtn" onclick="sbSendMessage(document.getElementById('sbUserInput').value)">Send</button>
    </div>
  </div>`;
}
function sbScrollToBottom(){
  const w = document.getElementById('sbChatWindow');
  if(w) w.scrollTop = w.scrollHeight;
}
function sbShowTyping(){
  const w = document.getElementById('sbChatWindow');
  if(!w) return;
  const div = document.createElement('div');
  div.className = 'sb-typing';
  div.id = 'sbTypingIndicator';
  div.textContent = 'Inspired AI is thinking...';
  w.appendChild(div);
  sbScrollToBottom();
}
function sbHideTyping(){
  const t = document.getElementById('sbTypingIndicator');
  if(t) t.remove();
}
async function sbSendMessage(text){
  if(!text || !text.trim() || sbSending) return;
  if(typeof puter === 'undefined'){
    alert('The Inspired AI service could not load. Please check your internet connection and refresh the page.');
    return;
  }
  sbSending = true;
  const sendBtn = document.getElementById('sbSendBtn');
  const input = document.getElementById('sbUserInput');
  if(sendBtn) sendBtn.disabled = true;

  sbHistory.push({ role:'user', content:text });
  const w = document.getElementById('sbChatWindow');
  if(w){
    const noteEl = w.querySelector('.sb-note');
    if(noteEl) noteEl.remove();
    const div = document.createElement('div');
    div.className = 'sb-msg sb-student';
    div.textContent = text;
    w.appendChild(div);
  }
  if(input) input.value = '';
  sbScrollToBottom();
  sbShowTyping();

  try{
    const messages = [
      { role:'system', content: sbBuildSystemPrompt() },
      ...sbHistory
    ];
    const response = await puter.ai.chat(messages, { model: 'claude-sonnet-5' });
    let replyText = '';
    if(response && response.message && response.message.content){
      const c = response.message.content;
      replyText = Array.isArray(c) ? c.map(b=>b.text||'').filter(Boolean).join('\n') : String(c);
    } else if(typeof response === 'string'){
      replyText = response;
    }
    if(!replyText) replyText = "Sorry, I couldn't process that. Please try asking again.";
    sbHideTyping();
    sbHistory.push({ role:'assistant', content:replyText });
    if(w){
      const div = document.createElement('div');
      div.className = 'sb-msg sb-buddy';
      const label = document.createElement('span');
      label.className = 'sb-label';
      label.textContent = 'Inspired AI';
      div.appendChild(label);
      div.appendChild(document.createTextNode(replyText));
      w.appendChild(div);
    }
    sbScrollToBottom();
  } catch(err){
    console.error(err);
    sbHideTyping();
    if(w){
      const div = document.createElement('div');
      div.className = 'sb-msg sb-buddy';
      div.textContent = "Something went wrong connecting to the assistant. Please check your connection and try again.";
      w.appendChild(div);
    }
  } finally {
    sbSending = false;
    if(sendBtn) sendBtn.disabled = false;
  }
}

/* ================= ASSIGNMENTS ================= */
function renderStudentAssignments(){
  const s = getStudent(SESSION.roll);
  const mine = DB.assignments || [];
  const rows = mine.map(a => `
    <div class="card" style="background:var(--light-gray); margin-bottom:14px;">
      <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:8px;">
        <div>
          <b>${a.title}</b> <span style="color:var(--ink-soft); font-size:13px;">— ${a.subject}</span><br>
          <span style="font-size:12px; color:var(--ink-soft);">Submitted: ${new Date(a.submittedAt).toLocaleString()}</span>
        </div>
        <span class="tag ${a.status==='Reviewed'?'paid':'due'}">${a.status}</span>
      </div>
      ${a.fileUrl ? `<div style="margin-top:8px;"><a href="${a.fileUrl}" target="_blank" rel="noopener" class="btn small">📄 View My Submission</a></div>` : ''}
      ${a.aiFeedback ? `<div style="margin-top:10px; background:var(--light-gray); border-left:4px solid var(--gold); padding:10px 12px; font-size:13.5px;"><b>Inspired AI Feedback${a.aiMarks!==null && a.aiMarks!==undefined ? ' — Score: '+a.aiMarks+'/10' : ''}${a.aiPercentage!==null && a.aiPercentage!==undefined ? ' ('+a.aiPercentage+'%)' : ''}:</b><br>${a.aiFeedback}</div>` : ''}
      ${a.aiPlagiarismFlag ? `<div style="margin-top:8px; background:var(--light-gray); border-left:4px solid var(--due); padding:10px 12px; font-size:13.5px; color:var(--due);"><b>⚠ Possible Originality Concern:</b><br>${a.aiPlagiarismNote || 'This submission may not be the student\'s own original work — please review manually.'}</div>` : ''}
      ${a.teacherComment ? `<div style="margin-top:10px; background:var(--light-gray); border-left:4px solid var(--ok); padding:10px 12px; font-size:13.5px; color:var(--ink);"><b>Teacher's Comment:</b><br>${a.teacherComment}</div>` : ''}
      <div class="actions-row" style="margin-top:10px;"><button class="btn small danger" onclick="deleteAssignment(${a.id})">Delete</button></div>
    </div>`).join('');
  return `
  ${renderDirectorNote(academySettings.assignmentsNote)}
  <div class="card">
    <h3>Submit an Assignment</h3>
    <div class="row2">
      <div><label>Subject</label><input id="asg_subject" placeholder="e.g. Physics"></div>
      <div><label>Title</label><input id="asg_title" placeholder="e.g. Chapter 3 Homework"></div>
    </div>
    <label>File (photo, PDF, Word, or Excel of your work)</label>
    <input id="asg_file" type="file" accept="image/*,.pdf,.doc,.docx" style="margin-bottom:14px;">
    <div id="asg_progress_wrap" class="section-hidden" style="margin-bottom:14px;">
      <div style="background:var(--cream-2); border-radius:10px; height:16px; overflow:hidden;">
        <div id="asg_progress_bar" style="height:100%; width:0%; background:linear-gradient(90deg, var(--maroon), var(--gold)); transition:width 0.15s;"></div>
      </div>
      <div id="asg_progress_text" style="font-size:12px; color:var(--ink-soft); margin-top:4px; text-align:center;">0%</div>
    </div>
    <div class="actions-row"><button class="btn gold" onclick="submitAssignment()">Submit Assignment</button></div>
  </div>
  <div class="card"><h3>My Submissions (${mine.length})</h3>
    ${rows || '<div class="empty-state">No assignments submitted yet.</div>'}
  </div>`;
}
async function extractAssignmentFileText(file){
  const name = file.name.toLowerCase();
  if(name.endsWith('.doc') && !name.endsWith('.docx')){
    return { unsupported: true, message: 'This is an older .doc file, which can\'t be read directly for AI review. Please save it as .docx in Word (or Google Docs) if you\'d like AI feedback — your teacher can still review the file either way.' };
  }
  if(name.endsWith('.docx')){
    const buf = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer: buf });
    return { text: result.value };
  }
  if(name.endsWith('.xlsx') || name.endsWith('.xls')){
    return { unsupported: true, message: 'Spreadsheets can\'t be submitted as assignments. Please save your work as a PDF, a Word document (.docx) or a photo and upload that instead.' };
  }
  return null; // image or PDF — handled via vision instead
}
function buildAssignmentReviewPrompt(subject, title, contentDescription){
  return `You are "Inspired AI", reviewing a student's homework/assignment submission for the subject "${subject}", titled "${title}". ${contentDescription}

Respond with ONLY a JSON object, no other text, in exactly this format:
{"marks": a whole number from 0 to 10, "percentage": a whole number from 0 to 100 representing the overall quality/correctness/completeness as a percentage, "feedback": "3-5 sentences of brief, constructive feedback — mention what looks correct or well done, point out anything incomplete, unclear, or possibly incorrect, and suggest one thing to improve", "plagiarismConcern": true or false, "plagiarismNote": "one short sentence explaining why, only if plagiarismConcern is true, otherwise an empty string"}

For plagiarismConcern, flag it true only if something looks genuinely suspicious for a student's own work — for example: text that reads exactly like a printed textbook or answer key rather than a student's own writing/wording, or content that looks copy-pasted rather than authored. Do NOT flag it just because the work is good — high-quality correct work is not itself suspicious. This is a rough check, not a definitive plagiarism verdict, so only flag clear, obvious cases.

Be encouraging and age-appropriate for a school student. Grade leniently, not strictly — give credit for the correct core idea even if the wording, formatting, or minor details aren't perfect, and don't penalize small mistakes heavily. Still give an honest score reflecting genuine effort and understanding — don't give everyone a high score regardless of quality. If the content isn't legible/readable or doesn't look like actual academic work, give marks: 0, percentage: 0, and say so honestly in the feedback instead of guessing.`;
}
function parseAssignmentAiResponse(response){
  let text = '';
  if(typeof response === 'string') text = response;
  else if(response && response.message && response.message.content){
    const c = response.message.content;
    text = Array.isArray(c) ? c.map(b=>b.text||'').filter(Boolean).join('') : String(c);
  }
  const match = text.match(/\{[\s\S]*\}/);
  if(!match) return { feedback: text || null, marks:null, percentage:null, plagiarismFlag:false, plagiarismNote:null };
  const parsed = JSON.parse(match[0]);
  return {
    feedback: parsed.feedback || null,
    marks: (typeof parsed.marks === 'number') ? Math.max(0, Math.min(10, Math.round(parsed.marks))) : null,
    percentage: (typeof parsed.percentage === 'number') ? Math.max(0, Math.min(100, Math.round(parsed.percentage))) : null,
    plagiarismFlag: parsed.plagiarismConcern === true,
    plagiarismNote: parsed.plagiarismConcern === true ? (parsed.plagiarismNote || null) : null
  };
}
function buildAnswerKeyMatchPrompt(subject, title, answerKey, contentDescription){
  return `You are grading a student's test submission for the subject "${subject}", titled "${title}", using an official answer key provided by the Director.

ANSWER KEY (correct answers, one per question):
"""
${answerKey}
"""

${contentDescription}

The student has only submitted their answer choices (e.g. "1A, 2B, 3C") with no written work — just mark each answer against the key. Do NOT write an explanation or feedback paragraph. Be lenient, not strict: if the student's answer clearly corresponds to the same option as the key (allowing for minor formatting differences like spacing, punctuation, or case), count it correct.

Respond with ONLY a JSON object, no other text, in exactly this format:
{"totalQuestions": total number of questions in the answer key, "correctCount": how many the student got right, "percentage": whole number 0-100 (correctCount/totalQuestions as a percentage), "marks": whole number 0-10 proportional to the percentage, "feedback": "Score: X/Y correct.", "plagiarismConcern": false, "plagiarismNote": ""}

The "feedback" field must be ONLY the short score line shown above — no additional commentary, no per-question breakdown, no encouragement text.`;
}
async function submitAssignment(){
  const subject = document.getElementById('asg_subject').value.trim();
  const title = document.getElementById('asg_title').value.trim();
  const fileInput = document.getElementById('asg_file');
  if(!subject || !title){ alert('Please enter a subject and title.'); return; }
  if(!fileInput.files || !fileInput.files[0]){ alert('Please choose a file to upload.'); return; }
  const s = getStudent(SESSION.roll);
  const btn = document.querySelector('button[onclick="submitAssignment()"]');
  const progWrap = document.getElementById('asg_progress_wrap');
  const progBar = document.getElementById('asg_progress_bar');
  const progText = document.getElementById('asg_progress_text');
  btn.disabled = true; btn.textContent = 'Submitting...';
  try{
    const file = fileInput.files[0];
    const path = `${Date.now()}_${file.name}`;
    progWrap.classList.remove('section-hidden');
    const storedAsgPath = await uploadWithProgress(path, file, (pct) => {
      progBar.style.width = pct + '%';
      progText.textContent = pct + '% uploaded' + (pct===100 ? ' — Inspired AI is reviewing your work...' : '');
    }, 'assignments');
    const fileUrl = `${DATA_URL}/storage/v1/object/public/assignments/${storedAsgPath || path}`;

    let aiFeedback = null, aiMarks = null, aiPercentage = null, aiPlagiarismFlag = null, aiPlagiarismNote = null;
    if(typeof puter !== 'undefined'){
      try{
        const matchingKey = (DB.answerKeys||[]).find(k => k.subject.toLowerCase()===subject.toLowerCase() && k.title.toLowerCase()===title.toLowerCase());
        const extracted = await extractAssignmentFileText(file);
        if(extracted && extracted.unsupported){
          aiFeedback = extracted.message;
        } else if(matchingKey){
          // An answer key exists for this exact Subject + Title — grade against it.
          if(extracted && extracted.text && isAnswerOnlyFormat(extracted.text)){
            // Student submitted only answer choices (e.g. "1A, 2B, 3C") — grade locally,
            // no AI call needed, no explanation, lenient matching against the Director's key.
            const graded = autoGradeAnswers(extracted.text, matchingKey.answerKey);
            aiFeedback = `Score: ${graded.correct}/${graded.total} correct.`;
            aiMarks = graded.total ? Math.round((graded.correct/graded.total)*10) : null;
            aiPercentage = graded.pct;
            aiPlagiarismFlag = false; aiPlagiarismNote = null;
          } else {
            const contentDescription = (extracted && extracted.text)
              ? `Here is the student's submitted answers (extracted text):\n\n"""${extracted.text.slice(0, 6000)}"""`
              : `Look at the attached image/document — it contains the student's submitted answers.`;
            const prompt = buildAnswerKeyMatchPrompt(subject, title, matchingKey.answerKey, contentDescription);
            let response;
            if(extracted && extracted.text){
              try{ response = await puter.ai.chat(prompt, { model: 'gpt-5.4-nano' }); }
              catch(e){ response = await puter.ai.chat(prompt); }
            } else {
              try{ response = await puter.ai.chat(prompt, fileUrl, { model: 'gpt-5.4-nano' }); }
              catch(e){ response = await puter.ai.chat(prompt, fileUrl); }
            }
            const parsed = parseAssignmentAiResponse(response);
            aiFeedback = parsed.feedback; aiMarks = parsed.marks; aiPercentage = parsed.percentage;
            aiPlagiarismFlag = parsed.plagiarismFlag; aiPlagiarismNote = parsed.plagiarismNote;
          }
        } else if(extracted && extracted.text){
          // Word/Excel file — review the extracted text
          const prompt = buildAssignmentReviewPrompt(subject, title, `Here is the extracted text content of the submitted document:\n\n"""${extracted.text.slice(0, 6000)}"""\n\nAssess this content.`);
          let response;
          try{ response = await puter.ai.chat(prompt, { model: 'gpt-5.4-nano' }); }
          catch(e){ response = await puter.ai.chat(prompt); }
          const parsed = parseAssignmentAiResponse(response);
          aiFeedback = parsed.feedback; aiMarks = parsed.marks; aiPercentage = parsed.percentage;
          aiPlagiarismFlag = parsed.plagiarismFlag; aiPlagiarismNote = parsed.plagiarismNote;
        } else {
          // Image or PDF — review visually
          const prompt = buildAssignmentReviewPrompt(subject, title, 'Look at the attached image/document and assess the work.');
          let response;
          try{ response = await puter.ai.chat(prompt, fileUrl, { model: 'gpt-5.4-nano' }); }
          catch(e){ response = await puter.ai.chat(prompt, fileUrl); }
          const parsed = parseAssignmentAiResponse(response);
          aiFeedback = parsed.feedback; aiMarks = parsed.marks; aiPercentage = parsed.percentage;
          aiPlagiarismFlag = parsed.plagiarismFlag; aiPlagiarismNote = parsed.plagiarismNote;
        }
      } catch(err){ console.error('AI assignment review failed:', err); }
    }

    const { error } = await sb.from('assignments').insert({
      student_roll: s.roll, student_name: s.name, class: s.class, subject, title,
      file_url: fileUrl, file_name: file.name, status:'Pending', ai_feedback: aiFeedback, ai_marks: aiMarks,
      ai_percentage: aiPercentage, ai_plagiarism_flag: aiPlagiarismFlag, ai_plagiarism_note: aiPlagiarismNote
    });
    if(error) throw error;
    alert('Assignment submitted! ' + (aiFeedback ? `Inspired AI gave it ${aiMarks!==null ? aiMarks+'/10 ':''}${aiPercentage!==null ? '('+aiPercentage+'%) ':''}with some initial feedback — check below.` : 'Your teacher will review it soon.'));
    document.getElementById('asg_subject').value=''; document.getElementById('asg_title').value=''; fileInput.value='';
    progWrap.classList.add('section-hidden'); progBar.style.width='0%'; progText.textContent='0%';
  } catch(err){
    console.error(err);
    alert('Could not submit assignment: ' + err.message);
  } finally {
    btn.disabled = false; btn.textContent = 'Submit Assignment';
  }
}

let assignmentsClassFilter = 'All Classes';
function setAssignmentsClass(cls){
  assignmentsClassFilter = cls;
  renderPage();
}
function renderAdminAssignments(){
  let list = DB.assignments || [];
  if(assignmentsClassFilter !== 'All Classes') list = list.filter(a=>a.class===assignmentsClassFilter);
  const pending = list.filter(a=>a.status==='Pending');
  const reviewed = list.filter(a=>a.status==='Reviewed');
  const rowHtml = (a) => `
    <div class="card" style="background:var(--light-gray); margin-bottom:14px;">
      <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:8px;">
        <div>
          <b>${a.studentName}</b> <span style="color:var(--ink-soft); font-size:13px;">(${a.class}) — ${a.subject}: ${a.title}</span><br>
          <span style="font-size:12px; color:var(--ink-soft);">Submitted: ${new Date(a.submittedAt).toLocaleString()}</span>
        </div>
        <span class="tag ${a.status==='Reviewed'?'paid':'due'}">${a.status}</span>
      </div>
      ${a.fileUrl ? `<div style="margin-top:8px;"><button class="btn small" onclick="openAssignmentFileViewer('${escAttr(a.fileUrl)}', '${escAttr(a.fileName||'')}')">📄 View Submission</button></div>` : ''}
      ${a.aiFeedback ? `<div style="margin-top:10px; background:var(--light-gray); border-left:4px solid var(--gold); padding:10px 12px; font-size:13.5px;"><b>Inspired AI Feedback${a.aiMarks!==null && a.aiMarks!==undefined ? ' — Score: '+a.aiMarks+'/10' : ''}${a.aiPercentage!==null && a.aiPercentage!==undefined ? ' ('+a.aiPercentage+'%)' : ''}:</b><br>${a.aiFeedback}</div>` : ''}
      ${a.aiPlagiarismFlag ? `<div style="margin-top:8px; background:var(--light-gray); border-left:4px solid var(--due); padding:10px 12px; font-size:13.5px; color:var(--due);"><b>⚠ Possible Originality Concern:</b><br>${a.aiPlagiarismNote || 'This submission may not be the student\'s own original work — please review manually.'}</div>` : ''}
      <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin:10px 0 4px;">Your Comment</label>
      <textarea id="asg_comment_${a.id}" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;font-family:inherit;height:60px;resize:vertical;">${a.teacherComment||''}</textarea>
      <div class="actions-row" style="margin-top:8px;">
        <button class="btn small gold" onclick="saveAssignmentReview(${a.id})">Save & Mark Reviewed</button>
        ${SESSION.role==='admin' ? `<button class="btn small danger" onclick="deleteAssignment(${a.id})">Delete</button>` : ''}
      </div>
    </div>`;
  return `
  ${SESSION.role==='admin' ? renderAnswerKeysSection() : ''}
  <div class="card">
    <h3>Filter</h3>
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Class</label>
    <select onchange="setAssignmentsClass(this.value)" style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;">${attendanceClassOptions().map(c=>`<option value="${c}" ${c===assignmentsClassFilter?'selected':''}>${c}</option>`).join('')}</select>
  </div>
  <div class="card">
    <h3>Pending Review (${pending.length})</h3>
    ${pending.length ? pending.map(rowHtml).join('') : '<div class="empty-state">No pending assignments.</div>'}
  </div>
  <div class="card">
    <h3>Reviewed (${reviewed.length})</h3>
    ${reviewed.length ? reviewed.map(rowHtml).join('') : '<div class="empty-state">No reviewed assignments yet.</div>'}
  </div>`;
}
function saveAssignmentReview(id){
  const comment = document.getElementById('asg_comment_'+id).value.trim();
  const reviewer = SESSION.name || SESSION.username || 'Director';
  sb.from('assignments').update({ teacher_comment: comment, status:'Reviewed', reviewed_by: reviewer }).eq('id', id).then(({error})=>{
    if(error){ console.error(error); alert('Could not save: ' + error.message); return; }
    alert('Saved and marked as reviewed.');
  });
}
function deleteAssignment(id){
  if(!confirm('Delete this assignment submission? This cannot be undone.')) return;
  sb.from('assignments').delete().eq('id', id).then(({error})=>{
    if(error){ console.error(error); alert('Could not delete: ' + error.message); return; }
    if(SESSION.role==='student') refreshMyAssignments(SESSION.roll);
    else refreshAssignmentsFromServer();
  });
}

/* ================= ANSWER KEYS (MCQ / Q&A auto-grading) ================= */
function renderAnswerKeysSection(){
  const keys = DB.answerKeys || [];
  const rows = keys.map(k => `
    <div class="card" style="background:var(--light-gray); margin-bottom:12px;">
      <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:8px;">
        <div><b>${k.subject}</b> — ${k.title}</div>
        <button class="btn small danger" onclick="deleteAnswerKey(${k.id})">Delete</button>
      </div>
      <pre style="white-space:pre-wrap; font-family:inherit; font-size:13px; margin-top:8px; color:var(--ink-soft);">${k.answerKey}</pre>
    </div>`).join('');
  return `
  <div class="card">
    <h3>Answer Keys (for MCQ / Q&A auto-grading)</h3>
    <div class="csv-drop" style="margin-bottom:14px;">Upload an answer key for a specific Subject + Title. When a student submits an assignment matching that exact Subject and Title, Inspired AI will automatically compare their answers against this key and mark each one right or wrong — instead of just giving general feedback.</div>
    <div class="row2">
      <div><label>Subject</label><input id="ak_subject" placeholder="e.g. Physics"></div>
      <div><label>Title (must match the assignment title exactly)</label><input id="ak_title" placeholder="e.g. Chapter 3 MCQ Test"></div>
    </div>
    <label>Answer Key</label>
    <textarea id="ak_answerkey" placeholder="e.g.&#10;1. B&#10;2. A&#10;3. D&#10;4. C&#10;&#10;or for short answers:&#10;1. Newton's second law states force equals mass times acceleration&#10;2. Photosynthesis" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;font-family:inherit;height:120px;resize:vertical;"></textarea>
    <div class="actions-row" style="margin-top:14px;"><button class="btn gold" onclick="saveAnswerKey()">Save Answer Key</button></div>
  </div>
  ${rows ? `<div class="card"><h3>Existing Answer Keys (${keys.length})</h3>${rows}</div>` : ''}`;
}
async function saveAnswerKey(){
  const subject = document.getElementById('ak_subject').value.trim();
  const title = document.getElementById('ak_title').value.trim();
  const answerKey = document.getElementById('ak_answerkey').value.trim();
  if(!subject || !title || !answerKey){ alert('Please fill in subject, title, and the answer key.'); return; }
  const existing = (DB.answerKeys||[]).find(k => k.subject.toLowerCase()===subject.toLowerCase() && k.title.toLowerCase()===title.toLowerCase());
  const reviewer = SESSION.name || 'Director';
  try{
    if(existing){
      const { error } = await sb.from('answer_keys').update({ answer_key: answerKey, created_by: reviewer }).eq('id', existing.id);
      if(error) throw error;
      alert('Answer key updated.');
    } else {
      const { error } = await sb.from('answer_keys').insert({ subject, title, answer_key: answerKey, created_by: reviewer });
      if(error) throw error;
      alert('Answer key saved. Students submitting an assignment with this exact Subject + Title will now be auto-graded against it.');
    }
    document.getElementById('ak_subject').value=''; document.getElementById('ak_title').value=''; document.getElementById('ak_answerkey').value='';
  } catch(err){ console.error(err); alert('Could not save answer key: ' + err.message); }
}
function deleteAnswerKey(id){
  if(!confirm('Delete this answer key? This cannot be undone.')) return;
  sb.from('answer_keys').delete().eq('id', id).then(({error})=>{
    if(error){ console.error(error); alert('Could not delete: ' + error.message); }
  });
}

/* ================= ONLINE QUIZ (Director/Teacher/Admin builder & results) ================= */
let quizBuilderOpen = false;
let quizBuilderEditId = null;
let quizBuilderMeta = { title:'', subject:'', cls:'All Classes', duration:20 };
let quizBuilderQuestions = [ { question:'', options:['','','',''], correct:null, topic:'' } ];
let quizResultsViewId = null;

function syncQuizBuilderFromDOM(){
  const t = document.getElementById('qz_title'); if(t) quizBuilderMeta.title = t.value;
  const su = document.getElementById('qz_subject'); if(su) quizBuilderMeta.subject = su.value;
  const c = document.getElementById('qz_class'); if(c) quizBuilderMeta.cls = c.value;
  const d = document.getElementById('qz_duration'); if(d) quizBuilderMeta.duration = d.value;
  quizBuilderQuestions.forEach((q,i) => {
    const qEl = document.getElementById(`qz_q_${i}`); if(qEl) q.question = qEl.value;
    const topicEl = document.getElementById(`qz_topic_${i}`); if(topicEl) q.topic = topicEl.value;
    q.options = q.options.map((_,j) => {
      const optEl = document.getElementById(`qz_opt_${i}_${j}`);
      return optEl ? optEl.value : q.options[j];
    });
    const correctEl = document.querySelector(`input[name="qz_correct_${i}"]:checked`);
    if(correctEl) q.correct = Number(correctEl.value);
  });
}
// Parses quiz Word documents. Supports the "Quiz Upload Template" format (Quiz Title: / Q1. / Answer:)
// AND the academy's normal MCQ paper style (plain "Topic:" header, questions numbered "1." with no
// "Q" prefix, "Time: 20 minutes" instead of "Duration:"), since real papers use the latter.
function parseQuizWordFormat(text){
  const lines = text.split(/\r?\n/).map(l=>l.trim());
  const meta = { title:'', subject:'', cls:'', duration:20 };
  let docTopic = ''; // a document-level "Topic:" header line (used as fallback title, and per-question default)
  const questions = [];
  let current = null;
  const classNames = attendanceClassOptions();
  let seenAnyQuestion = false;
  for(const raw of lines){
    if(!raw) continue;
    let m;
    if(!seenAnyQuestion && (m = raw.match(/^(?:Quiz\s+)?Title:\s*(.+)/i))){ meta.title = m[1].trim(); continue; }
    if(!seenAnyQuestion && (m = raw.match(/^Subject:\s*(.+)/i))){ meta.subject = m[1].trim(); continue; }
    if(!seenAnyQuestion && (m = raw.match(/^Topic:\s*(.+)/i))){ docTopic = m[1].trim(); continue; }
    if(!seenAnyQuestion && (m = raw.match(/^Class:\s*(.+)/i))){
      const val = m[1].trim();
      meta.cls = classNames.find(c=>c.toLowerCase()===val.toLowerCase()) || '';
      continue;
    }
    if(!seenAnyQuestion && (m = raw.match(/^(?:Duration|Time):\s*(\d+)/i))){ meta.duration = Number(m[1]); continue; }
    // Question line: "Q1. ..." (template style) OR plain "1. ..." (real paper style) — "Q" is optional.
    if((m = raw.match(/^Q?\s*(\d+)\s*[\.\):]\s+(.+)/i)) && !raw.match(/^[A-D]\s*[\.\):]/i)){
      seenAnyQuestion = true;
      if(current && current.question.trim()) questions.push(current);
      current = { question:m[2].trim(), options:['','','',''], correct:null, topic:'' };
      continue;
    }
    if(current && (m = raw.match(/^([A-D])\s*[\.\):]\s*(.+)/i))){
      const idx = m[1].toUpperCase().charCodeAt(0) - 65;
      current.options[idx] = m[2].trim();
      continue;
    }
    if(current && (m = raw.match(/^Answer:\s*([A-D])/i))){
      current.correct = m[1].toUpperCase().charCodeAt(0) - 65;
      continue;
    }
    if(current && (m = raw.match(/^Topic:\s*(.+)/i))){
      current.topic = m[1].trim();
      continue;
    }
  }
  if(current && current.question.trim()) questions.push(current);
  // Fallbacks so nothing silently disappears: title defaults to the doc-level Topic if no
  // explicit title was given; class defaults to "All Classes" rather than an unmatched raw
  // string (an unmatched class value would make the quiz invisible to every student).
  if(!meta.title) meta.title = docTopic || '';
  if(!meta.cls) meta.cls = 'All Classes';
  if(docTopic) questions.forEach(q => { if(!q.topic) q.topic = docTopic; });
  return { meta, questions };
}
let quizImportStatusMsg = '';
let quizKeyImportStatusMsg = '';
function extractAiResponseText(response){
  if(typeof response === 'string') return response;
  if(response && response.message && response.message.content){
    const c = response.message.content;
    return Array.isArray(c) ? c.map(b=>b.text||'').filter(Boolean).join('') : String(c);
  }
  return '';
}
function extractJsonFromAiText(text){
  const match = text.match(/\{[\s\S]*\}/);
  if(!match) return null;
  try{ return JSON.parse(match[0]); } catch(e){ return null; }
}
// Uses AI to read the document and pull out quiz questions, regardless of format/wording —
// handles the invented template, plain numbered MCQ papers, or basically anything reasonable.
async function aiExtractQuizQuestions(rawText, classNames){
  const prompt = `Extract quiz question data from this document. It could be in any format — numbered "Q1." or plain "1.", options as "A)" or "A." or bullets, answers marked inline or missing entirely, headers worded differently (e.g. "Topic:" instead of "Title:", "Time:" instead of "Duration:"). Read it like a person would and extract what's actually there.

Respond with ONLY a JSON object, no other text, in exactly this format:
{"title": "quiz title or main topic if mentioned, else empty string", "subject": "subject if mentioned, else empty string", "duration": duration in minutes as a number if mentioned anywhere (e.g. from a Time/Duration line), else 20, "questions": [{"question": "question text without its number", "options": ["option text 1", "option text 2", "option text 3", "option text 4"], "correct": 0-3 index of the correct option if indicated in this document, else null, "topic": "sub-topic for this question if mentioned, else empty string"}]}

Extract every question found, in the order they appear. Each question should have exactly the options actually listed for it. If no answers are indicated anywhere in the document, set "correct" to null for every question — do not guess.

Document text:
"""
${rawText.slice(0, 12000)}
"""`;
  const response = await puter.ai.chat(prompt, { model: 'gpt-5.4-nano' });
  const text = extractAiResponseText(response);
  const parsed = extractJsonFromAiText(text);
  if(!parsed || !Array.isArray(parsed.questions)) return null;
  const validClass = classNames.find(c=>c.toLowerCase()===String(parsed.title||'').toLowerCase());
  return {
    meta: {
      title: parsed.title || '',
      subject: parsed.subject || '',
      cls: 'All Classes',
      duration: (typeof parsed.duration==='number' && parsed.duration>0) ? parsed.duration : 20
    },
    questions: parsed.questions.map(q => ({
      question: q.question || '',
      options: Array.isArray(q.options) ? [0,1,2,3].map(i=>q.options[i]||'') : ['','','',''],
      correct: (typeof q.correct==='number' && q.correct>=0 && q.correct<=3) ? q.correct : null,
      topic: q.topic || ''
    }))
  };
}
// Uses AI to read a standalone answer-key document (any format, with or without explanations)
// and return the correct-answer index for each question, in order.
async function aiExtractQuizAnswerKey(rawText, questionCount){
  const prompt = `Extract the answer key from this document. It lists the correct answer for each numbered question, possibly with an explanation after each one — the format could be "1. B", "Q.1 (Answer: B)" plus a paragraph, or something else entirely. Read it like a person would and pull out just the correct letter for each question number.

Respond with ONLY a JSON object, no other text, in exactly this format:
{"answers": ["B", "C", "A", ...]}

The array should have one letter (A, B, C, or D) per question, in question-number order, matching all ${questionCount} question(s) if that many are present. Use null for any question number you can't find an answer for.

Document text:
"""
${rawText.slice(0, 12000)}
"""`;
  const response = await puter.ai.chat(prompt, { model: 'gpt-5.4-nano' });
  const text = extractAiResponseText(response);
  const parsed = extractJsonFromAiText(text);
  if(!parsed || !Array.isArray(parsed.answers)) return null;
  return parsed.answers.map(a => (typeof a==='string' && /^[A-D]$/i.test(a)) ? a.toUpperCase().charCodeAt(0)-65 : null);
}
// Parses a standalone answer-key document. Handles simple formats like "1. B", "Q1) C", "1: A",
// as well as detailed-explanation formats like "Q.1 (Answer: B)" followed by an explanation
// paragraph — the explanation text is simply ignored, only the number and answer letter matter.
function parseQuizAnswerKeyWordFormat(text){
  const lines = text.split(/\r?\n/).map(l=>l.trim());
  const answers = [];
  for(const raw of lines){
    if(!raw) continue;
    const numMatch = raw.match(/^Q?\.?\s*(\d+)\b/i);
    if(!numMatch) continue;
    const qNum = Number(numMatch[1]);
    let letterMatch = raw.match(/Answer\s*:?\s*\(?\s*([A-D])\b/i);
    if(!letterMatch) letterMatch = raw.match(/^Q?\.?\s*\d+\s*[\.\):]\s*([A-D])\b/i);
    if(letterMatch) answers[qNum-1] = letterMatch[1].toUpperCase().charCodeAt(0) - 65;
  }
  return answers;
}
async function handleQuizAnswerKeyImport(event){
  const file = event.target.files[0];
  if(!file) return;
  if(!quizBuilderQuestions.length || quizBuilderQuestions.every(q=>!q.question.trim())){
    quizKeyImportStatusMsg = '⚠️ Please add or upload your quiz questions first, then upload the answer key to match against them.';
    renderPage();
    return;
  }
  quizKeyImportStatusMsg = 'Reading file…';
  renderPage();
  try{
    const buf = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer: buf });
    syncQuizBuilderFromDOM();
    quizKeyImportStatusMsg = 'Reading with AI…';
    renderPage();
    let answers = null;
    try{ answers = await aiExtractQuizAnswerKey(result.value, quizBuilderQuestions.length); }
    catch(aiErr){ console.error('AI answer key extraction failed, falling back:', aiErr); }
    const hasAnyRealAnswer = (arr) => Array.isArray(arr) && arr.some(a => a!==null && a!==undefined);
    if(!hasAnyRealAnswer(answers)) answers = parseQuizAnswerKeyWordFormat(result.value);
    if(!hasAnyRealAnswer(answers)){
      quizKeyImportStatusMsg = '⚠️ Could not find any answers in this file.';
      renderPage();
      return;
    }
    let matched = 0;
    quizBuilderQuestions.forEach((q,i) => {
      if(answers[i]!==undefined && answers[i]!==null){ q.correct = answers[i]; matched++; }
    });
    const unmatched = quizBuilderQuestions.length - matched;
    quizKeyImportStatusMsg = `✅ Matched answers for ${matched} of ${quizBuilderQuestions.length} question${quizBuilderQuestions.length!==1?'s':''}.${unmatched ? ' ⚠️ '+unmatched+' question(s) still need a correct answer — check them below.' : ' All questions now have a correct answer set.'}`;
    renderPage();
  } catch(err){
    console.error(err);
    quizKeyImportStatusMsg = '⚠️ Could not read this file. Please make sure it\'s a .docx file.';
    renderPage();
  }
}
async function handleQuizWordImport(event){
  const file = event.target.files[0];
  if(!file) return;
  quizImportStatusMsg = 'Reading file…';
  renderPage();
  try{
    const buf = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer: buf });
    const classNames = attendanceClassOptions();
    quizImportStatusMsg = 'Reading with AI…';
    renderPage();
    let parsed = null;
    try{ parsed = await aiExtractQuizQuestions(result.value, classNames); }
    catch(aiErr){ console.error('AI quiz extraction failed, falling back:', aiErr); }
    const hasRealQuestions = (p) => p && Array.isArray(p.questions) && p.questions.some(q => q.question && q.question.trim());
    if(!hasRealQuestions(parsed)) parsed = parseQuizWordFormat(result.value);
    const { meta, questions } = parsed;
    if(!hasRealQuestions(parsed)){
      quizImportStatusMsg = '⚠️ Could not find any questions in this file.';
      renderPage();
      return;
    }
    const incomplete = questions.filter(q => q.options.some(o=>!o.trim()));
    quizBuilderMeta = { title: meta.title, subject: meta.subject, cls: meta.cls||'All Classes', duration: meta.duration||20 };
    quizBuilderQuestions = questions;
    quizImportStatusMsg = `✅ Imported ${questions.length} question${questions.length!==1?'s':''}.${incomplete.length ? ' ⚠️ '+incomplete.length+' question(s) are missing an option — please check them below before saving.' : ' Please review everything below, then click Save Quiz.'}`;
    renderPage();
  } catch(err){
    console.error(err);
    quizImportStatusMsg = '⚠️ Could not read this file. Please make sure it\'s a .docx file.';
    renderPage();
  }
}
function toggleQuizBuilder(){
  quizBuilderOpen = !quizBuilderOpen;
  quizImportStatusMsg = '';
  quizKeyImportStatusMsg = '';
  quizBuilderEditId = null;
  if(quizBuilderOpen){ quizBuilderMeta = { title:'', subject:'', cls:'All Classes', duration:20 }; quizBuilderQuestions = [ { question:'', options:['','','',''], correct:null, topic:'' } ]; }
  renderPage();
}
function editQuiz(id){
  const quiz = (DB.quizzes||[]).find(q=>q.id===id);
  if(!quiz) return;
  quizBuilderEditId = id;
  quizBuilderMeta = { title: quiz.title, subject: quiz.subject, cls: quiz.cls, duration: quiz.durationMinutes };
  // Deep copy so edits don't mutate DB.quizzes until actually saved.
  quizBuilderQuestions = quiz.questions.map(q => ({ question:q.question, options:[...q.options], correct:q.correct, topic:q.topic||'' }));
  quizBuilderOpen = true;
  quizImportStatusMsg = '';
  quizKeyImportStatusMsg = '';
  renderPage();
}
function addQuizQuestion(){
  syncQuizBuilderFromDOM();
  quizBuilderQuestions.push({ question:'', options:['','','',''], correct:null, topic:'' });
  renderPage();
}
function removeQuizQuestion(idx){
  syncQuizBuilderFromDOM();
  if(quizBuilderQuestions.length<=1){ alert('A quiz needs at least one question.'); return; }
  quizBuilderQuestions.splice(idx,1);
  renderPage();
}
async function saveQuizBuilder(){
  syncQuizBuilderFromDOM();
  const { title, subject, cls, duration } = quizBuilderMeta;
  if(!title.trim() || !subject.trim()){ alert('Please fill in the quiz title and subject.'); return; }
  for(let i=0;i<quizBuilderQuestions.length;i++){
    const q = quizBuilderQuestions[i];
    if(!q.question.trim() || q.options.some(o=>!o.trim())){ alert(`Please fill in question ${i+1} and all four of its options.`); return; }
  }
  // A quiz only needs every correct answer set to go live for students — it's fine to save
  // without them and come back later (e.g. to upload the answer key as a separate file).
  const isComplete = quizBuilderQuestions.every(q => q.correct!==null && q.correct!==undefined);
  const status = isComplete ? 'published' : 'draft';
  try{
    if(quizBuilderEditId){
      const { error } = await sb.from('quizzes').update({
        title: title.trim(), subject: subject.trim(), class: cls, duration_minutes: Number(duration)||20,
        questions: quizBuilderQuestions, status
      }).eq('id', quizBuilderEditId);
      if(error) throw error;
    } else {
      const { error } = await sb.from('quizzes').insert({
        title: title.trim(), subject: subject.trim(), class: cls, duration_minutes: Number(duration)||20,
        questions: quizBuilderQuestions, created_by: SESSION.name || SESSION.username || 'Director', status
      });
      if(error) throw error;
    }
    quizBuilderOpen = false;
    quizBuilderEditId = null;
    await refreshQuizzesFromServer();
    alert(isComplete
      ? 'Quiz saved and published! Students in the selected class will now see it under Online Quiz.'
      : `Quiz saved as a draft — it won't be visible to students yet because ${quizBuilderQuestions.filter(q=>q.correct===null||q.correct===undefined).length} question(s) still need a correct answer. Come back to this quiz anytime (use "Edit") to upload the answer key or finish it, and it will publish automatically once complete.`);
    renderPage();
  } catch(err){ console.error(err); alert('Could not save quiz: ' + err.message); }
}
async function deleteQuiz(id){
  if(!confirm('Delete this quiz and all student attempts for it? This cannot be undone.')) return;
  try{
    const { error: attErr } = await sb.from('quiz_attempts').delete().eq('quiz_id', id);
    if(attErr) throw attErr;
    const { error } = await sb.from('quizzes').delete().eq('id', id);
    if(error) throw error;
    await refreshQuizzesFromServer();
    await refreshAllQuizAttemptsFromServer();
    renderPage();
  } catch(err){ console.error(err); alert('Could not delete: ' + err.message); }
}
function quizQuestionBuilderHtml(q, i){
  return `
  <div class="card" style="background:var(--light-gray); margin-bottom:12px;">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <b>Question ${i+1}</b>
      <button class="btn small danger" onclick="removeQuizQuestion(${i})">Remove</button>
    </div>
    <label style="margin-top:10px;">Question Text</label>
    <input id="qz_q_${i}" value="${(q.question||'').replace(/"/g,'&quot;')}" placeholder="e.g. What is the SI unit of force?">
    <label style="margin-top:8px;">Topic (optional, for performance breakdown)</label>
    <input id="qz_topic_${i}" value="${(q.topic||'').replace(/"/g,'&quot;')}" placeholder="e.g. Newton's Laws">
    <label style="margin-top:8px;">Options (select the correct one)</label>
    ${q.correct===null || q.correct===undefined ? `<div style="color:var(--due); font-size:12.5px; margin-top:4px;">⚠️ No correct answer selected yet</div>` : ''}
    ${[0,1,2,3].map(j => `
      <div style="display:flex; align-items:center; gap:8px; margin-top:6px;">
        <input type="radio" name="qz_correct_${i}" value="${j}" ${q.correct===j?'checked':''}>
        <input id="qz_opt_${i}_${j}" value="${(q.options[j]||'').replace(/"/g,'&quot;')}" placeholder="Option ${String.fromCharCode(65+j)}" style="flex:1;">
      </div>`).join('')}
  </div>`;
}
function renderAdminQuizzes(){
  if(quizResultsViewId !== null) return renderQuizResultsView(quizResultsViewId);
  if(quizBuilderOpen){
    const classOpts = attendanceClassOptions().map(c=>`<option value="${c}" ${c===quizBuilderMeta.cls?'selected':''}>${c}</option>`).join('');
    return `
    <div class="card" style="background:var(--light-gray);">
      <h3 style="margin-top:0;">📄 Import from Word (optional)</h3>
      <div style="font-size:13px; color:var(--ink-soft); margin-bottom:10px;">Upload any Word document with quiz questions — an MCQ paper, worksheet, or anything similar. AI reads it and fills everything in below, whatever format it's in. You can upload just the questions (no answers) and add the answer key separately below.</div>
      <input type="file" accept=".docx" onchange="handleQuizWordImport(event)">
      ${quizImportStatusMsg ? `<div style="margin-top:10px; font-size:13.5px;">${quizImportStatusMsg}</div>` : ''}
    </div>
    <div class="card" style="background:var(--light-gray);">
      <h3 style="margin-top:0;">🔑 Import Answer Key Separately (optional)</h3>
      <div style="font-size:13px; color:var(--ink-soft); margin-bottom:10px;">Upload any answer-key document, in whatever format you already write it — simple lists, detailed explanations, anything. AI reads it and matches each answer to the questions above by question number.</div>
      <input type="file" accept=".docx" onchange="handleQuizAnswerKeyImport(event)">
      ${quizKeyImportStatusMsg ? `<div style="margin-top:10px; font-size:13.5px;">${quizKeyImportStatusMsg}</div>` : ''}
    </div>
    <div class="card">
      <h3>${quizBuilderEditId ? 'Edit Quiz' : 'Create New Quiz'}</h3>
      <div class="row2">
        <div><label>Quiz Title</label><input id="qz_title" value="${quizBuilderMeta.title.replace(/"/g,'&quot;')}" placeholder="e.g. Chapter 3 — Electrostatics"></div>
        <div><label>Subject</label><input id="qz_subject" value="${quizBuilderMeta.subject.replace(/"/g,'&quot;')}" placeholder="e.g. Physics"></div>
      </div>
      <div class="row2">
        <div><label>Class</label><select id="qz_class">${classOpts}</select></div>
        <div><label>Duration (minutes)</label><input id="qz_duration" type="number" min="1" value="${quizBuilderMeta.duration}"></div>
      </div>
      <h3 style="margin-top:22px;">Questions</h3>
      ${quizBuilderQuestions.map((q,i)=>quizQuestionBuilderHtml(q,i)).join('')}
      <div class="actions-row" style="margin-top:14px;">
        <button class="btn" onclick="addQuizQuestion()">+ Add Question</button>
        <button class="btn gold" onclick="saveQuizBuilder()">${quizBuilderEditId ? 'Save Changes' : 'Save Quiz'}</button>
        <button class="btn" onclick="toggleQuizBuilder()">Cancel</button>
      </div>
    </div>`;
  }
  const quizzes = DB.quizzes || [];
  const rows = quizzes.map(q => {
    const attempts = (DB.quizAttempts||[]).filter(a=>a.quizId===q.id);
    const avg = attempts.length ? Math.round(attempts.reduce((s,a)=>s+a.percentage,0)/attempts.length) : null;
    return `
    <div class="card" style="margin-bottom:12px;">
      <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:8px; align-items:center;">
        <div>
          <b>${q.title}</b> — ${q.subject} <span style="color:var(--ink-soft); font-size:12.5px;">(${q.cls})</span>
          ${q.status==='draft' ? `<span class="tag due" style="margin-left:8px;">Draft — not visible to students</span>` : ''}<br>
          <span style="font-size:12.5px; color:var(--ink-soft);">${q.questions.length} question${q.questions.length!==1?'s':''} · ${q.durationMinutes} min · ${attempts.length} attempt${attempts.length!==1?'s':''}${avg!==null?' · Avg: '+avg+'%':''}</span>
        </div>
        <div class="actions-row">
          <button class="btn small" onclick="editQuiz(${q.id})">✏️ Edit</button>
          <button class="btn small" onclick="quizResultsViewId=${q.id}; renderPage();">View Results</button>
          <button class="btn small danger" onclick="deleteQuiz(${q.id})">Delete</button>
        </div>
      </div>
    </div>`;
  }).join('');
  return `
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <h3 style="margin:0;">Online Quiz</h3>
      <button class="btn gold" onclick="toggleQuizBuilder()">+ Create New Quiz</button>
    </div>
  </div>
  ${rows || '<div class="card"><div class="empty-state">No quizzes created yet.</div></div>'}`;
}
function renderQuizResultsView(quizId){
  const quiz = (DB.quizzes||[]).find(q=>q.id===quizId);
  if(!quiz){ quizResultsViewId=null; return renderAdminQuizzes(); }
  const attempts = (DB.quizAttempts||[]).filter(a=>a.quizId===quizId).slice().sort((a,b)=>b.percentage-a.percentage);
  const avg = attempts.length ? Math.round(attempts.reduce((s,a)=>s+a.percentage,0)/attempts.length) : 0;
  const rows = attempts.map(a => `
    <tr class="ledger-row">
      <td>${a.studentName}</td><td class="mono">${a.studentRoll}</td>
      <td>${a.score}/${a.total}</td><td>${a.percentage}%</td>
      <td>${new Date(a.submittedAt).toLocaleString()}</td>
    </tr>`).join('');
  return `
  <div class="card">
    <button class="btn small" onclick="quizResultsViewId=null; renderPage();">← Back to Quizzes</button>
    <h3 style="margin-top:12px;">${quiz.title} — Results</h3>
    <div style="font-size:13.5px; color:var(--ink-soft); margin-bottom:14px;">${attempts.length} attempt${attempts.length!==1?'s':''} · Average score: ${avg}%</div>
    <table><thead><tr><th>Student</th><th>Roll No.</th><th>Score</th><th>%</th><th>Submitted</th></tr></thead>
    <tbody>${rows || '<tr><td colspan="5" class="empty-state">No attempts yet.</td></tr>'}</tbody></table>
  </div>`;
}

/* ================= ONLINE QUIZ (Student — take quiz & view own results) ================= */
let activeQuizId = null;
let activeQuizAnswers = [];
let activeQuizTimeLeft = 0;
let activeQuizTimer = null;
let quizResultView = null; // attempt object to show results for, or null

async function startQuiz(quizId){
  const quiz = (DB.quizzes||[]).find(q=>q.id===quizId);
  if(!quiz) return;
  // Re-check directly against the server (not just local cache) so a second tab, a stale
  // page, or a slow realtime update can't let a student start a second attempt.
  const { data: existing, error } = await sb.from('quiz_attempts').select('id').eq('quiz_id', quizId).eq('student_roll', SESSION.roll).maybeSingle();
  if(error){ console.error(error); alert('Could not check your attempt status. Please try again.'); return; }
  if(existing){ alert('You have already attempted this quiz. Only one attempt is allowed.'); refreshMyQuizAttempts(SESSION.roll); return; }
  if(!confirm(`Start "${quiz.title}"? You'll have ${quiz.durationMinutes} minutes and can only attempt this once.`)) return;
  activeQuizId = quizId;
  activeQuizAnswers = new Array(quiz.questions.length).fill(null);
  activeQuizTimeLeft = quiz.durationMinutes * 60;
  renderPage();
  if(activeQuizTimer) clearInterval(activeQuizTimer);
  activeQuizTimer = setInterval(() => {
    activeQuizTimeLeft--;
    const timerEl = document.getElementById('quizTimer');
    if(timerEl) timerEl.textContent = formatQuizTime(activeQuizTimeLeft);
    if(activeQuizTimeLeft<=0){ clearInterval(activeQuizTimer); submitQuiz(true); }
  }, 1000);
}
function formatQuizTime(sec){
  const m = Math.floor(sec/60), s = sec%60;
  return `${m}:${String(s).padStart(2,'0')}`;
}
function selectQuizAnswer(qIdx, optIdx){
  activeQuizAnswers[qIdx] = optIdx;
  document.querySelectorAll(`input[name="take_q_${qIdx}"]`).forEach((el,i) => { el.checked = (i===optIdx); });
}
async function submitQuiz(auto){
  if(!auto && !confirm('Submit your quiz now? You cannot change your answers after this.')) return;
  if(activeQuizTimer) clearInterval(activeQuizTimer);
  const quiz = (DB.quizzes||[]).find(q=>q.id===activeQuizId);
  if(!quiz){ activeQuizId=null; renderPage(); return; }
  let score = 0;
  quiz.questions.forEach((q,i) => { if(activeQuizAnswers[i]===q.correct) score++; });
  const total = quiz.questions.length;
  const percentage = total ? Math.round((score/total)*100) : 0;
  const s = getStudent(SESSION.roll);
  try{
    // Final guard right before writing — catches the rare case where a second attempt
    // was started (e.g. two open tabs) before this one finished submitting.
    const { data: existing } = await sb.from('quiz_attempts').select('id').eq('quiz_id', quiz.id).eq('student_roll', SESSION.roll).maybeSingle();
    if(existing){
      alert('An attempt for this quiz was already submitted — this one will not be recorded.');
      activeQuizId = null; refreshMyQuizAttempts(SESSION.roll); return;
    }
    const { error } = await sb.from('quiz_attempts').insert({
      quiz_id: quiz.id, student_roll: SESSION.roll, student_name: s.name,
      answers: activeQuizAnswers, score, total, percentage
    });
    if(error){
      if(error.code==='23505'){ alert('An attempt for this quiz was already submitted — this one will not be recorded.'); }
      else throw error;
    }
  } catch(err){ console.error(err); alert('Could not submit your quiz: ' + err.message); }
  quizResultView = { quizId: quiz.id, answers: activeQuizAnswers, score, total, percentage };
  activeQuizId = null;
  renderPage();
}
function renderStudentQuizzes(){
  if(activeQuizId !== null) return renderQuizTakingView();
  if(quizResultView !== null) return renderQuizOwnResultView();
  const s = getStudent(SESSION.roll);
  const available = (DB.quizzes||[]).filter(q => (q.cls===s.class || q.cls==='All Classes') && q.status!=='draft');
  const myAttempts = DB.quizAttempts || [];
  const rows = available.map(q => {
    const attempt = myAttempts.find(a=>a.quizId===q.id);
    return `
    <div class="card" style="margin-bottom:12px;">
      <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:8px; align-items:center;">
        <div>
          <b>${q.title}</b> — ${q.subject}<br>
          <span style="font-size:12.5px; color:var(--ink-soft);">${q.questions.length} question${q.questions.length!==1?'s':''} · ${q.durationMinutes} min</span>
        </div>
        ${attempt
          ? `<div style="text-align:right;"><span class="tag ${attempt.percentage>=50?'present':'absent'}">Completed — ${attempt.percentage}%</span><br>
             <button class="btn small" style="margin-top:6px;" onclick="quizResultView={quizId:${q.id}, answers:${JSON.stringify(attempt.answers)}, score:${attempt.score}, total:${attempt.total}, percentage:${attempt.percentage}}; renderPage();">View My Answers</button></div>`
          : `<button class="btn gold" onclick="startQuiz(${q.id})">Start Quiz</button>`}
      </div>
    </div>`;
  }).join('');
  return `<div class="card"><h3>Online Quiz</h3></div>${rows || '<div class="card"><div class="empty-state">No quizzes available for your class right now.</div></div>'}`;
}
function renderQuizTakingView(){
  const quiz = (DB.quizzes||[]).find(q=>q.id===activeQuizId);
  if(!quiz){ activeQuizId=null; return renderStudentQuizzes(); }
  const qHtml = quiz.questions.map((q,i) => `
    <div class="card" style="margin-bottom:12px;">
      <b>Q${i+1}. ${q.question}</b>
      ${[0,1,2,3].map(j => `
        <div style="margin-top:8px; display:flex; align-items:center; gap:8px; cursor:pointer;" onclick="selectQuizAnswer(${i},${j})">
          <input type="radio" name="take_q_${i}" id="take_q_${i}_${j}">
          <label for="take_q_${i}_${j}" style="cursor:pointer;">${String.fromCharCode(65+j)}. ${q.options[j]}</label>
        </div>`).join('')}
    </div>`).join('');
  return `
  <div class="card" style="position:sticky; top:0; z-index:10; display:flex; justify-content:space-between; align-items:center;">
    <h3 style="margin:0;">${quiz.title}</h3>
    <div style="font-size:20px; font-weight:bold; color:var(--maroon);" id="quizTimer">${formatQuizTime(activeQuizTimeLeft)}</div>
  </div>
  ${qHtml}
  <div class="actions-row"><button class="btn gold" onclick="submitQuiz(false)">Submit Quiz</button></div>`;
}
function renderQuizOwnResultView(){
  const quiz = (DB.quizzes||[]).find(q=>q.id===quizResultView.quizId);
  if(!quiz){ quizResultView=null; return renderStudentQuizzes(); }
  const rows = quiz.questions.map((q,i) => {
    const studentAns = quizResultView.answers[i];
    const isCorrect = studentAns===q.correct;
    return `
    <div class="card" style="margin-bottom:10px; background:${isCorrect?'#f0f8f0':'#fff8f8'};">
      <b>Q${i+1}. ${q.question}</b>
      <div style="margin-top:8px; font-size:13.5px;">
        Your answer: ${studentAns!==null && studentAns!==undefined ? String.fromCharCode(65+studentAns)+'. '+q.options[studentAns] : '— Not answered —'}
        ${isCorrect ? ' ✓' : ` ✗ <br>Correct answer: ${String.fromCharCode(65+q.correct)}. ${q.options[q.correct]}`}
      </div>
    </div>`;
  }).join('');
  return `
  <div class="card">
    <button class="btn small" onclick="quizResultView=null; renderPage();">← Back to Quizzes</button>
    <h3 style="margin-top:12px;">${quiz.title} — Your Result</h3>
    <div style="font-size:18px; font-weight:bold; color:var(--maroon); margin-bottom:14px;">Score: ${quizResultView.score}/${quizResultView.total} (${quizResultView.percentage}%)</div>
  </div>
  ${rows}`;
}

function renderStudentProfile(){
  const s = getStudent(SESSION.roll);
  return `<div class="card"><h3>My Profile</h3>
    <table>
      <tr class="ledger-row"><td><b>Roll Number</b></td><td class="mono">${s.roll}</td></tr>
      <tr class="ledger-row"><td><b>Name</b></td><td>${s.name}</td></tr>
      <tr class="ledger-row"><td><b>Class</b></td><td>${s.class}</td></tr>
      <tr class="ledger-row"><td><b>Father's Name</b></td><td>${s.father}</td></tr>
      <tr class="ledger-row"><td><b>Phone</b></td><td>${s.phone}</td></tr>
    </table>
  </div>
  <div class="card"><h3>Change Password</h3>
    ${changePasswordFormHtml('student')}
  </div>`;
}

/* ================= STUDY MATERIAL (shared) ================= */
let materialsClassFilter = 'All Classes';
function setMaterialsClass(cls){
  materialsClassFilter = cls;
  renderPage();
}
function renderMaterials(isAdmin){
  const s = isAdmin ? null : getStudent(SESSION.roll);
  let visible;
  if(isAdmin){
    visible = materialsClassFilter==='All Classes' ? DB.materials : DB.materials.filter(m => m.cls===materialsClassFilter || m.cls==='All Classes');
  } else {
    visible = DB.materials.filter(m => m.cls==='All Classes' || m.cls===s.class);
  }
  const items = visible.map(m => `
    <div class="material-item">
      <div class="meta"><b>${m.title}</b><small>${m.subject} · ${m.cls} · Uploaded ${m.uploadedDate}</small></div>
      <div style="display:flex; gap:8px;">
        ${m.fileURL ? `<button class="btn small" onclick="openMaterial(${m.id})">View</button>` : `<span style="font-size:12px;color:var(--ink-soft);">No file attached</span>`}
        ${isAdmin ? `<button class="btn small danger" onclick="deleteMaterial(${m.id})">Delete</button>` : ''}
      </div>
    </div>`).join('');
  return `
    <div class="card">
      <h3>Study Material</h3>
      ${isAdmin ? `<div class="actions-row"><button class="btn gold" onclick="openModal('materialModalOverlay')">+ Upload Material</button></div>` : ''}
      ${isAdmin ? `
        <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Class</label>
        <select onchange="setMaterialsClass(this.value)" style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:14px;">${attendanceClassOptions().map(c=>`<option value="${c}" ${c===materialsClassFilter?'selected':''}>${c}</option>`).join('')}</select>
      ` : ''}
      ${items || '<div class="empty-state"><div class="big">📄</div>No study material available yet.</div>'}
    </div>
    <div id="pdfViewerWrap" oncontextmenu="return false;">
      <div class="pdf-controls" id="pdfControls">
        <button class="btn small" onclick="pdfPrevPage()">‹ Prev</button>
        <span id="pdfPageInfo" class="mono"></span>
        <button class="btn small" onclick="pdfNextPage()">Next ›</button>
      </div>
      <div id="materialLoading" style="display:none; text-align:center; padding:30px; color:var(--ink-soft);">Loading document…</div>
      <canvas id="pdfCanvas" style="display:none;"></canvas>
      <img id="materialImage" style="display:none; max-width:100%; box-shadow:var(--shadow); user-select:none; pointer-events:none;" draggable="false">
      <video id="materialVideo" style="display:none; max-width:100%; box-shadow:var(--shadow);" controls controlsList="nodownload" oncontextmenu="return false;"></video>
      <iframe id="materialIframe" style="display:none; width:100%; height:70vh; border:1px solid var(--line); box-shadow:var(--shadow);"></iframe>
      <div id="materialDocView" style="display:none; text-align:left; max-height:75vh; overflow-y:auto; background:var(--white); border:1px solid var(--line); box-shadow:var(--shadow); padding:24px 30px;"></div>
      <div id="materialSheetView" style="display:none; text-align:left; max-height:75vh; overflow:auto; background:var(--white); border:1px solid var(--line); box-shadow:var(--shadow); padding:16px;"></div>
      <div id="materialSheetTabs" style="display:none; margin-bottom:10px; gap:6px; flex-wrap:wrap;"></div>
      <div id="materialFallback" style="display:none; text-align:center; padding:24px; background:#fff8e1; border:1px solid var(--gold); border-radius:14px; color:#5c4300; font-size:13.5px;"></div>
    </div>`;
}

let pdfDoc=null, pdfPage=1;
function isPdfFile(m){
  const name = (m.fileName||m.fileURL||'').toLowerCase();
  return name.endsWith('.pdf');
}
function fileKind(m){
  const name = (m.fileName||m.fileURL||'').toLowerCase();
  if(name.endsWith('.pdf')) return 'pdf';
  if(/\.(jpg|jpeg|png|gif|webp)$/.test(name)) return 'image';
  if(/\.(mp4|webm|mov|m4v)$/.test(name)) return 'video';
  if(name.endsWith('.docx')) return 'docx';
  if(name.endsWith('.doc')) return 'doc-legacy';
  if(name.endsWith('.xlsx') || name.endsWith('.xls')) return 'sheet';
  if(name.endsWith('.pptx') || name.endsWith('.ppt')) return 'slides';
  return 'other';
}
function openMaterial(id){
  const m = DB.materials.find(x=>String(x.id)===String(id));
  if(!m || !m.fileURL) return;
  const wrap = document.getElementById('pdfViewerWrap');
  const canvas = document.getElementById('pdfCanvas');
  const img = document.getElementById('materialImage');
  const video = document.getElementById('materialVideo');
  const iframe = document.getElementById('materialIframe');
  const controls = document.getElementById('pdfControls');
  const loading = document.getElementById('materialLoading');
  const docView = document.getElementById('materialDocView');
  const sheetView = document.getElementById('materialSheetView');
  const sheetTabs = document.getElementById('materialSheetTabs');
  const fallback = document.getElementById('materialFallback');
  wrap.classList.add('show');
  wrap.scrollIntoView({ behavior:'smooth', block:'start' });
  [canvas, img, video, iframe, docView, sheetView, fallback].forEach(el => el.style.display='none');
  controls.style.display='none'; sheetTabs.style.display='none'; sheetTabs.innerHTML='';
  loading.style.display='none';
  iframe.src=''; video.pause(); video.src=''; docView.innerHTML=''; sheetView.innerHTML='';

  const kind = fileKind(m);
  const showFallback = (message) => {
    loading.style.display='none';
    fallback.style.display='block';
    fallback.innerHTML = `${message}<br><br><a href="${m.fileURL}" target="_blank" rel="noopener" class="btn small gold" style="display:inline-block; margin-top:6px;">⬇ Open / Download File</a>`;
  };

  if(kind==='pdf'){
    controls.style.display='flex';
    canvas.style.display='block';
    loading.style.display='block';
    getPdfLib().then(lib => lib.getDocument(m.fileURL).promise).then(doc => {
      loading.style.display='none';
      pdfDoc = doc; pdfPage = 1; renderPdfPage();
    }).catch(()=>{ showFallback('⚠️ Could not load this PDF file for preview.'); });
  } else if(kind==='image'){
    img.style.display='block';
    img.src = m.fileURL;
  } else if(kind==='video'){
    video.style.display='block';
    video.src = m.fileURL;
  } else if(kind==='docx'){
    loading.style.display='block';
    fetch(m.fileURL).then(r => {
      if(!r.ok) throw new Error('Fetch failed');
      return r.arrayBuffer();
    }).then(buf => mammoth.convertToHtml({ arrayBuffer: buf }))
      .then(result => {
        loading.style.display='none';
        docView.style.display='block';
        docView.innerHTML = result.value || '<p style="color:var(--ink-soft);">This document appears to be empty.</p>';
      }).catch(()=>{ showFallback('⚠️ Could not preview this Word document here.'); });
  } else if(kind==='sheet'){
    loading.style.display='block';
    fetch(m.fileURL).then(r => {
      if(!r.ok) throw new Error('Fetch failed');
      return r.arrayBuffer();
    }).then(buf => {
      loading.style.display='none';
      const wb = XLSX.read(new Uint8Array(buf), { type:'array' });
      sheetView.style.display='block';
      const renderSheet = (name) => {
        const html = XLSX.utils.sheet_to_html(wb.Sheets[name], { editable:false });
        sheetView.innerHTML = html;
      };
      if(wb.SheetNames.length > 1){
        sheetTabs.style.display='flex';
        sheetTabs.innerHTML = wb.SheetNames.map((name,i) =>
          `<button class="btn small ${i===0?'active':''}" onclick="
            document.querySelectorAll('#materialSheetTabs button').forEach(b=>b.classList.remove('active'));
            this.classList.add('active');
            document.getElementById('materialSheetView').innerHTML = XLSX.utils.sheet_to_html(window.__currentWb.Sheets['${name.replace(/'/g,"\\'")}'], {editable:false});
          ">${name}</button>`
        ).join('');
        window.__currentWb = wb;
      }
      renderSheet(wb.SheetNames[0]);
    }).catch(()=>{ showFallback('⚠️ Could not preview this Excel file here.'); });
  } else if(kind==='slides' || kind==='doc-legacy'){
    loading.style.display='block';
    iframe.style.display='block';
    iframe.src = 'https://docs.google.com/gview?url=' + encodeURIComponent(m.fileURL) + '&embedded=true';
    iframe.onload = () => { loading.style.display='none'; };
    // Google's viewer is best-effort for these formats — always show a direct fallback link alongside it.
    setTimeout(() => {
      if(fallback.style.display==='none'){
        fallback.style.display='block';
        fallback.innerHTML = `If the preview above doesn't load, <a href="${m.fileURL}" target="_blank" rel="noopener">open or download the file directly</a>.`;
      }
    }, 2500);
  } else {
    showFallback('This file type can\'t be previewed in-browser.');
  }
}
function openPdf(id){ openMaterial(id); }
function renderPdfPage(){
  if(!pdfDoc) return;
  pdfDoc.getPage(pdfPage).then(page => {
    const canvas = document.getElementById('pdfCanvas');
    const viewport = page.getViewport({scale: 1.3});
    canvas.width = viewport.width; canvas.height = viewport.height;
    page.render({canvasContext: canvas.getContext('2d'), viewport});
    document.getElementById('pdfPageInfo').textContent = `Page ${pdfPage} of ${pdfDoc.numPages}`;
  });
}
function pdfPrevPage(){ if(pdfDoc && pdfPage>1){ pdfPage--; renderPdfPage(); } }
function pdfNextPage(){ if(pdfDoc && pdfPage<pdfDoc.numPages){ pdfPage++; renderPdfPage(); } }
function pdfGoToPage(pageNum){ if(pdfDoc && pageNum >= 1 && pageNum <= pdfDoc.numPages){ pdfPage = pageNum; renderPdfPage(); } }

/* ================= NO-DOWNLOAD ASSIGNMENT FILE VIEWER (Director/Teacher/Admin review) ================= */
function escAttr(str){
  return String(str||'').replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/"/g,'&quot;');
}
function fileKindFromName(name){
  name = (name||'').toLowerCase();
  if(name.endsWith('.pdf')) return 'pdf';
  if(/\.(jpg|jpeg|png|gif|webp)$/.test(name)) return 'image';
  if(/\.(mp4|webm|mov|m4v)$/.test(name)) return 'video';
  if(name.endsWith('.docx')) return 'docx';
  if(name.endsWith('.doc')) return 'doc-legacy';
  if(name.endsWith('.xlsx') || name.endsWith('.xls')) return 'sheet';
  if(name.endsWith('.pptx') || name.endsWith('.ppt')) return 'slides';
  return 'other';
}
let fvPdfDoc=null, fvPdfPage=1, fvCurrentCanvas=null, fvPageInfoEl=null;
function renderFvPage(){
  if(!fvPdfDoc) return;
  fvPdfDoc.getPage(fvPdfPage).then(page => {
    const viewport = page.getViewport({scale: 1.3});
    fvCurrentCanvas.width = viewport.width; fvCurrentCanvas.height = viewport.height;
    page.render({canvasContext: fvCurrentCanvas.getContext('2d'), viewport});
    if(fvPageInfoEl) fvPageInfoEl.textContent = `Page ${fvPdfPage} of ${fvPdfDoc.numPages}`;
  });
}
function fvPrevPage(){ if(fvPdfDoc && fvPdfPage>1){ fvPdfPage--; renderFvPage(); } }
function fvNextPage(){ if(fvPdfDoc && fvPdfPage<fvPdfDoc.numPages){ fvPdfPage++; renderFvPage(); } }

// Opens a student's submitted assignment file in a view-only modal — no download link or
// raw file URL is ever exposed, per Director's policy that submissions can be reviewed but not saved.
function openAssignmentFileViewer(fileUrl, fileName){
  if(!fileUrl) return;
  const kind = fileKindFromName(fileName || fileUrl);
  const modal = document.createElement('div');
  modal.className = 'modal-fullprofile show';
  modal.oncontextmenu = () => false;
  modal.innerHTML = `<div class="file-viewer-modal-content" onclick="event.stopPropagation()" oncontextmenu="return false;">
    <span class="profile-modal-close" onclick="this.closest('.modal-fullprofile').remove()">&times;</span>
    <h3 style="margin-top:0; margin-right:34px; color:var(--maroon-deep);">📄 ${fileName || 'Student Submission'}</h3>
    <div class="file-viewer-body" id="fvBody">
      <div id="fvLoading" style="padding:30px; color:var(--ink-soft);">Loading…</div>
      <div class="pdf-controls" id="fvPdfControls" style="display:none;">
        <button class="btn small" onclick="fvPrevPage()">‹ Prev</button>
        <span id="fvPageInfo" class="mono"></span>
        <button class="btn small" onclick="fvNextPage()">Next ›</button>
      </div>
      <canvas id="fvCanvas" style="display:none;"></canvas>
      <img id="fvImage" style="display:none;" draggable="false">
      <video id="fvVideo" style="display:none; max-width:100%;" controls controlsList="nodownload" oncontextmenu="return false;"></video>
      <iframe id="fvIframe" style="display:none; width:100%; height:65vh; border:1px solid var(--line);"></iframe>
      <div id="fvDocView" style="display:none;"></div>
      <div id="fvSheetTabs" style="display:none; gap:6px; flex-wrap:wrap; margin-bottom:10px;"></div>
      <div id="fvSheetView" style="display:none; overflow:auto; max-height:65vh;"></div>
      <div id="fvError" style="display:none; padding:24px; background:#fff3cd; border:1px solid #ffc107; border-radius:14px; color:#856404;"></div>
    </div>
  </div>`;
  modal.onclick = () => modal.remove();
  document.body.appendChild(modal);

  const loading = modal.querySelector('#fvLoading');
  const pdfControls = modal.querySelector('#fvPdfControls');
  const canvas = modal.querySelector('#fvCanvas');
  const img = modal.querySelector('#fvImage');
  const video = modal.querySelector('#fvVideo');
  const iframe = modal.querySelector('#fvIframe');
  const docView = modal.querySelector('#fvDocView');
  const sheetTabs = modal.querySelector('#fvSheetTabs');
  const sheetView = modal.querySelector('#fvSheetView');
  const errBox = modal.querySelector('#fvError');
  const showError = (msg) => { loading.style.display='none'; errBox.style.display='block'; errBox.textContent = msg; };

  if(kind==='pdf'){
    pdfControls.style.display='flex'; canvas.style.display='block';
    getPdfLib().then(lib => lib.getDocument(fileUrl).promise).then(doc => {
      loading.style.display='none';
      fvPdfDoc = doc; fvPdfPage = 1; fvCurrentCanvas = canvas; fvPageInfoEl = modal.querySelector('#fvPageInfo');
      renderFvPage();
    }).catch(()=> showError('⚠️ Could not load this PDF for preview.'));
  } else if(kind==='image'){
    img.style.display='block'; img.src = fileUrl;
    img.onload = () => { loading.style.display='none'; };
    img.onerror = () => showError('⚠️ Could not load this image.');
  } else if(kind==='video'){
    video.style.display='block'; video.src = fileUrl;
    loading.style.display='none';
  } else if(kind==='docx'){
    fetch(fileUrl).then(r => { if(!r.ok) throw new Error('fetch failed'); return r.arrayBuffer(); })
      .then(buf => mammoth.convertToHtml({ arrayBuffer: buf }))
      .then(result => {
        loading.style.display='none';
        docView.style.display='block';
        docView.innerHTML = result.value || '<p style="color:var(--ink-soft);">This document appears to be empty.</p>';
      }).catch(()=> showError('⚠️ Could not preview this Word document.'));
  } else if(kind==='sheet'){
    // A spreadsheet here was uploaded by a student. The reader available to us
    // has a known flaw, so we hand the file over rather than open it.
    loading.style.display='none';
    showError('\u26A0\uFE0F Spreadsheets are not previewed here. Use the Download button to open it in Excel.');
    return;
  } else if(kind==='__never__'){
    fetch(fileUrl).then(r => { if(!r.ok) throw new Error('fetch failed'); return r.arrayBuffer(); })
      .then(buf => {
        loading.style.display='none';
        const wb = XLSX.read(new Uint8Array(buf), { type:'array' });
        sheetView.style.display='block';
        const renderSheet = (name) => { sheetView.innerHTML = XLSX.utils.sheet_to_html(wb.Sheets[name], { editable:false }); };
        if(wb.SheetNames.length > 1){
          sheetTabs.style.display='flex';
          sheetTabs.innerHTML = wb.SheetNames.map((name,i) => `<button class="btn small ${i===0?'active':''}" onclick="
            this.parentElement.querySelectorAll('button').forEach(b=>b.classList.remove('active'));
            this.classList.add('active');
            this.closest('.file-viewer-body').querySelector('#fvSheetView').innerHTML = XLSX.utils.sheet_to_html(window.__fvWb.Sheets['${name.replace(/'/g,"\\'")}'], {editable:false});
          ">${name}</button>`).join('');
          window.__fvWb = wb;
        }
        renderSheet(wb.SheetNames[0]);
      }).catch(()=> showError('⚠️ Could not preview this Excel file.'));
  } else if(kind==='slides' || kind==='doc-legacy'){
    iframe.style.display='block';
    iframe.src = 'https://docs.google.com/gview?url=' + encodeURIComponent(fileUrl) + '&embedded=true';
    iframe.onload = () => { loading.style.display='none'; };
    setTimeout(() => { if(loading.style.display!=='none'){ showError('⚠️ Preview is not available for this file type.'); } }, 4000);
  } else {
    showError('This file type can\'t be previewed here.');
  }
}

/* ================= ADMIN VIEWS ================= */
function totalCollected(student){
  return student.fees.filter(f=>f.status==='Paid').reduce((sum,f)=>sum+Number(f.amount||0),0);
}
function totalExpenses(){
  return DB.expenses.reduce((sum,e)=>sum+Number(e.amount||0),0);
}
function classDistribution(){
  const counts = {};
  DB.students.forEach(s=>{
    const cls = s.class || 'Unspecified';
    counts[cls] = (counts[cls]||0)+1;
  });
  return Object.entries(counts).sort((a,b)=>b[1]-a[1]);
}
let dashboardPeriodMode = 'all'; // 'all' | 'month' | 'year'
let dashboardPeriodValue = '';
/* ---- Attendance Overview (Dashboard) — day-by-day table ---- */
let dashAttClass = 'All Classes';
let dashAttSort = 'newest'; // 'newest' | 'oldest'
function setDashAttClass(val){ dashAttClass = val; renderPage(); }
function setDashAttSort(val){ dashAttSort = val; renderPage(); }
function computeAttendanceByDay(){
  let students = DB.students;
  if(dashAttClass !== 'All Classes') students = students.filter(s=>s.class===dashAttClass);
  const byDate = {};
  students.forEach(s => {
    (s.attendance||[]).forEach(a => {
      if(!a.date) return;
      if(!byDate[a.date]) byDate[a.date] = { present:0, absent:0, leave:0 };
      if(a.status==='Present') byDate[a.date].present++;
      else if(a.status==='Absent') byDate[a.date].absent++;
      else if(a.status==='Leave') byDate[a.date].leave++;
    });
  });
  let rows = Object.entries(byDate).map(([date, c]) => ({ date, ...c, total: c.present+c.absent+c.leave }));
  rows.sort((a,b) => dashAttSort==='newest' ? (a.date<b.date?1:-1) : (a.date>b.date?1:-1));
  return rows;
}
function attendanceOverviewHtml(){
  const rows = computeAttendanceByDay();
  const classOpts = attendanceClassOptions().map(c=>`<option value="${c}" ${c===dashAttClass?'selected':''}>${c}</option>`).join('');
  const tableRows = rows.map(r => `
    <tr class="ledger-row">
      <td data-label="Date">${new Date(r.date+'T00:00:00').toLocaleDateString('en-US',{weekday:'short', month:'short', day:'numeric', year:'numeric'})}</td>
      <td data-label="Present"><span class="tag present">${r.present}</span></td>
      <td data-label="Absent"><span class="tag absent">${r.absent}</span></td>
      <td data-label="Leave"><span class="tag leave">${r.leave}</span></td>
      <td data-label="Total Marked">${r.total}</td>
    </tr>`).join('');
  return `
  <div class="card">
    <h3 style="margin:0 0 12px;">Attendance by Day</h3>
    <div class="row2">
      <div>
        <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Class</label>
        <select onchange="setDashAttClass(this.value)" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;">${classOpts}</select>
      </div>
      <div>
        <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Sort By Day</label>
        <select onchange="setDashAttSort(this.value)" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;">
          <option value="newest" ${dashAttSort==='newest'?'selected':''}>Newest First</option>
          <option value="oldest" ${dashAttSort==='oldest'?'selected':''}>Oldest First</option>
        </select>
      </div>
    </div>
    <table style="margin-top:14px;"><thead><tr><th>Date</th><th>Present</th><th>Absent</th><th>Leave</th><th>Total Marked</th></tr></thead>
    <tbody>${tableRows || '<tr><td colspan="5" class="empty-state">No attendance records yet.</td></tr>'}</tbody></table>
  </div>`;
}
function periodMonthLabel(dateLike){
  const d = new Date(Date.parse(dateLike));
  if(isNaN(d.getTime())) return null;
  return d.toLocaleDateString('en-US',{month:'long'}) + ' ' + d.getFullYear();
}
function periodMonthOptions(){
  const months = new Set();
  DB.students.forEach(s => (s.fees||[]).forEach(f => { const lbl = periodMonthLabel(f.month); if(lbl) months.add(lbl); }));
  DB.expenses.forEach(e => { const lbl = periodMonthLabel(e.date); if(lbl) months.add(lbl); });
  return Array.from(months).sort((a,b) => Date.parse(a) - Date.parse(b));
}
function periodYearOptions(){
  const years = new Set();
  periodMonthOptions().forEach(m => years.add(new Date(Date.parse(m)).getFullYear()));
  return Array.from(years).sort();
}
function setDashboardPeriod(mode, value){
  dashboardPeriodMode = mode;
  dashboardPeriodValue = value || '';
  renderPage();
}
function feeInPeriod(entry){
  if(dashboardPeriodMode==='all') return true;
  const lbl = periodMonthLabel(entry.month);
  if(!lbl) return false;
  if(dashboardPeriodMode==='month') return lbl===dashboardPeriodValue;
  if(dashboardPeriodMode==='year') return String(new Date(Date.parse(lbl)).getFullYear())===String(dashboardPeriodValue);
  return true;
}
function expenseInPeriod(exp){
  if(dashboardPeriodMode==='all') return true;
  const lbl = periodMonthLabel(exp.date);
  if(!lbl) return false;
  if(dashboardPeriodMode==='month') return lbl===dashboardPeriodValue;
  if(dashboardPeriodMode==='year') return String(new Date(Date.parse(lbl)).getFullYear())===String(dashboardPeriodValue);
  return true;
}
function periodSelectorHtml(){
  const monthOpts = periodMonthOptions();
  const yearOpts = periodYearOptions();
  return `
  <div class="card">
    <h3>View Period</h3>
    <div class="row2">
      <div>
        <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Split By</label>
        <select id="periodModeSelect" onchange="onPeriodModeChange()" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;">
          <option value="all" ${dashboardPeriodMode==='all'?'selected':''}>All Time</option>
          <option value="month" ${dashboardPeriodMode==='month'?'selected':''}>By Month</option>
          <option value="year" ${dashboardPeriodMode==='year'?'selected':''}>By Year</option>
        </select>
      </div>
      <div id="periodValueWrap">
        ${dashboardPeriodMode==='month' ? `
          <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Month</label>
          <select onchange="setDashboardPeriod('month', this.value)" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;">
            ${monthOpts.map(m=>`<option value="${m}" ${m===dashboardPeriodValue?'selected':''}>${m}</option>`).join('') || '<option>No dated records yet</option>'}
          </select>` : ''}
        ${dashboardPeriodMode==='year' ? `
          <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Year</label>
          <select onchange="setDashboardPeriod('year', this.value)" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;">
            ${yearOpts.map(y=>`<option value="${y}" ${String(y)===String(dashboardPeriodValue)?'selected':''}>${y}</option>`).join('') || '<option>No dated records yet</option>'}
          </select>` : ''}
      </div>
    </div>
  </div>`;
}
function onPeriodModeChange(){
  const mode = document.getElementById('periodModeSelect').value;
  if(mode==='month'){ setDashboardPeriod('month', periodMonthOptions()[0] || ''); }
  else if(mode==='year'){ setDashboardPeriod('year', periodYearOptions()[0] || ''); }
  else { setDashboardPeriod('all', ''); }
}
function renderAdminDashboard(){
  const canSeeFees = SESSION.role==='teacher' ? false
    : SESSION.role==='staff' ? (SESSION.permissions||[]).includes('fees')
    : true;
  const totalStudents = DB.students.length;
  let totalDueAll, totalCollectedAll;
  if(dashboardPeriodMode==='all'){
    totalDueAll = DB.students.reduce((sum,s)=>sum+totalDue(s),0);
    totalCollectedAll = DB.students.reduce((sum,s)=>sum+totalCollected(s),0);
  } else {
    totalDueAll = 0; totalCollectedAll = 0;
    DB.students.forEach(s => (s.fees||[]).forEach(f => {
      if(!feeInPeriod(f)) return;
      if(f.status==='Paid') totalCollectedAll += Number(f.amount||0);
      else totalDueAll += Number(f.amount||0);
    }));
  }
  const totalExpensesAll = dashboardPeriodMode==='all' ? totalExpenses() : DB.expenses.filter(expenseInPeriod).reduce((sum,e)=>sum+Number(e.amount||0),0);
  const netBalance = totalCollectedAll - totalExpensesAll;
  const avgAttendance = totalStudents ? Math.round(DB.students.reduce((sum,s)=>sum+attendancePct(s),0)/totalStudents) : 0;
  // Quick actions — respects each role's permissions
  const qaAllowed = SESSION.role==='teacher' ? (SESSION.permissions || TEACHER_DEFAULT_PERMISSIONS)
                  : SESSION.role==='staff'   ? (SESSION.permissions || [])
                  : null;                     // admin / director = full access
  const qaCan = k => qaAllowed === null ? true : qaAllowed.includes(k);
  const qaItems = [
    ['students',    '\u{1F465}', 'Manage Students',    qaCan('students')],
    ['gatescan',    '\u{1F4DF}', 'Gate Scanner',       qaCan('attendance')],
    ['teachergate', '\u{1F3EB}', 'Teacher Attendance', qaCan('teachergate')],
    ['attendance',  '\u{1F5D3}', 'Mark Attendance',    qaCan('attendance')],
    ['results',     '\u{1F4CA}', 'Results',            qaCan('results')],
    ['materials',   '\u{1F4DA}', 'Study Material',     qaCan('materials')],
    ['assignments', '\u{1F4C4}', 'Assignments',        qaCan('assignments')],
    ['announce',    '\u{1F4E2}', 'Announcements',      qaCan('announce')],
    ['fees',        '\u{1F4B0}', 'Fee Ledger',         canSeeFees],
    ['expenses',    '\u{1F4B5}', 'Expenses',           canSeeFees && qaCan('expenses')],
    ['reports',     '\u{1F4CB}', 'Reports',            qaCan('reports')],
    ['quizzes',     '\u{1F4DD}', 'Online Quiz',        qaCan('quizzes')],
    ['admissions',  '\u{1F4DD}', 'Admissions',         qaCan('admissions')]
  ];
  const qaTiles = qaItems.filter(x => x[3]).map(function(it){
    return '<div class="quick-tile" onclick="goTab(\'' + it[0] + '\')">'
         + '<div class="quick-icon">' + it[1] + '</div>'
         + '<div class="quick-label">' + it[2] + '</div></div>';
  }).join('');
  // ---- who is signed in ----
  const whoName = SESSION.role==='admin' ? 'Director'
                : (SESSION.name || SESSION.username || (SESSION.role==='teacher' ? 'Teacher' : 'Administrator'));
  const whoSub  = SESSION.role==='admin'   ? 'Inspired Model School & Girls College'
                : SESSION.role==='teacher' ? 'Teacher'
                : 'Administrator';
  const whoInit = whoName.trim().split(/\s+/).slice(0,2).map(w=>w[0]||'').join('').toUpperCase() || 'D';

  // ---- period filter (same handlers as before) ----
  const periodTag = dashboardPeriodMode==='all' ? 'All time' : String(dashboardPeriodValue||'');
  const monthOpts = periodMonthOptions(), yearOpts = periodYearOptions();
  const periodBar = canSeeFees ? `
    <div class="sd-period">
      <span class="sd-label">Period</span>
      <select id="periodModeSelect" onchange="onPeriodModeChange()">
        <option value="all" ${dashboardPeriodMode==='all'?'selected':''}>All Time</option>
        <option value="month" ${dashboardPeriodMode==='month'?'selected':''}>By Month</option>
        <option value="year" ${dashboardPeriodMode==='year'?'selected':''}>By Year</option>
      </select>
      ${dashboardPeriodMode==='month' ? `<select onchange="setDashboardPeriod('month', this.value)">
          ${monthOpts.map(m=>`<option value="${m}" ${m===dashboardPeriodValue?'selected':''}>${m}</option>`).join('') || '<option>No dated records yet</option>'}
        </select>` : ''}
      ${dashboardPeriodMode==='year' ? `<select onchange="setDashboardPeriod('year', this.value)">
          ${yearOpts.map(y=>`<option value="${y}" ${String(y)===String(dashboardPeriodValue)?'selected':''}>${y}</option>`).join('') || '<option>No dated records yet</option>'}
        </select>` : ''}
    </div>` : '';

  // ---- stat cells ----
  const cell = (label, value, sub, cls) =>
    `<div class="sd-cell"><div class="sd-label">${label}</div><div class="sd-big ${cls}">${value}</div><div class="sd-sub">${sub}</div></div>`;
  const cells = [
    cell('Total Students', totalStudents, 'Enrolled', 'sd-green'),
    cell('Avg. Attendance', avgAttendance + '%', 'All classes', 'sd-green')
  ];
  if(canSeeFees){
    cells.push(
      cell('Fee Collected', fmtMoney(totalCollectedAll), periodTag, 'sd-green sd-money'),
      cell('Fee Remaining', fmtMoney(totalDueAll),       periodTag, (totalDueAll>0?'sd-orange':'sd-green') + ' sd-money'),
      cell('Total Expenses', fmtMoney(totalExpensesAll), periodTag, 'sd-orange sd-money'),
      cell('Net Balance',   fmtMoney(netBalance),        periodTag, (netBalance>=0?'sd-green':'sd-orange') + ' sd-money')
    );
  }
  cells.push(cell('Study Materials', DB.materials.length, 'Uploaded', 'sd-green'));
  const odd = cells.length % 2 === 1;
  if(odd) cells[cells.length-1] = cells[cells.length-1].replace('class="sd-cell"', 'class="sd-cell sd-span"');

  const attendanceCard = (function(){ try { return attendanceOverviewHtml(); } catch(err){ console.error('Attendance overview failed:', err); return '<div class="card"><h3>Attendance by Day</h3><div class="empty-state">Could not load attendance data. Check the browser console (F12) for details.</div></div>'; } })();

  return `
  <div class="sd-wrap">
    <div class="sd-user">
      <div style="min-width:0;">
        <div class="sd-label">Signed in as</div>
        <div class="sd-name">${whoName}</div>
        <div class="sd-sub">${whoSub}</div>
      </div>
      <div class="sd-avatar">${whoInit}</div>
    </div>
    ${periodBar}
    <div class="sd-grid${odd?' odd':''}">${cells.join('')}</div>
  </div>

  <div class="card"><h3>Quick Actions</h3>
    <div class="quick-grid">${qaTiles}</div>
  </div>

  ${attendanceCard}`;
}

let searchQuery = { students:'', fees:'', attendance:'', results:'', expenses:'', logins:'' };
let sortState = { students:'roll', fees:'roll', results:'roll', logins:'roll', expenses:'date-desc', attendance:'roll' };
function setSortBy(tab, field){
  sortState[tab] = field;
  if(tab==='students') refreshStudentsTable();
  else if(tab==='fees') refreshFeesTable();
  else if(tab==='results') refreshResultsTable();
  else if(tab==='logins') refreshLoginsTable();
  else if(tab==='expenses') refreshExpensesTable();
  else if(tab==='attendance') refreshAttendanceTable();
  document.querySelectorAll('.kebab-menu').forEach(m => m.classList.remove('show'));
}
function toggleKebabMenu(id){
  document.querySelectorAll('.kebab-menu').forEach(m => { if(m.id!==id) m.classList.remove('show'); });
  const el = document.getElementById(id);
  if(el) el.classList.toggle('show');
}
document.addEventListener('click', function(e){
  if(!e.target.closest('.kebab-wrap')){
    document.querySelectorAll('.kebab-menu').forEach(m => m.classList.remove('show'));
  }
});
function rollKey(r){
  // sort IMS-1001, IMS-1002 ... numerically (plain text sort puts IMS-999 after IMS-1001)
  const m = String(r||'').match(/(\d+)\s*$/);
  return m ? String(m[1]).padStart(10,'0') : String(r||'').toLowerCase();
}
function sortByField(list, field, getters){
  const [key, dir] = field.split('-');
  const get = getters[key] || getters.default;
  const sorted = [...list].sort((a,b) => {
    const va = get(a), vb = get(b);
    if(va < vb) return dir==='desc' ? 1 : -1;
    if(va > vb) return dir==='desc' ? -1 : 1;
    return 0;
  });
  return sorted;
}
let attendanceClassFilter = 'All Classes';
let attendanceDate = new Date().toISOString().slice(0,10);
function matchStudent(s,q){
  if(!q) return true;
  q = q.toLowerCase();
  return s.roll.toLowerCase().includes(q) || s.name.toLowerCase().includes(q) || (s.class||'').toLowerCase().includes(q);
}
function matchExpense(e,q){
  if(!q) return true;
  q = q.toLowerCase();
  return (e.category||'').toLowerCase().includes(q) || (e.description||'').toLowerCase().includes(q) || (e.date||'').toLowerCase().includes(q);
}
function updateSearch(tab, value){
  searchQuery[tab] = value;
  if(tab==='students') refreshStudentsTable();
  else if(tab==='fees'){ refreshFeesTable(); refreshFeeSummary(); }
  else if(tab==='attendance') refreshAttendanceTable();
  else if(tab==='results') refreshResultsTable();
  else if(tab==='expenses') refreshExpensesTable();
  else if(tab==='logins') refreshLoginsTable();
}
let studentsClassFilter = 'All Classes';
function setStudentsClass(cls){
  studentsClassFilter = cls;
  refreshStudentsTable();
}
function studentsFilteredList(){
  let list = DB.students.filter(s=>matchStudent(s, searchQuery.students));
  if(studentsClassFilter !== 'All Classes') list = list.filter(s=>s.class===studentsClassFilter);
  return list;
}
function studentsTableRows(){
  let list = studentsFilteredList();
  list = sortByField(list, sortState.students, {
    name: s=>s.name.toLowerCase(), roll: s=>rollKey(s.roll), class: s=>s.class.toLowerCase(),
    default: s=>rollKey(s.roll)
  });
  const rows = list.map(s => `
    <tr class="ledger-row">
      <td data-label="Roll No." class="mono">${s.roll}</td><td data-label="Name">${s.name}</td><td data-label="Class">${s.class}</td><td data-label="Phone">${s.phone}</td>
      <td data-label="Actions">
        <button class="btn small" onclick="showStudentProfile(getStudent('${s.roll}'))">👁️ View Profile</button>
        <button class="btn small gold" onclick="generateReportCard('${s.roll}')">🖨 Report Card</button>
        <button class="btn small" onclick="editStudent('${s.roll}')">Edit</button>
        ${['teacher','staff'].includes(SESSION.role) ? '' : `<button class="btn small" onclick="viewFeeHistory('${s.roll}')">Fee History</button>`}
        <button class="btn small danger" onclick="deleteStudent('${s.roll}')">Delete</button>
      </td>
    </tr>`).join('');
  return rows || `<tr><td colspan="5" class="empty-state">No matching students.</td></tr>`;
}
function refreshStudentsTable(){ document.getElementById('studentsTbody').innerHTML = studentsTableRows(); }
function viewFeeHistory(roll){
  const s = getStudent(roll);
  document.getElementById('feeHistoryTitle').textContent = `Fee History — ${s.name} (${s.roll})`;
  const withIdx = (s.fees||[]).map((f,i) => ({...f, _idx:i}));
  const sorted = withIdx.sort((a,b)=> (a.month<b.month?1:-1));
  const dueMonths = sorted.filter(f=>f.status==='Due').map(f=>f.month);
  const summary = dueMonths.length
    ? `<div style="background:var(--light-gray); border:1px solid var(--due); color:var(--due); padding:10px 12px; border-radius:14px; margin-bottom:14px; font-size:13.5px;"><b>Remaining / Due:</b> ${dueMonths.join(', ')}</div>`
    : `<div style="background:#e9f5e8; border:1px solid var(--ok); color:var(--ok); padding:10px 12px; border-radius:14px; margin-bottom:14px; font-size:13.5px;"><b>All recorded fees are paid.</b></div>`;
  const rows = sorted.map(f => `
    <tr class="ledger-row">
      <td>${f.month}</td><td>${fmtMoney(f.amount)}</td>
      <td><span class="tag ${f.status==='Paid'?'paid':'due'}">${f.status}</span></td>
      <td>${f.date || '—'}</td>
      <td><button class="btn small danger" onclick="deleteFeeEntry('${s.roll}', ${f._idx})">Delete</button></td>
    </tr>`).join('');
  document.getElementById('feeHistorySummary').innerHTML = summary;
  document.getElementById('feeHistoryTbody').innerHTML = rows || `<tr><td colspan="5" class="empty-state">No fee records for this student yet.</td></tr>`;
  openModal('feeHistoryModalOverlay');
}
function deleteFeeEntry(roll, idx){
  const s = getStudent(roll);
  const entry = s.fees[idx];
  if(!entry) return;
  if(!confirm(`Delete the ${entry.month} fee entry (${fmtMoney(entry.amount)}, ${entry.status}) for ${s.name}? This cannot be undone.`)) return;
  const updated = s.fees.filter((f,i) => i!==idx);
  sb.from('students').update({ fees: updated }).eq('roll', roll).then(async ({error})=>{
    if(error){ console.error(error); alert('Could not delete: ' + error.message); return; }
    await refreshStudentsFromServer();
    viewFeeHistory(roll);
  });
}
let feeClassFilter = 'All Classes';
function setFeeClass(cls){
  feeClassFilter = cls;
  renderPage();
}
function feeClassOptions(){
  const classes = Array.from(new Set(DB.students.map(s=>s.class))).sort();
  return ['All Classes', ...classes];
}
function feeMonthColumns(){
  const months = new Set();
  DB.students.forEach(s => (s.fees||[]).forEach(f => months.add(f.month)));
  return Array.from(months).sort((a,b) => {
    const da = Date.parse(a), db = Date.parse(b);
    if(!isNaN(da) && !isNaN(db)) return da - db;
    return a < b ? -1 : 1;
  });
}
function feeFilteredList(){
  let list = DB.students.filter(s=>matchStudent(s, searchQuery.fees));
  if(feeClassFilter !== 'All Classes') list = list.filter(s=>s.class===feeClassFilter);
  return list;
}
function feeMonthLabel(m){
  const d = new Date(Date.parse(m));
  if(!isNaN(d.getTime())) return d.toLocaleDateString('en-US',{month:'short'}) + " '" + String(d.getFullYear()).slice(2);
  return m;
}
function feesTableRows(){
  let list = feeFilteredList();
  list = sortByField(list, sortState.fees, {
    name: s=>s.name.toLowerCase(), roll: s=>rollKey(s.roll), balance: s=>totalDue(s),
    default: s=>rollKey(s.roll)
  });
  const months = feeMonthColumns();
  if(!list.length) return `<tr><td colspan="${5+months.length}" class="empty-state">No matching students.</td></tr>`;
  return list.map(s => {
    const monthCells = months.map(m => {
      const entry = (s.fees||[]).find(f=>f.month===m);
      const label = feeMonthLabel(m);
      if(!entry) return `<td data-label="${label}" class="fee-cell fee-na" title="No fee recorded for ${m}" onclick="openFeeModal('${s.roll}','${m}')">–</td>`;
      if(entry.status==='Paid') return `<td data-label="${label}" class="fee-cell fee-paid" title="${m}: ${fmtMoney(entry.amount)} — Paid${entry.date?(' on '+entry.date):''}" onclick="openFeeModal('${s.roll}','${m}')">✓</td>`;
      return `<td data-label="${label}" class="fee-cell fee-due" title="${m}: ${fmtMoney(entry.amount)} — Due" onclick="openFeeModal('${s.roll}','${m}')">✗</td>`;
    }).join('');
    return `
    <tr class="ledger-row">
      <td data-label="Roll No." class="mono">${s.roll}</td>
      <td data-label="Student"><b>${s.name}</b><br><small style="color:var(--ink-soft);">${s.father||''}</small></td>
      <td data-label="Class">${s.class}</td>
      <td data-label="Fee/mo">${fmtMoney(s.feeAmount)}</td>
      ${monthCells}
      <td data-label="Balance" style="font-weight:700;">${fmtMoney(totalDue(s))}</td>
    </tr>`;
  }).join('');
}
function refreshFeesTable(){ document.getElementById('feesTbody').innerHTML = feesTableRows(); }
function refreshFeeSummary(){
  const el = document.getElementById('feeSummaryWrap');
  if(el) el.innerHTML = feeSummaryHtml();
}
function feeSummaryHtml(){
  const list = feeFilteredList();
  let collected, due;
  if(dashboardPeriodMode==='all'){
    collected = list.reduce((sum,s)=>sum+totalCollected(s),0);
    due = list.reduce((sum,s)=>sum+totalDue(s),0);
  } else {
    collected = 0; due = 0;
    list.forEach(s => (s.fees||[]).forEach(f => {
      if(!feeInPeriod(f)) return;
      if(f.status==='Paid') collected += Number(f.amount||0);
      else due += Number(f.amount||0);
    }));
  }
  return `
  ${periodSelectorHtml()}
  <div class="grid-cards">
    <div class="stat"><div class="label">Students (${feeClassFilter})</div><div class="value">${list.length}</div></div>
    <div class="stat ok"><div class="label">Fee Collected${dashboardPeriodMode!=='all'?' ('+dashboardPeriodValue+')':''}</div><div class="value">${fmtMoney(collected)}</div></div>
    <div class="stat due"><div class="label">Fee Remaining${dashboardPeriodMode!=='all'?' ('+dashboardPeriodValue+')':''}</div><div class="value">${fmtMoney(due)}</div></div>
  </div>`;
}
const MONTH_ALIASES = {
  january:['jan'], february:['feb','fab'], march:['march','mar'], april:['april','apr'],
  may:['may'], june:['june','jun'], july:['july','jul'], august:['august','aug'],
  september:['september','sep','sept'], october:['october','oct','out'], november:['november','nov'], december:['december','dec']
};
function monthMatchWords(monthText){
  const first = monthText.trim().toLowerCase().split(/[\s,-]+/)[0];
  for(const [full, aliases] of Object.entries(MONTH_ALIASES)){
    if(full===first || aliases.includes(first)) return [full, ...aliases];
  }
  return [first];
}
function parseFeeRegisterSheet(sheet, monthWords){
  const gridRows = XLSX.utils.sheet_to_json(sheet, {header:1, defval:'', raw:false});
  let nameCol=-1, headerIdx=-1;
  for(let i=0;i<gridRows.length;i++){
    const row = gridRows[i];
    const nc = row.findIndex(c=>String(c).trim().toLowerCase()==='name');
    if(nc>-1){ nameCol = nc; headerIdx = i; break; }
  }
  if(nameCol===-1) return null;
  const headerRow = gridRows[headerIdx];
  let amountCol = -1;
  for(let c=0;c<headerRow.length;c++){
    const h = String(headerRow[c]).trim().toLowerCase();
    if(!h) continue;
    if(monthWords.some(w => h.includes(w))){ amountCol = c; break; }
  }
  if(amountCol===-1) return null; // this sheet has no column matching the requested month
  const results = [];
  for(let i=headerIdx+1;i<gridRows.length;i++){
    const row = gridRows[i];
    const name = String(row[nameCol]||'').trim();
    if(!name) continue;
    if(/total|sub|gross|share/i.test(name)) break;
    const amountRaw = Number(String(row[amountCol]||'').replace(/[^0-9.]/g,''));
    results.push({ name, amount: amountRaw });
  }
  return results;
}
function handleFeeImportUpload(evt){
  const file = evt.target.files[0];
  if(!file) return;
  const month = document.getElementById('feeImportMonth').value.trim();
  if(!month){ alert('Please enter which month this import is for first.'); evt.target.value=''; return; }
  const reader = new FileReader();
  reader.onload = async e => {
    let wb;
    try{ wb = XLSX.read(e.target.result, {type:'array'}); }
    catch(err){ alert('Could not read Excel file. Please check the format.'); evt.target.value=''; return; }

    // Try the simple/clean format first, using whichever sheet has the most content.
    const firstSheetName = wb.SheetNames.find(n => {
      const r = XLSX.utils.sheet_to_json(wb.Sheets[n], {header:1, defval:''});
      return r.some(row => row.some(c => String(c).trim().length));
    }) || wb.SheetNames[0];
    const firstObjRows = XLSX.utils.sheet_to_json(wb.Sheets[firstSheetName], {defval:'', raw:false});
    const hasCleanFormat = firstObjRows.length && Object.keys(firstObjRows[0]).some(k=>k.trim().toLowerCase()==='amount');

    let normalized, hasStatusColumn;
    if(hasCleanFormat){
      normalized = firstObjRows.map(raw => {
        const row = {};
        Object.keys(raw).forEach(k => row[k.trim().toLowerCase()] = String(raw[k]).trim());
        return row;
      });
      hasStatusColumn = firstObjRows.length && Object.keys(firstObjRows[0]).some(k=>k.trim().toLowerCase()==='status');
    } else {
      // Multi-sheet fee register: each sheet may be a different class, with one column per month.
      const monthWords = monthMatchWords(month);
      let combined = [];
      let sheetsMatched = 0;
      for(const sheetName of wb.SheetNames){
        const parsed = parseFeeRegisterSheet(wb.Sheets[sheetName], monthWords);
        if(parsed && parsed.length){ combined = combined.concat(parsed); sheetsMatched++; }
      }
      if(!combined.length){
        alert(`Could not find a column matching "${month}" in any sheet of this file. Check that at least one sheet has a column header containing that word (e.g. "May", "July").`);
        evt.target.value=''; return;
      }
      normalized = combined.map(r => ({ name:r.name, amount:String(r.amount||''), status:'', roll:'', date:'' }));
      hasStatusColumn = false;
    }

    let updated=0, noMatch=0, ambiguous=0, skipped=0;
    const noMatchNames=[], ambiguousNames=[];
    try{
      for(const row of normalized){
        const name = row.name;
        if(!name){ skipped++; continue; }
        let student = null;
        if(row.roll) student = DB.students.find(s=>s.roll.toLowerCase()===row.roll.toLowerCase());
        if(!student){
          const matches = DB.students.filter(s=>s.name.trim().toLowerCase()===name.toLowerCase());
          if(matches.length === 0){ noMatch++; noMatchNames.push(name); continue; }
          if(matches.length > 1){ ambiguous++; ambiguousNames.push(name); continue; }
          student = matches[0];
        }
        const amountRaw = Number(String(row.amount||'').replace(/[^0-9.]/g,''));
        let status, amount;
        if(hasStatusColumn){
          status = /paid/i.test(row.status) ? 'Paid' : 'Due';
          amount = amountRaw > 0 ? amountRaw : student.feeAmount;
        } else {
          status = amountRaw > 0 ? 'Paid' : 'Due';
          amount = amountRaw > 0 ? amountRaw : student.feeAmount;
        }
        const entry = { month, amount, status, date: row.date || '' };
        const current = student.fees || [];
        const idx = current.findIndex(f=>f.month===month);
        const newFees = idx>-1 ? current.map((f,i)=>i===idx?entry:f) : [...current, entry];
        const { error } = await sb.from('students').update({ fees: newFees }).eq('roll', student.roll);
        if(error) throw error;
        updated++;
      }
      if(updated>0) await refreshStudentsFromServer();
      let msg = `Import complete: ${updated} student(s) updated for "${month}". ${skipped} row(s) skipped (missing name).`;
      if(noMatch) msg += `\n\n${noMatch} name(s) didn't match any student: ${noMatchNames.join(', ')}`;
      if(ambiguous) msg += `\n\n${ambiguous} name(s) matched more than one student (skipped — update manually): ${ambiguousNames.join(', ')}`;
      alert(msg);
    } catch(err){ console.error(err); alert('Could not save some records: ' + err.message); }
    evt.target.value='';
  };
  reader.readAsArrayBuffer(file);
}

async function deleteMonth(month){
  const affected = DB.students.filter(s => (s.fees||[]).some(f=>f.month===month));
  if(!affected.length){ alert(`No students have a "${month}" entry.`); return; }
  if(!confirm(`Delete the "${month}" column entirely? This removes that month's fee entry for all ${affected.length} student(s) who have one. This cannot be undone.`)) return;
  try{
    for(const s of affected){
      const updated = s.fees.filter(f=>f.month!==month);
      const { error } = await sb.from('students').update({ fees: updated }).eq('roll', s.roll);
      if(error) throw error;
    }
    await refreshStudentsFromServer();
    alert(`Done. Removed the "${month}" entry from ${affected.length} student(s).`);
  } catch(err){ console.error(err); alert('Something went wrong partway through: ' + err.message); }
}
async function addNewMonth(){
  const existingMonths = feeMonthColumns();
  const month = prompt('What should the new month/installment column be called? (e.g. "August 2026")');
  if(!month || !month.trim()) return;
  const trimmed = month.trim();
  if(existingMonths.some(m => m.toLowerCase() === trimmed.toLowerCase())){
    alert(`"${trimmed}" already exists as a column on the Fee Ledger — no need to add it again. You can use "Generate Pending Fees" if some students are still missing it.`);
    return;
  }
  const list = feeFilteredList();
  if(!list.length){ alert('No students match the current Class/search filter to add this month for.'); return; }
  if(!confirm(`This adds "${trimmed}" as a new column, with a "Due" entry at each student's normal monthly rate for all ${list.length} student(s) currently in view (${feeClassFilter}). Continue?`)) return;
  try{
    for(const s of list){
      const updated = [...(s.fees||[]), { month:trimmed, amount:s.feeAmount, status:'Due', date:'' }];
      const { error } = await sb.from('students').update({ fees: updated }).eq('roll', s.roll);
      if(error) throw error;
    }
    await refreshStudentsFromServer();
    alert(`Done. "${trimmed}" is now a column on the Fee Ledger for ${list.length} student(s).`);
  } catch(err){ console.error(err); alert('Something went wrong partway through: ' + err.message); }
}
async function generatePendingFees(){
  const month = prompt('Generate a "Due" fee entry for which month? (e.g. "August 2026")', new Date().toLocaleString('en-US',{month:'long'}) + ' ' + new Date().getFullYear());
  if(!month) return;
  const list = feeFilteredList();
  const needsEntry = list.filter(s => !(s.fees||[]).find(f=>f.month===month));
  if(!needsEntry.length){ alert(`Every student in view already has a "${month}" entry.`); return; }
  if(!confirm(`This will add a "Due" fee entry of their standard monthly rate for ${needsEntry.length} student(s) who don't yet have a "${month}" entry (${feeClassFilter}). Continue?`)) return;
  try{
    for(const s of needsEntry){
      const updated = [...(s.fees||[]), { month, amount:s.feeAmount, status:'Due', date:'' }];
      const { error } = await sb.from('students').update({ fees: updated }).eq('roll', s.roll);
      if(error) throw error;
    }
    await refreshStudentsFromServer();
    alert(`Done. Added a "${month}" Due entry for ${needsEntry.length} student(s).`);
  } catch(err){ console.error(err); alert('Something went wrong partway through: ' + err.message); }
}
function printClassFeeRecord(){
  const list = feeFilteredList();
  const months = feeMonthColumns();
  const collected = list.reduce((sum,s)=>sum+totalCollected(s),0);
  const due = list.reduce((sum,s)=>sum+totalDue(s),0);
  const rows = list.map(s => {
    const monthCells = months.map(m => {
      const entry = (s.fees||[]).find(f=>f.month===m);
      if(!entry) return `<td>–</td>`;
      return `<td>${entry.status==='Paid'?'✓':'✗'}</td>`;
    }).join('');
    return `<tr><td>${s.roll}</td><td>${s.name}</td><td>${s.class}</td>${monthCells}<td>${fmtMoney(totalDue(s))}</td></tr>`;
  }).join('');
  const monthHeaders = months.map(m=>`<th>${feeMonthLabel(m)}</th>`).join('');
  const body = `
    <h1>Inspired Model School &amp; Girl College Larkana</h1>
    <h2>Fee Ledger — ${feeClassFilter}</h2>
    <div class="meta">Printed: ${new Date().toLocaleString()} &nbsp;|&nbsp; Students: ${list.length} &nbsp;|&nbsp; Collected: ${fmtMoney(collected)} &nbsp;|&nbsp; Remaining: ${fmtMoney(due)}</div>
    <table>
      <thead><tr><th>Roll No.</th><th>Name</th><th>Class</th>${monthHeaders}<th>Balance</th></tr></thead>
      <tbody>${rows || '<tr><td colspan="4">No students found.</td></tr>'}</tbody>
    </table>
  `;
  openPrintWindow(`Fee Ledger — ${feeClassFilter}`, body);
}
function attendanceTableRows(){
  let list = DB.students.filter(s=>matchStudent(s, searchQuery.attendance));
  if(attendanceClassFilter !== 'All Classes') list = list.filter(s=>s.class===attendanceClassFilter);
  list = sortByField(list, sortState.attendance||'roll', {
    name: s=>s.name.toLowerCase(), roll: s=>rollKey(s.roll), pct: s=>attendancePct(s),
    default: s=>rollKey(s.roll)
  });
  const rows = list.map(s => {
    const todays = (s.attendance||[]).find(a=>a.date===attendanceDate);
    const status = todays ? todays.status : null;
    return `
    <tr class="ledger-row">
      <td data-label="Roll No." class="mono">${s.roll}</td><td data-label="Name">${s.name}</td><td data-label="Class">${s.class}</td>
      <td data-label="Attendance %">${attendancePct(s)}%</td>
      <td data-label="Today's Status">
        ${status ? `<span class="att-status-badge att-${status.toLowerCase()}">${status}</span>` : `<span style="color:var(--ink-soft);font-size:12px;">Not marked</span>`}
      </td>
      <td data-label="Mark" style="display:flex; gap:6px; flex-wrap:wrap;">
        <button class="btn small ${status==='Present'?'gold':''}" onclick="quickMarkAttendance('${s.roll}','Present')">Present</button>
        <button class="btn small danger ${status==='Absent'?'active-danger':''}" onclick="quickMarkAttendance('${s.roll}','Absent')">Absent</button>
        <button class="btn small" onclick="quickMarkAttendance('${s.roll}','Leave')">Leave</button>
      </td>
    </tr>`;
  }).join('');
  return rows || `<tr><td colspan="6" class="empty-state">No matching students.</td></tr>`;
}
function refreshAttendanceTable(){ document.getElementById('attendanceTbody').innerHTML = attendanceTableRows(); }

/* ================= AUTO-GENERATED REPORT CARD ================= */
const DIRECTOR_SIGNATURE = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUkAAACmCAYAAABX731LAABSoklEQVR42u29XZBd13kltta3z73dDUIUNyVREiSL8hH4I1CkJB+SojUaw57pmbhSzsMkaacqlZdUqjipVFzOjMcjypLcgEhK4nhULtfkRXpKVR5SpX5JUq6UU+mZMTIam/q5oSSaGFKij0yPLEiizE2RAPrnnv2tPOxzbzdAkMQfATR4VhUkoNl9+9599v7297O+9QEDBgwYMGDAgAEDBgwYMGDAgAEDBgwYMGDAgAEDBgzYuzh8eBVN8+VhIQZc97BhCQZcGAQA+CsgvoQfNXfc+7kaK1+df33AgDexkRwOwQAAOAIAWDj5FhAGuNV3/tX/FwEOe2TAdQkOSzDgQnHo8Cr85HgZniNNSQBugK9PJkeHxRlw3aE6Xy/ynnuOxBh/NR079mvDqr1Jw+y6eQiL+xfRvVwt01CzYpQAF/ByNW4BtMM6DXhThtu33Xuk3hovNM/jT4eQ6k2IVazitnuP1CNbbPKpqiEVQY8EI0CYEXma47BSA96kRnIVAeNICdXphXqI0N98+F9ufT8CxtG6Ct4p0ghKcAEQolwYB0VgdVisAW8+I1nfizpn1MgeN7yrDz2wGne8ycGrfDNg8d0/qQVGBNTjkdUkaijUgBqRDWi1stW331/Vs4t1wIA3gZEsBnABizEQEQF1BdY5V8sfaB5tVla+isGrfJNskul2De9ql9Uui+4hiooAQSlCaGCMcNZ3fPwxAEeHC3TAm8eTnHYODzlKFkXUdNXBWX+3fWb5jnsfbg7evRrPNqwDrjMwRBlq0pGRI+A1hUigJlkTquVqJNSabi8fWlkdLtAB1w1eu7q9ugr7Pz3SUYNeS0gAU7AOkiWYxWphhFvvW/0K9iE9d2w4GNcXBIAQvaYzopi+SACgagk1SAAEDbUBNUDk754elm7AdYPwKtYRwK/hjs1frw1oQN1F2H9G8i6AkSBgjAAihHrs3FTuNt/23v8ULxycbuK554aVvS4MJHDrhxErQ0MwClgiDCIOEKhpXAIE0CBpk8QmHGn/wi/8+xMn/nhYwgHXe7gtcDqNgBqCNa18K4laYA2hBlALiKBF+kJdTbeXP7T5D+Phw0Pi/jqJswEgUiEBTBCjw6MAQOztKHeZVAIGnKp+0pQ9cBjl/4f9MOC6M5JHccfH/wVKFdOjZLXk88MgqgYVBUVCUYZoRETFmF0rP3l51Oz2RgbsVQMpLFZVTQigenvISDGenXIk+4tVBLzCiVMLze33Ly//+BSa2x4YDRzKAdefJ5m70xCYHAShOMtPce47IPZfipCDEuBIykJ29YfiyLDCezbU/iruaB6rhVLFhhRJgFQilXYczZkPSQCWXEjIHQJyNLdotBg6xgce+BKGYs6A68pI7nvrfgQyGhlLqD0TMCghmMQICBISxIawSDeIhqrCEGLtcS/ynnueA8NWTQQ4FAGLoAElN1nSLOKufYHa5TWlWSomSgBhcHXx1Knt/qIdoosBewvVub0IYvvFaQ1XI6IhsctAahZeRcCaUvEGQCxn08SoJFj88OGb4neO/ZM0LPHexOb4dEMPkci1g5EEJI8QCpn8HKo/BJdpigJhtARmyJnoIZ0ab7aDgRxwXXmS3gmA4u6Q6lw/TjIWOohqErXEKHmcnjxVF8L5gL0IL0RxQJYIJEk412V5hpEsOcsGYsw5R7pFkVGmWGm8fOjQkSHkHnA9GMlyAL73xKfbYPoKxXWXJ3CHLSQRUjlK/aGJAGsUnlztYO2G5jvt95sh7N6beHn75xNCqVSsBcFaiNDurPQ5oUQDUNgQka5IABY8TsehHlZ2wF7Dq/AkjwJYxfM/OnLiHe/51RayTxA4sNtj4Curm0uAalA1gQQgkorveM9o867b/psTzz33v/evO2Av4NRP/iFufv8IcoEZSxaYAG2CWKLUU8L8lQaTXJIQAS0ZABERJCSDgUu3/MKvbt5y06+k55//02E/DNjLRhIAjgEAfvajf3vi7e/+ewBwAMQmgIRZxfMVPihhDEuQ7iIZKSZJeDm/lP72bw6n4lUeG1Z9T+D/xd/+d59It7SEy0roTW4KfgJABHjgFTclgPJtiiQjwViI57YkOkgml6Lt04nnf/hrm8MaD9jjRnK+7fG29/y7msSmhE1ASyQPvNb394cnln+xDZmbt977X7UnvvfPhhXfSzh2DD/7m19Jt7yPAG2pdxwjgBOADrB/xmeHFIUviSWQkQIkbBLYZGFFJMqWDr7vN9p3vvO/wNCZM+Bax3noSRKkTUC0IFuCrYC2T0q+5s+JqI1eI3jEiR8Nq70ncRS3LOYWDAlACmQCBTNOJE1eWeFWzzm3skWIqEJEjwAjaLXA+sXp5vLLfH757nu/UM8v1wED9qaRFJ7+5u+15phAngQlgokWXn9jSxDYOFiPfnLjsNp7EsKxY0dxQ3fzBFVIkECEJAdIppJ+YW8eAe1waUHb9XcSgmBwSBmuHAHFzjyurg6qQQP2tJE8AgDofJrmvoIUS5via1Y5UfKSinTFn75zisFj2Isoz3gy+cd45+LmpBNbiElCKzABaCEkoe+6EhKkVBoNiJkRlQMGJFDINEgBFJJbTn/6p8MqD9jTRrJgNFoEaWmnh1fnd8CERCKNTg6ewl7HsWNHMaKS1AEmAA4BCcQEQELvWaq0MSZoxq8U0EcgLqTgSBaUGLrEXKVjx4Yq94DrwJPcttx7CEggknZ5Ga9jJ+tMAxZP1zjfnxlwzYXcAPDhD/9hdDlEAkTqizKzHqxWUntmtKAEorXicSITIEIiKrgMcqCbvjws74BrGtX5fuPiqYDpaJpAw0wU5rzsHRGDPGo0HpRg9njIPZ2+mHKFBITWoJpm65IaQRECrOQdE6QIWPE2heRSIiwJGTJCUgKV5EjP3vZswrfPdzMNGHBNepKF0vHkk59KHgQTeuksnlfILRBOwpXr933iC4Oh3MM4fvwovjdBi7DQTt3a7Ggr45pJa4QmUN9EUIR5S4GvaEzGIpLBaDIQxRv1PE5YWxsWdsBeN5Lllr/nnj+I6qroxS6el7FjMaSJ8BjAuHQqD3SPPY+j+N43frfdNx2vB9uedFIR5PUZNcyAIqkGSaXa7eVONQlFUW8EYjM9++1PpyEFM+A6MJJHilkbb8QqKJYk/PlBEArxg9Fh0SE0zYMYdCb3OoTvfvd3cfybR9N0a6HdMXEOUi2gdNZtuSsu8Vihw8hCGi7LAdeJkey/cZohL7QOwdKMKfz6gTojBIhKwVCf9tvirDd8wF7F7Lmvov3u76ZQ7Z/QbGYYE8BEoPwhk4EJ6ilBJDohbnaIgwc54LryJLetSiASzBPlUaWH+7X9DQksmtW1gTXAKG3XaL48eJPXSegNAH/x9f8pOaZtL6mWXExZPclcgFMQEYtGr8OIOMY43nnf54cc9YDrwUgWf/CWG7tkYAsygUjG8ytta5bDlBpAtQdv3rf0wuBFXGdYnO6biJZkTMbcypEktqISBZiYiCKzRyERiu5b9aH7VuMQVQy4DsJt4tixo3CgNWoiYHJ+2SSBRgiMgiLIBmQ92ths7rnnd+bfM2Dv4x999yQUuA5XggAzQlCkkFwzXq0iRZCAi9E0qh0LzQMPDC2rA/a8kSx4evKZpMxEMGE2tuF17aRQ1GJYA4pG1YHjuLl40/IdH38Mg0d5PUA4iqNYOG0pBEugJesbDwREY6GMFTpYz4ygUjaC0659/PF/OlyWA64PI4l5uKSSnzxfzKTTxCgpmlTDEbW9ufyBX/pcc+jQEG7tbRDAKu688wNJU7YSAGMiPZWORPbyF2WmohOQGAnHaeXhohxw/RjJOz7+GGCIokVd0Mbu+3epYijptRE1xTgKqrslDPzJ6wBra78Jh5LNtYBCAtmCXr7S08cERmeZ0b04GtXlkhwM5YA9bSTL5g7TaUMhCh4hv8DiS5HTojERjCqdOzVFVDYMr9/7OAIAqBYIMsB6myigTExUETspkbai9Rxak2Fp6cSwfAP2upEsxtBhSaYkqgWYBE8X6IxGSbVAUIhAVQuonYi3PfBIfLUpfAP2EFxwzxAcjhwJRRgxo4wV40iYGCGLQo4nFz4wrNuAaxbhQr75vbf8PXgQ5JaMSBSXRI8El87fn2Q0YQnAEoi7XIh0bgKM7zrwayee/9HhYfbJnsUxvP3Ar0aCy042AJYEWyK8jHIANsvXitwezZfEENFNDyzd+pHjL/3w8WEJB+xtI/njH/+bzVve9xubGdMlg0UISzQuCThw/oE3i6Q/uCTpBMlN0uHOJHHpbQf+bvrbE8cGQ7nn8KcAjuKG9/wKKtlvi1gi2JJ2gMRSCb25RHHTDJuQDhQhXlsCuVnlBbz/wOETJ04Mg+IG7MlwewfVaU9wRlFQ8L6r5gIq3bMqJxVpjMVmMtJQV4Y4WqiG/OQexqItRtFAMIHEfBYSCRoACnJFFL5kzPSEzGQEXhoNuekB14GRHI1OwmiQq3RR6EIM5JmG0mg1gEZEJDy6GLHlsWlWMeQm9xqOlA01nbWsAhQid8286Q1mnM/iBiOlOpuDQLSpmiKAMmDAnjWSwuQ3gGBqKUJgEnu18ouA5DCGCKGBLIoetxXqNMZQxNmjIB2El77+3hiWJIsAIYrsDSQiyZKjZogZAVkBGxvvHhZxwN72JHH0KDaIFIJaOBJgrYS22LML57pJDtAigFpiYwHR8kzF/MjwhPYYph178rhF7HTXRAejep1JABFURGlVrakcIUYLiqdGGELuAXvZSBbv7gdf/3RyZzIyUUospLjzkk97JXwmzluDBKgYXMt1sxpnKjMD9tCGqryflFhIkhJq9R037FWBOFO1FyOkKLPIKke6YlXNGgsGDNirnmRvBDf2T1sHk8Ak9b3cLNPxLpRkLjlIiwRqOiPINOJwWPYwIqnYBxfJiAiVPxSj3FFk81SLjHAHOosAMMI4HvzEo3GW3hkwYA8ayYLnjh1NHjIAge6pzGC+kHGz54q9vZY8UgA9DE9nr6IPs4vHiOSuBDICgihArAnWMEQCEURtJpT2RcTx9hByD7gOjCQABFcKDsBCEpEkJPIie3BLMr8MjoIibYRBZ3AP2kcGYBZdwBPlPRUIEFBLqFE8S3BHmDe6WAaIOeA+e7Ujw4IO2KtGsniK1eKolRnkDuun4fEiX49gyWsCycHUhWkCjg9PaI8hK0RiNgiMEbRIsXiQmHXw74o2pFYA6IhS8ShHyMNCDtjrRrJsc3t5EU4r3mNJRUbpYl9PIBgB1ibHSzcutcDaGUZ5wF6ItDNm5pAUBJQq9iwTM89Xs595IxgBBUSUKZzRBxs54HoJt6vqxeQ2nXjRlkxwXfQEvDJ+lDWoGkBz8wvbK0X0YhUDZ3IvbahqpohWjKDUU4EUBUaYlf+Hl0ibqEuOEjWhCFjcCiEeOrw6hNsD9rqRFCaTowjZEotefwvjpOd4XGTIDQjWAFh2qak6PfjBe8ODt33sc/WOBzIYy2sTRwEI46lNAK2RSDujZXdCbcj7FGXJPsORQEU6evE0x4i53jy5NDQUDNjrRrJs4Lvr25McE2UlCElCe2nhmkCzhtSKaCuCrVjHBz/YHG12/94B12aw/d3v/i5uwC1rckxIRJRRHyAsqhTnyiR2clcF25KAZFAiHZ1bGpsPyzngmkB1qS+wtvabuKN5dGa7EqhWrsie8nGxoTctFJ4kA6RpdATc/tFH49aN25PnjjENj+7axU9GJ3FDx8gyxgFwQXOPUsC8kDMzlGoFJFAQiMoYx/u2hoUcsNc9yV1GjQLME+AJLKIXF00FmhtK7/90ANgAWIb5yvjl0XL9y38w8OiuYYQNi5IiqER5KtSu+WYpjVWzoIDsGxDmcUR0IZ76+bj/2pFhQQfsfSM5DmzhSE4mZqXLPa6kVElVkvtUPd6aNh/62KODobxGMa5eqo0AvXAguStFsnN39jlJzcve0cU6SABytLAd77nnD4bFHHD1L/1L+/HSW/3Tv/k36W2/8CswMQE8AHAJUn35jCVBcIkkQEtkPrFZdent7/07+MV3/r3NQaj12sLb3v0PDoDegNgULZFaKnJ4ZyvYEySWAGyqGNBNkEvmOAHYUhd86W9P/P4wAGfA3vckAQEdWnZKBrYEWhEJvIwuJYEyjhYRUD3uLFpeaDZQNQfvX915HwOu/qYKAmEJQhvoLcREIAlKZ/b19wLMYrSSw46Aohtq9v3fB+//4tDHPeB6MJJEtYGUYRGh1xHUnORx+d6shSh6I7GWc1kaRUeoLVtTeHXDWNJrATm9ZUJhPZglySGotKyKSXC8wlASJYfppZBDAAylMYEc+rgHXBdGEsA73oEQrO/RZXwjDJbkAFhDVgOMQbmG5Uiz2k8vNPfc8zvDE73qEJ599rdxejtMHLllrxRFsi21a/b8yTP3B2mRZK0SMkSXIsEYfKACDbhejOQtz0Nw5EwUUQNAb0iIRMC0TKJxIkpWU6opb3whNs1vfHl4qtcAFscj0EMUCc5J5bsV7JXONq7FiCIKhtLvDYSuGxZzwFXFZdMje9/Sf42pbUZQS6AOADxA8A0JlXoJ1xriXX27210wwYHYvbxx4Jbb//Pjzz/3fw1P96qgdN787YmPb77jXf/3CXB8wKgEYRNlgmIq0zUJAEu7PcpejPcAaZv9g14ChXjL3z/xwn//bzZx7E8xCDEP2KNGUjhwYAKF00sSD5TxoUWin7ClN+KNE4CZLZWRpXaAjgiwFrTZbW3gF275lfSTnxzbLAn/4WBdeUN5FD/78b/bfOeBXz7hthCRualKJygsAVxiEbNYOldwQ9oBQHdBWAK5aVVY+tnfdMfx3K8NSztgr4bbxGTyj+Evb7cOJdAiSzta+0ZWJWeEc8gBoiaQSNYjY7M5HvXK5keGp3wV8dS3Hk0LW1sTWZioYy+CMgu7ec4Lt28gAOQ1gBq5i3e9tDQo1Q/Yy0aybO7jx4+WzFKvccErWm0mBEUUNzaaVN9532pdvJpBvPfqQfjOd44mOJP6MbLzWdyveoH2+8ZKEYdkzCHHgwf/aFjOAXvZSBaMgQnBiaR2Z9zsFTCWBAhrJNSCagmNe7V8x8e+UA/h9tVEefbPPPHJFMgEm491iK9nXClEAbXTo1xNeOtG700Ol96APWkk2YdXn02OaVtUxgkIibQ3/pOUkBsQG4HLIhojGsvT5uBHHh0O17VgLitPcLbSeXIfaSgiGKEmEamuOXT4f8asODRgwJ70JAFhab+3BFrAWpDJrwjXjYAEkqBZJLgsYFnislVsDn1kCL2vJg4e/C14l4sYyvkSxEvKJlIe+7bF2J16cXlHiHnAgD1pJIHq5IHkYgspQZ4AXRlvsjfSs/nfRqsBNoauzqPR8sH7Hx1C7yuO4vGFm95RmzMGzELt8/AEJTCEfoCY6kzWlDf33LN/WNYBe9lIEj/b/yOQgEGtyAmpVLplruzhlABRNYRGUqLU3PlLX2je94mHhn7gKx1qs4KC1V7mqZ93nlqeAbIOtEjlCHJoUxyw143kKp47BoSuSw4k0pPEFmC6GiFSL/waTWxMiGKulzaWmvc+8E+GkO1KPgfrYJoXbGKJLHSem1RQmYcDijh94/ZgKAfsZSP5OQBHsT1GS7PW8+xXXIUe3JmyaxHDro2oAxhpxOJNQ7vblUTuQplvU5r7o/qUyPk8QxcS5MlkSUBbbXHgTA7Yy0ayeAfPfuMoLGwlGiYk27Ms15WKuMvAACGWv+fknpM7074fjYenfwXhYbuIMgsXJ8pMxjIoTAiaDgs6YC8byR0cf/yutqumLQO/IvEhyddLyfJKGcoycIpETaIWLIoW4SFuL9zYHDq0Gh944Es4+OsDSfmNRpVHEHKdwYYXcldKoFmEVIs5Ghklw62HB5bCgCu0d9/Yl/9N/OXj8+mJkzt/6ZGJ4F8kbPnKFU0EWhWVc0MQIlqym8irtltC/fO83Y7/dgMAJsN2eAMzH3kUQ6XaoZoMuKBCXokIasoAClmow89DAmZtr0NuecAe9SR38FUAq+icLYkE5Su6sfsKKQBFGmBkdOQSBgoxA/H2+x+ud6cLBlwuHAEAhNE0CmguboUF0mb8yigy2jic8foDLmw9B1xzRvIpzPiJu8bUX9ltIUFC6kWBEYA4BhJNkAMGxpWVrw6H7g1A03wZcouCtRf36AnJQaKFLBkAKaNpBu3Qi/TrB2N57YTbM3yueBPcBjRqCy/nyopfkA6AUQToRfV6KtVwtiIjRDz1H5+KwNFhpvdl9ViIkwuPQVtdQ4RIsNcgucAn2I+hdSgKQOhC3d34ozQ8rwvDAw98CSe1GfdpO33jG0Oa4nwQrtyvWsW73hcOONAA/ASvuDdpKLQTA6ElEpEE+pkrSyYAXuGWWz+x9PwPfzUBx3Zu2pVbgOPHAawAOD7smvPGUTTNl5HzRgOoBtDQWF9UwK2iPUlgk+DxTEvatqVb3vV3l57/8bHBUJ4n9r/7V6OAest14O3v/vt33fTO5fTCj//uJvCnGLrRrqoniRLG5kdmwVO6Sp0TfR+wEkQUkV5GEkmGllSdt0fpg/cpKq/Cw+dr8xH0g48m/dI9qCogbHxg8uSTXxwO5Xlisv92fPDU12pANWHxYiO8nhARi0uZo2VGDwYixDvu/Ryy5fbZbwyH/PUwWiC6rQygqkVFBo/A0bXBQL6We3UFw66tn9/YSmUw1HmTiS9TuK2ZShAI0uKskGOGBkLt8lquKFP0jjU4aszVEGoorynWyIrSW+ae8YDXx6GTX49ORfSdNpeyg1RcyhoKtZki5dFpMFlduTV33fvw0InzmisInJy+BMngngGpDmA9FC2vGU8SWHzbyTh1Au5tke+/Ut5kUQEus3Ec5W+oS5JLKKGgoUzos8TKk7zMfZYIUg0C2wxG3+cNpPUrx/Xc40dTuYazFlADihe7bJyJKgO9YrklSgnmiRYgD6mjgIHK9ZpY6G6AyAgLoByAapuqAdAOq3NVPcmCrhjIBGMC0F5Jb5KY5R+LuILmAhhzcnttRCQ8IrPuQ/FaQCOwkbwGCbrFQ3etDTvndVd7FXc2jzQe1JQLCpGX5WJRUtm2NQ21iFi8IkRCdWEoDHg15G4JkEdSsURYAKwaFuZaMZLuY8ANcLQAEoF0ZVx8zryRCcjW5SU3VsadAuJslGkJCamaRA2wLl+fzftGdCjm/INh57xmWPdf4s5m1OSsmlkoa3phohav5k2CLCM6KDgZoRABiwwAaPH4X7f14aEb51WxtM/hApgFp0eRydHtMge6xvfWxfzZQ+G22TbInLK4Y7pKifkNfDiFiOxSEjCh1JJoATSAosTZXJy6zH5mIpVU8me1yNSPQY0QajK3N+wfeodfy5Q1zSpOySNHVZKrprwGL0DUYnYg1PN+SPSDwWbzkyKAVGylIgzJHZFAysrNT08vYWVlpV1bGzz+3c/l0KFVbPp2NBhgXaQMokAx3Xnvo/VN1WL7+OOz57OKK1fMea1L7egrnJ3L+3uPvO7rVlfqAQHC099kuvv+L67nPO2Nj1q4Gryhgrx90UaCkQjwyVPfWl0/ePC3MLrplhVByyjh9AS0CAAs4wXKtEf2prMInzdCSCfdy38fcE6cxkIj8zrI4VSESnrjQrY4WYFmcJ8WIrkIQAlEK9gsAmkRlJQLg9IswLOi2MVDhw4ND+IsnHoHsLihhqYaYomWxAQ6INQ/z6fjL37s0fYH77stYe038ca3fM5e/9WN8R0ff6xPEyyi0qlop7awvf/m5HkDixsbMYRFnBozle/ZiDf0Q4rDqfL1sXkcbRLbb7E03RJGC/3MpT/7JGajj88vDr3COHTfv4idbdXmbCitOLjM3gpd9sdQvNTS52tcz+ktDz377G+f8T13fvRoIwsrhGoaooRUfo51Od6lKksiqhSb/sEz3/rM+rkfOPDm7CcunscdH38M2tr6pJHLmBs2RgjL/fTDVzksu7ckAantyeMAWYo0JCjCpRZUotjKvHiahbyQQIumsHZ88lC6st7QtY/ybLYfNLKREAmvASbB1sp6CkSIbt5mV/vs5LPtqxu21/va+eHWw6tY2KhqeYWKU0gBUobZGNkzANWUIs3gypGOiIBIBECesoQwaxIBk1hqDSahOD1K4KiFcnJ3mCFSglS1CErGUTr+zX+erplwe4b+TU0OHVqd+NK4dOC4lmnsCd+X0Y/k/AwmSAi3vBDx7MwLLIfo6SdWJ3fe9/m26rzO8kbs9QrpSSQg1pRqCCDUghZve+CR+P3Hp6lpDmAy+cdnbZLZLz3S//vIdW40izdw64f/MGp6etloTRn2JRSxZdRnXoLatUZW+rL7f/def0tqLcuTITRyJJViH0SHoGSwVk4YAmCAy6FiRJN8SIecC+HF08hLo/kjE6oWyqDUOLwFLQpdglsdoPjB+x6ttzxMfmH/Rjp27C4Av3nWPhaw8pvA2itD9MOHV3Hy5AHs3/8jHDuGXWehfO+dzSNRhhoveWRQlBwui3AAwdC5UoCKahcVBdUkwUBAiKBDZAosrAeKhX8tNEDhPUOINAN82oporQKQBTcC8kZSMnTpgx99eO0/PNGlVzunV+nkzgzIUdx+/8N1yFgR+UkyxPlg+svkRZICnEnQhMSEZus+qibBT+P440fT2Q/37nu/UG97rkXVBougkitHE2tZqIHcUtU6WW4th6Ll0FbbuTUbp9OLJzEW4vFvvrna5Q7dv1pntxXKGgHLfUks9XJ19Y5RBMhiGCWfqQGl/mElSS3JCbJPMg2BMy1QlLpCdogh0ZhcjmAOdRZBA0MGHVGw9un6tvUSMg6Y4fDhVZw4OX4w0GuJUUDNOVtAM4FjGNgKngIFokpT5DbAEoDk2k4K4zpkRHkHM0KWWyLAnTXYJdoIdKsdHgVPhEXtqjsEGGSKkiKBnmaHFvBasBpSAgEKCWAtIgKKEGOJFhDLsUYqdYKde5d9/to9p0KmKHPeBbTgzDnqW2OJRLI198lLoxe+8sPH//Da8SR3G8GgLWQswKAWUHM57XapCRE9yyfOD+jWdhNK8SbtJIfLKj/5rU+1WF1t7/zjUTR4nWU1yOQIIDUp/MlcZyGZFI0EgurpokBup+Cj1GXig83n2+xK2TO0bym1f/6716HRJA6t/D66v6qWc8YyzWpAy2TZmD0X9uywrC3GUZCUALWEJcCTu7cMltyRQrASeMuS6KAMWV2RJqGAnFEZoAxYKB6oy2tZBUOOh556amggPQs/fnGxDlWeFUrrWc1UvdEhCZNg9DoLSSgXmQm1AJQzMwKzR4k1gxVSnQeIoWfSjeYFNpgKEQHsOceKIOFQgiORc+5rBLTcc5KhYtjKuBeqsBdA0Mr4D6mM8zAyalbB5swxKv+mWdzxlKwfCth/TwnjZ1uyzWDct/X2dQDt7sv8KhvJHezzn7Yn9d6+CyfjUmki5yjbAECS2FJqhQ7qqvbJ73z2LC3CXfnEo8TTQHp3szq5EVUkKoi5hatmkTSMgagdTAKjOSL70bkEE61rM2yZZmlkBk230p33Pjq5QW9vNzZ+hOPHj14nuUth9FPELI9iVcPVsPf8zs7PlnPJlvCWtOTyVgTKSAYlEslztT7efGuqqh8AeBdeHJ3EO6ZlMmLXLeHkjVvY56drdKjdADMmAlBmdBFA1TIQzMD29s0X/anuuvfh6FQc3bTUfvf/+d3rxEQKHH8uerZYBKgRCSYCkWXkc+znoSeJ0difm55dQDgcpdAjFH5q+XlBNBAeoZml6gt1jpIXpJIcsegmYMa+A4BoQBkzXJKKUSiaChDjvEOuf/9np+JeMzV3xn8TSoQ6O+q263W9LmdWy1hZ+QrOwYi46kZyY+PdwD5rZy725d8bBKhC63FAZHrmO59qX312805+5cTkKJaaT64b9i1XGoGYJinEDp5MjIRKXqWEipFiAhWhEA1IgkcRiUJ0Cif5kxoLo3jXvZ9v337D1uTYMWJvFxeE7xxj+vADj6xvTlWTs0hAZ11TfSWanigmyScBoe2kkmgHQFaTZ7/9e6/wtk+88pe2dzarcWoLYNhK02oRYSOnYFYXDyYnmNLm2zvg2Yv8VKe7hLeEiJ/8+Lry+uVHI4ioUtWOkOr+Gksz+kahavU9aWWO/Zy6JSAZBe/zzfKZOpN6lpbKsxbnxc5d9L6EPrRGKa7EIoLNVP6OEnnQ+vehsyKQyxe9vuL1WEL4FQBr1064vev93VTVtsUoOAQ7l7d7aSjFoJriBOalKnZeKCH4L+w/gv94qmpNvtzREEwwJwoVRbF4QqwhJZbgHiIheUThWELwSKEmLImWOvfmxyfH8UMfe3TyF1//dNrLBw8AvvP4Z9IHP/rwV9wIQiswNju0H8GE1qFEMrmphTM50QYjPFucVi9NfvD1L5z/OthCW41COv5n5XK57b5HYuUdMj3KAqrM9F4AP7zIT9V7+tdVm96HPvZo3Oq8NmNDoQF3jhln7cHkPAhQn/tD73HCVC77PiTuWQg1WUJrL/nDRM7yiZwbOs5fW6nYYesdIp95dKn3JhNLAH9l2pVpkHsikeT+qrzaq24kF7duaU/z+br3wi5/+Nm73RJqKbR+RuHo9Y1Aqcyhre/5g7VR2FxxMKkMtIrlBlULoCefC+6A0aMYEinQcwQMoNcCEi0nOFp3xa2OzaH7HklhIbTjjR+k/fvfjVtuuQtrryg4XOthufAfnmC68/5H1pEZ4YiiooRUCgNIRiSpzz2KabQgSGoXNsfpmckXLui3Pf3NmcdZ1oU+bcGqVxniJX0OgFhZ+SraNvWshd04F+n5yDX5bA4fXkWpSD+Fgx8Zx+3syySXITX9qoGvXcndaVss3mQkkHoDmWYVZi9eY9pJrsyLQGke0Aowm3mmAOWlNZjcnRIDoElp7kCz87XLkX6bvTsvr0eUgqF7K6qVMDm9kddf7axVV/twTSbEhz726GSa1cg5MaK57O5kuf0ilFPgOH7grkfiXz51NJ2/8RHa7zLd/YmH1rY39i+XnLQSLMClaHBI1l9OhKsPXTRvjKpZHk+UmABGM0+k2uwWfTvHbb0PJzcQf/qDZ9Kd931+MjMETbOKyeTaz1uurq7iq//HZlJYSCrFGBiVvHgpvSK8J/QcVOVR+g9f/2S6HJt/qwMWxkjBkSTBgfizn1UX9Xq3Hl7Ft//62SYYcMfHV9vp1lLa3tiIPzx+NJ07LXLtpUo+cO/D8ccvs/nQfd9LjhE6d0BojGgExgsj9ff5THDHcPaNASoXUuKctdBXkolUeuz7MLp0W6USWc2KeQTl/SsxAYpgL6PY6yuUNg7FS9r97GmFUqKQREUSicW4twFoRaYwOldYfk0YyfKGXjr9MhbGN7QBmpQbCvXlMZQCGQBkSGwL+WA73RD2pQvzzkru8MmvHU1188W1oG4ZRO1wBBDeUxQcs/wMIffy/wgolOgS0vQbLAJo+5kvSZ1a0AD32sV+BhDWP/zh1fhSZfXB5uF0Cl17YnL0LK/mWvFiiD/+4y9D4fm6RFmWKM2YBa2kJCgJTBQRjED2yxZS3YSbMLWTpcggwhwpjF84r5+9876H4sL2Ak5xDFWO8SnVWQKM8M7qCltYWFrAbR/5XCIDLGwD2wsYjQO2us2oytP3v3WkvbrPQWecp0paFhE7Z8vAVIVQ55xrADUv+VwJgKIK/3WuvSAQlIqnKauLoWQiPFKsZYSgiZwAvWi4svdUNXtfgLRbKYqXbl8kUGpVfl+a0YXE+UpElzBaePUOumvghJUQ5vaPjmsLviJxGUTDni5wOYykPCeIax7UElx/5pufmVxKweSOOx4D9289CLKmEB2s2bffzQhYohL7/mIvV2TsmQrlMHuZP93n7frukj64YDVh6JK6EEXBRBBdenm0f3LjSy/tqo5fG6E2cASHDgFaWlgWvYFUUhEWkheaD7Ic5qGo05GJiy+u5W4fiFAfWMrtsWNHL/r3r+II/tcGcTFUK8oGYWnt6ck/Ta/dHbKKO5qlGpjWFTxleMxajCFMU/ZZmNcHfAJEj8aAQmMplKTyTL39Od65duI3foRf/JPtOA4hWh5jupWBkze3Z3d3vdG4s3kkgr7sQm2wNlhOnVe14A/uRGmXWABCX4ArXl4SkGYFHhbj2P+9p+z0FWs5WlAJEgyEk6kv7MSi84rkUG1g3PXs4rkvhLNN2O6v2+x9Fq5l0WJoCaZeAiASqgVLpCcIX3l68pm1V1sbXhuHjLi9WY3kQgPkZYJNz5ks+Tz4Jb8+ijezVtqwuq98b3L0IseRFuN6532fj5CWezJrL6WGvpJrbcn6zN53yemUBbckeOrb1SO83GDqQwNSLTNTBpLNJjvmDFnpJiHQTgNbICTLFb43+WfXTOHn0AOrMU8Xl43TGrIEA+RKxXsQaNZKiDlj8uy3P53u+PhjwPZW/a4b/nV7rE/+Xgzu+eU/iFvTzVpCE4g0iotrr03dEW5vPl/DURsJ0UsIOCs2meCZsMDkPo20CqYS+oEGUrHwZQFKqQNaVmjReSRDhLxXLDJAam1jOjl+/HJ7/WXvFoI44rgaY7PzWAGN4DVhUTML74gAl0mrL09+T62EOOMea1awxIwArlnFPFJI2NVJRyFpJzzHTleW+vBdfSRZzg1pQNG9RC+Y/QrDePYplucS8s/SAUQrecte5auoelndRzmTzf3vfei5Y//tq+b+r5FkV3lzd973+RrSsuTLhGqCUWBNM+gSx9CWEFgAsQ5hTVVYf+brn7rkCuath1fjvlOjxoVlgA3gvQQcY+GQlcQ33MumZS/OQAFusaeCpZlATtlqlkpuZ3bDqmdnIFFo+1AnEkAX/Cvf/8bvt+cuLBx5lb/v/tqRs/77ha3xTNXaMUrPfuOhdOvhVSyeGi0HsvYsZKINVro1nv7m7132ivGhQ6vQUlhRP9rBgeTWrb3aKIc7Pr4asR2ioEhHdA+xGhEu9Ycx9AfNi8CGeQxiITyXh5Agxn5mT0mjEC2EBKBGiYBKwarkvtrt8cJaaSa4XAW4vsCEFRy//5fqzqe1wNr66EtiXfZH8eYcimS1TGRcDg1XzsLkM8L8uTMCEW2v1tSWaA4J3tN75lGweseFfXi9w4boHY+dlFvxWncMqwq9blbUmb2fEuqjJZG892RdSL13mwAmo2q5aoCtyJS3wmPPPvnQaz6ba0Rts7y5jX1b7dJG1SLbBMix5CzUFj7XpT3YGUsfUjShVp7WuGSaxwqeO3Y0Hbx/dZ0ZKWCUAKtLyK2EPvQoAn6IhBUpNqDwxOZjAxmNs+JP4XU6HJCBhlT6mz1CiE7UpiLLKTmC24OH7ltdO/7No5NXpg9eL4Q9eo6/95X/lbtw8IkTGI9fwDveUf7LLbfchTUAh3/6FJ7fWqinrmjZa8FAdbjt3i9Mvn/sU+2dzSOpA5Joia62+/kNu8LOs9Mcl3Zot7dvxmjhpf6CAeCW8OLNOHRotcxuO2sNfMtqeoijsWHKbq65QakoFkGQMoJZhDkqouS0PUSBoPs8Z+a02BcfajOhjCZBPx+coATAY9g+XeM1FdP1KuHjq11sxMG7V+N3F6oaPo0AagrRzPpuFMUiGo3U9y836EWmL4eRfiWJe6cXX+WySISn0noKwGfeZ+4XzmZaruUsgDXl2FXrLoyRYujS7NlqxrllKRpxFqUVlkmCmFxINm9PRDIyuZQMSqIl99wSFmVAHo3Wn/3WP3/dy+uaK5vece9jNdQ1lJYLbcZiISlfOhXAgZZCS3oL2drTk7OVfC7yPX/8Mdi2N1nbIEMR6pUgA6xQGiKlWmBPwO1zMUX0tEaZKd2HGyyzwFXSDPOv98ReoA9X1OdrqDbI1jaJCeGpmnYRti8BgPdCD2YjBBO6MI0LXmFzmtNCJjYrYLEDpqNthOoGUFvIQuOhg2eDgXNeqcNhJAyhzyPl2qEYYBCQHEhwJdo0YTQCs6cp3+jhXGVzf+hjn4pd3r/cey9woUWF5J0DoWunW4g3vmURW9PNaN2oJrwU1IgkKHqnaBXqmS/D8iKzmTyzQxRn8paAoYS0iP2OTL31iMUwzKrBPiHYelB7ym5Y++Hjv3Nen+nQ4SM4/ho52oMfeTSGqvQ5F88q15LVNO8VcNhPp9zpWrkiYroChEKJo82UtNDn3Jn6UQBQH373UVOfx+89Qs6MqFLJ/+6qLwBRskQU1kQo3T4R8MLTlCUI0YIS4G3Oo7Yal2f69Nc/NXmt9Nnru3DXEJpmFac4bkQsw1U2IrVMWrwUKbU+ykiEJpC1cq2FhelkR+TiEkLuD/9hXFx4qQkwuEJyVwnbwjQyWxQ8Eh7JUEIfWbkT6bGnUkQQESxKN1TJm5R8TH9YNW/Oj33uM/b3X9uH4K0KeTcWQ+azG7nkM1G8GkkwWQRU05hyZl8fY/kZK7kmOmJRQCphfRGr8CTZJJiiExGuGkWooiUsBXiakpPFxWry5Nc+dcVypXd8/DEobzfMjF5yhYmByJ7T2BjlQOeWAhWDZWQPsJn8nRNuRWVmftLNIvoqbNlxJf1RpMVsJtJcxBnAohbVT4IkdgqOvcDHGsAW8AnywmTzhdPpueeO7jqiq/jf7q/q7JtpPFqEphaDvFbo2k0fYwyADHDfRmdAJUYDm9L1wgh6ZMl5l/EiQhRZxpBcaaXxXn8Vhbkxq4Qn9IIZNjM3s9ZjCXLOUlLJymYt6+6eaFa4tjs0xwjzNpvaiky+vZCELrJS3MS0XewAD4txjFGqpi/jO9+5PCIz15iRLCHGhz42jlOhsey1y2oYllmUxC/x9Q2AJ0gTMax57ta//8Tvt5eeK1rFuxtgvP/9eD/+Cj/druJ0qnp6Q57krRtx40svxelSaCpWUVIhlZeyNxTYJ/pRRAMK7yz6bORuoUT0rWKIxRAy7soCpXJ7F0EA7p4MqXkOZ+btpD53t0sns8zB5nz2D/pUAWtjhZl8mUpolFSKEoUDR9aSEsG2UD4woWH96W98Zv1KEeAPHVrF9IZRU3mGk9EzopnBnTAqkRlCiEbE7J4YEKly+RQyAiP6C6cXoI0C63KgPWK3ZyjU4myoHOI8Twb2VLO+LW+mol7WsiW5blLrYttVnEx/st2ORjdj9JaXIommI+FmqDzHwmN0CKpRZlIkZiUVea8aReSh3oksSoTSe71FCIKcqStd6ePbFrWdonZecu0l7UQyKStJBqsQS0TVk+bkSQEIzpQzUI2AnIEQKuTsoDEBU7gvQNxIb6tubB/vvfJb+1Edz53T8169gNTTq+MamwBUDtVffB3pI594dLKxxSR3mPrKGS81bOhbnohoylE2ju994Ev44eOX+r6P4kTvzD+3E37tdu8TgPUPfezRuLU5qjnagGxcZoCLCbJYCj6WYA44mtKhUrySnmAbz0r/zCZfRKC0AZae2HnLGOaVxz68L/mcXm6qGMWen7ZDteA8p3amKEDhdpZwcid6Y08ULvQmM0Z5jsDKFbt/T70DGJ8EsluUEK3qM79mfZUzRMHrLEYasSPCoDjLHc4+YC+zFYsnjwhYPGtrnjHMjHOa0Gytzqy69jmzWlKTCZgJQUT19nEtezm5PBrYmICADFE1nMg0hPLkagBJVqIKsb9Q2c+MFyLJyN2Fk5km5xX0f3paaXIrRHAW77DtZc0SoBaZMwNevHLrq9mOJIW2CsWHqQxwdXEMppuXHmiPHfu1V/y+7+8ygDvGcfUchUheRqt0jeLg/asYTavoxi8KWLY5NeDir7rCm/QW0LqISe5s7dlvfzpd6da/9z7wJdy4tVVPQ65pPSsvE4VziRqFhJtA1BJqK73thUpkfeV8TrzArAei74TAXGZlJxmuWaXwjLFC8z5c8ixOMnflKXRWmHRmsUHw1mgpuyaE1t+1P69dPO/xAvfIwT+CvfVkY2J0dJGhAryrQYsGT8KsTXLW2VFSH0UnQHGXyuXsE/c0EcReUb2vqs6oKBdaCTZ4+blJT51pgxFyS0KOpW/ai3Eu1djZJRVRjODMi++LfTN5sd3G8erHfxRaUS3FJKKFlBxsSaRQ6D0pj9COu0WIjs5PYVyN4S9vp7N5v3ff/YW48Z596dk/+W1cCy25e0Kn647m4QcBexDwelbBu6SPXCrd6xQmgNa7d9y4Xh7IlUspzNz/Ww+vog/JkRcQzUKTFUquyQC4RdBrqoxmFSwVvnrfamXFU+G8z3YW7qHPB6HX1uM8D1S0+qztLWoUvWj7eSHxctf8HpF9T3QuuSahGOm50rh6SgbXBUzMbK1Qfa6MutFtDzwSmdnQQxSn0YrcVw2intUFduhVSIVpwFpneuXxDB+weNtz9ZtLn4TbX1LqhV/70RS9DxpL2NxXhbwP44mZyGwxkjzzv19uScGLOkck4BmFToO250i2KsXHBLJFBjBm+/Sf/95rdCXpmjZL1/jA3SJeZGZJ7n0b06WGEn1OqZC/k4Rm88UXJrhig73OlGx67tgZnyUBWP/gRx9upsY6OGFk0dosHMniYQCJcjgIOic9j7I+08vjjhcpTxTjTImF5ETIMBqylIwBRQsTaSckVZ+Lw0TKdXm9ouQDFDI15sIGSka0QGj9pdDuhDtvvJEM09OA9kOYglCULNJKxEFDlJciixlj6f4xzDo8QMzaJ3sO6+4e5TmN5LJcjKVjUnUhU5fLqO9bLiG1ZuH8LIzXzl0HFmXvudG+mh7kvJOlLQYecKg1RwtTAiwxs81AohtoXfvMn/9+C3z6Vd4zr3lf7Ro3kmXinboMmKXSYnS5ZJQYSwcF4phnBA5X3ZEfe9dujrfbyt+CDlt1QIg5W0tTtCK5X4OEQW2pnLPdfWzYH3r11c7+P7Ta4WTMw3IrrXVp5qgUZ1O9MAFnnRNpPm4Xc9HUtpxbgQHr2B6vcft0+8wzR9+gdTz3a1bVDZhuO1Axmgsy1D2xOMo5IybHvvgStet1dqrTO0okosA3yJthUYOK/TrHXcauz5fOPqdesUN0WY32udbz7H/Pe6l3XR59SkeYiL1yOACjemUsJne2ISgZDOAUm/u93WOB614zkr03EtT2Yp2p5NQuQ5M+S5hDRxynhV2/7+pjN3Xh4K//0SS/8PM6hGlkXkgypqxpC1iRHCOiDM18DxYuWs2+8NN7K3FXZ0LaGWnd5+TmffLz8LJUJUUQnkBLjn6z0yBnU1Re2Fpge9K6yQ+/vVvR540zkLceXsUNz9+Fu+4Cvvs3P4hd9prw6Ls8QpsXtFTyiru4gny1/lzyLNP0RnhqM0K34iv28OukkC6ffdwZvlaGrs0i5wAwoB+ill7BkJjnTnuhCCCVHK2hKFuVCM1CYfEoKyJYGm049jqqvfAm+57L5ECyy3nsHDWghBvy8sH7V9feWOLzxbxD4Nk/IXBWZ9CtH16N1Yj4y8lnEwDcfv/DLaU1WEbuymhOszFy5qz7p8j1+8x7IUyEg4VSZAYKLVwJVPKA9L1vfGb9wozdG+mFs3zm8VKsTm3XWno6PvmDABYhjehBEbQIoUapTNcAdpG/8apGj7uKVK/3vZflk/AqFyFK4RKu3PbdLKkfnFX3HWBlphB7zYS5UnjPy8S8/7qlIcFZiw5zJYlJzFBnsXTAhLQZ9u15I3mN+78l+X+oeXSlMy2XnByWOVcJuQzJ9DKUaN0Ma2JYLzqO19fc7IMHfwtVfHc0bMFsHDmKyV7ewkb1IswW4L6F702uxemO5TnUv7waR9ujZRkjkAsdSRYJLc+/S5zNDy6Fm0sWRrne0PcASYmGCbPW1auIS2F2IkqaxhDhHq2v7qt3zQk0khJZKvVFpdwioWRScoTk6no9yQrmYfLME59MZ0u5DZ7kZUXx7JTzBGXaWdP3RMfLcQDZC3IaCXfVrq4MM79Gwu7z99x0jjRF/2flOJ5d+1dAX5i69fBqeu7Y/3DO11tZWcMa1oC1Qzi76HLHxx/DdOsFtJPHzuvd3Xp4dReHTRdxLxce3Hsf+BKq6UYDMAblntztsadGFRHXnUJTXynGdWggX2NGCzAnsfPs2FyzMN8hYJ1SC3HitrUuhWRhsWZ2BHn0knKo6Uqg1d6nAKwnrPfdL714LRCImOWJIDIRC50+JEOAApGx3bd1lvfzkY88Gt/61u10pehhbxJPcgcf/NjRRl1YEbwhuFySH34ZPr4DwLqEidEmL/94ce2HP/wdXH/Q6xy0y7cVDj2wGr0b126etra69NwltId98COfq7tgTWWIkkdpNqy+CH303TJFPKS06GH272uBQ3h5jqheyWGd/X8Zz5ugMqK1/564+wf6MRqT0qbK1itf//7Xf3+ewjn0d74Yu81pHSoHskXPqhmstL564eXOeJwqRrElBblgsJRZph5CXkJuYwrG5BlxTGs3Ok/u24ijA+mVIzEGT/KyYbSxb7I13mxYlMtbyOv5hLdLMhwGINdFZzKnG96Zavzw+hoCdW4jyAtYowszoNO8WDu7GJxxcTzCXc3D7TYrBG6iWxinZ7/2+sPPDn7i0biwbXHaTZvQjzt1t0hTBKzuyywRUoSFnt8ZSs/7NUKyvlTDqFJJBoB2d7sjyEgv6jh9veSMSaOCWkMRRhGRjGoJti60eYTJ6KUnz5gRdPzfP5Te94mH2rf+HDBbQDeyNM2qaZas9LWX1k0pUkwMfTcYiIwisFw4k9wR2nUkoUsdq7qyDFaGjRt+tH49nJxrFg888CW8ND3dOLEMlIFG6BVALu1jzEnWEwHrgE3247m1yeQr16E3uXpGGuNcva0HD/7RXB5tFhatrKygbZexsfEjLC2dwJlrs0MaP3RoFVy6oc7Yakp12SFWicjJGKJnhwKS5SoBU2QKhLfVRkkFLC2dANDgVPhRwxxqt77P2j06Qywixqx7lfe+TZIztR5gTxrHs1Im0mxAViqk/+IhFtmzMp9Fs3zrTOEeTL0AbpLQltEEGVBIbp6qKZMCJu/cPz3vUPeee/4Am6PTjbGqIcLpfddXT67XjOe50y4sFwKZXCFlOcyKoTZ0yWVYeks3+c4tdyW8YtDdYCQvW6j4kY88GjdNyzJfIawuA7ZmhvKSf0UqgrycZNP69y9xxMO1jHc3qziAA2dNA1zBwY98JDKorhhA81Rtjlupi9s3MFalUwXZK3R8uR0vAS9t3YgfPv47eOCBL+Gnp1+KYTSqg1BneF1ZiO4z0WG0oQy3j6aQ4F7U2I0R8KSecqRQwVw13GOv0h4li6Ki9WMwjIgCI+RFR3HWrTLPQ17bW3pX989MSLmfV81UxhKjF2GetwMlmiV5P3BLbNFriRKWehmNiYsIAmBVUvZIbrXPPHGuNMf5RwaHDq3Cb1hokBHJDpTVmeo7fmbhfk8PYnknJia5EkIRxyUEdwMsAx5SVW2n5JicOa9pMJKX1VB+8L6HGwkPFkUW1AQvy9Cw/qdbwtcFWztV/e36Dx//Q1x7le4Lfz933/2FuLG0mYjFOuQcvU+yU0qlgclAMXrwmmU+D7K8hUIaGaOXPuIU6GkqRzCDPMSMDkGjROuiI9QuT4YcCVsW0QtplG6h2W6TlMyY0BG00g+dS7iWTD2xGhmZVhMW6T5rI+yl5BylXU812Heu9Oz2MoPGr1FvsnQ7FVaN+mGaRalI/cxqUDAouggY276FFEBoAbU7wsyWMrrkVqWRe/v05DPpjdpnhw6tAkujJhcF8agi4xcNgvehda/UXhSpxMigMgPHPRHWF0gzXEg2Ypo6Jn/5rc/uGRZJhT2GWX+xirJNulxr3EuMRdCigPqG7ubm13/9jyZ/8ifXoIFcWcHBJz6Bzbe/EPcJ0bJFqIogkqscQp968pFi8BC30dWhC2DwKDFamR4XnVxmAPo8Xumq6e+bQGsFj06r5UqEUhZbkrGfeJfKMKeuF+ct4VXp8y5aiwAiqbbnLgI+m9eMBHapzJrMYOlHjwYhG0EPpQAjgUaAaqH5v2Mv8T+vshKYCIjuuSkK8NdkjjFRauf1pL7RB7Bi+A0JmUk9+Z1S8uKltQDaAE9FxTknG0/b7i03p5ueX9wVDZxrdMelpqGA/fuBFzKjAZEqA9AsFNqQSbGMhujVpcrcmzJSGQJCiJCS5BANoS/2jLuFvup9ZE/YnD1lJA8e/C3QWARoi/J3urRh9GcZIJZWRXMgk/FvXty4DCMeLu9hO/TAauRfh7h984vxRozQbSvSSohrQiRYSOEjYiSrRY8SYbQaXpSeizhG0STUzlTAtLsQJqAxIIJVBKdppl0JhAT6GWFI383bd9QVj2nWZSdHXablMpGKBrZyzYzpbGZMeQ1Dr9ijSCdgSAGYHHr/HWtra7+JpvkyNvmzZXfVMsK9v97cJgiI5ooe9EnaqOk7R66lMLufOz3XuOtV5r18zUsnS99PnpxEgOD01o2TKcapC1P81Z+vpnNHFhc6uuP8LuSX8jQGjKME0BhlOWZZpCOCSlb2TCQYvVcbnwlks4wgmc25qSWDy9dZbce6+dx6O7kcWq6DkTzjgdl7ViNPI2ahLiMRLtd87tmRdxgswZiCHORGurD3eGTXDX4pD//cP3vHvZ+rp1PrBWGVhBEsdNHda5TB88mIxkEE71svZTV62S/Sdnh0vSjsrt8Sd9ybWX3YAd9GkR0zzOS5yhCnnR/0My0mKLYqIsCJ3CXp1nP2TECmRUNOYAV2nryaeyrRiWjmEUDrGXj66b+MANJPRiexP3fJYTAoGgzODJhqCNEDG4L1bh3Mq7tnzyzMlCYIzsQsEq0XXiZbI5JcUVIyr1qayjx3VVjcsPTkkw+lq5ExWxjtw3bOyB17D7HXAzBEFvHn6P1gr6K2T1A+812i4E1feCqFNmOiow3w5TKbielatz57ypP0PIa79zJWM41AR5nDki99wwgQPIKI7kjfHf9qOv8bmWfd4DyHwTufzoPy/U3zIH72sy28/e0LSKixUHmjKaKZw/tCRvYuErkmrQFVc2d4EkSrWT7L3OSVQUzCbu9br3rB7LJ6UjGYu983d9IUZ3rjJc84Z6DuqqeUKIyx6CN6AqxMsBwxwnO5omjY1UVde9Dy1Drc3jwKdCeTwKZ4JX1/tiyW8aGoATRXXpV7R+S413o8c1VocO966bNSoBEtEQ444LS+uKFIU6Kq1gNhuYi6dFD75JOfumpdKyc7YQFVNPbjPzj7xGUwXck9zzqd2Ocle5FmEqWgwwQolTk3HgXCEODG1xmQNhjJC83p4NmvMd3x0UfWGcoDkcqhAFST4RLHzgq0AHhuBLasPN39wuPxyfOSUFvFPb+8P+btzZgtpJvCQnoxb8WNfVvpTCk0ntdnPdSsxpdt3IzeqXSKjKNtwTtFWI4mRmkm059Lkh+oZ2MYiqSaYimKzBJgr9Xxwgu8BF7NY9qJK1WESNr5VMEi85Y41/JkbzD6AfbupadYgNC1VKiLGvtM3g0N6aACVLQii1eC+fyfSKsgdZc8evhC9uNsDrTcUUal9dMJUfiJpUKtBKql1Ao2QcjJinJ3IgjzXIpOQJIhOYggx7QTtrYt/fXcQF7pkLTkC8cZcCt0oyxLwQXB2zLqgrV6kRSwl3wDk4gIeNsPfAXm1XAHYS3oiagw2ljYE3zkPeRJlk3yzBOfmdx++F+23Dod1eXaOFqRewPYpU9UnCnJUDUz67yvq++87/Nt6ed+jVzpR1BPfaMGWJuAF7dPtU7D0stL6a7m4fTU5LPt4cOreOHUYr2lTRhGaXdF8kMfezTu52J6/PHfwcG7Hq4FLAcC5kyFLN2BpuhC7UQdwH5KLWGFJ1jPZxBbL412NWacFP+xJTghlFwlJLaiHNMvcdEgJPucIntD2Uf6ZICAovoERMNubcuiLq6i2o6dCjqSe1eKRZdVjPZc8mGC5Gk34RtUa3P9YUb084CKEISvZ6h9x8LL63/2Z3+AlZWv4qmnnsLZatwXd0FdgejNqwhMQVoaWU5ZoZ/nbQlAK3gsylxWVkMOQ4BYTZjRjjumrQVfhnzZxOQQjEjjgPXvfPd390SFew92nPfUhPtWo1fj6F1uKFuGqyHRXPohESCuOzFxcX3EnKaWJ2crBN16a6kmLt2yUHee60CCKpMRC0VMCaxad0ShK16RGM16fy/nBAJmhaJbfjV77T7rb+gqUV2R66f1grJewxULYRiz2TfN1SdSF+XtIm7AdVCtFW+/hFdy9NMX58GoMPcmI+aq6oJks/Ay7s5UlGKQUCgnrHu5t/Jv9kRn9WTzSz4ZnGsoCrkXYVdRFidbSmU4m5BAJaGfLElA9AQx0TCRmBZG08l3//xoapov71SjV1bO/H1rh3DmfJbLUXy59HN2x0cfi2Zby6ClXGbyzAjlUcyQz6Kafi62AcpsAUuc5vZ7/6hrb/vjUUO3GvRIepSFtjq1vXZhF8VgJC8Kd33si3XXbdUgG4ANxYYW6jOHMl3YcpRWMK1LmCBwvZImT33rs2d4kgc/8WgMp9SQDg9VmdHsQDDMZwALBkNOtBGgKSQrQ5wMyApltgyRSgrPYOqiUCVQCciNq4yeDUFwD4Aplnwsm/kI2H5esWDLV6UVjwYo78w4mQn0ytflaEMVoivPZ+NYKZFCfaLfJGQoGsJO4pKlUm5e5nmL3veXGECHFUX0Eq4SyR01e6WaGc8SxmWIzTnTAedvJNLOrCAlSG3f2ZIotDK2FGspQxZaKCfQaqn8XJnt7qkaIZWxxXuxMWHHUDJ0kaba3Wu4wfr8a2aONtemDAgMCVDK5olBKWdLlYjsXhuBII9Tjibf/9an2r2yJtVeNpLiRqqCocto57OGhXouKHrBhnKeHI8G1XKP2Hfmaxx6YDV2m2poFknEoML3A7wXuEViUKJ7dLAO6JKgFCqmnGehRY5gP8tZBqorYzOpfl52fzNnxuwOMYNiJFlTO+3qpT+3n+jHcxkEvkb4+PrFo1fNO85+3r1QVmAJ9NTTWgCE3vh7Kp3UDsKi9x0m7oBkoPUE5CwoMAGF1M6c4aFohxIGF5A9p6oy0Ag5IHWJsgjrJvJxMs/gCMky09TREnqQKHOBLtgsCK2TLaGEXlCWxe1vkbtkI64/9fXPth/+2BdqYBsvLub2uWNHUTdfxOL+DQDA8WOXm5JzNVNcn0wA0j2/vJq2tw2o0PTzbBAQCkEeoZ/WmUFX2dN5hHEAjr//ifZ9Jz6Qqg0l2lvjRvhp2ktrsudFE+9sHl52sLYyz6Qp87mtnikDXKQ3mSBNZgOOKuPaS/azNiy8Ly5uvNQoj0Hmms6dwsj8MFoqhFpB3vevogI1TTMaomjR3WFAohmA3M9tDoBZkrYbF2pKRbygvKfZUPoapZ839ac6gqiLSsuZqYZzVq77Lo5ewHhWGJnZ2EnZ6IhAP2hefVGofMNc9opSi1lPMZToc55lyoZ1BmulDE4zaAEezn4fOdKQgo/rLiuCngKsr4gzhoqt5PBMVMFi13UYB6bpaDR55j3fQtNG/PznC5i+52a8H8Dzz2PeV940D+IUfmEZwrKTDYlX8bTP/tpsWBfbmSyYC6310xUJtBW4/heTT7ez+UuvV9C7Ptpady7Nw4dX8ZPT1YMZiiEzuSwVcjlmY3ohVwpjTawjNAo4/p9stTi6d9dhjxvJr+KOe58poTZRF8OCmlRzKR+tjAHtEsSJkW0pJKA1UytZncvs47pUbC2p9BGDVJIC5gbaBYQAKacRiNybgBkROiCDNGSvAHbJLCRzj1loSES34g0TAGeTDA3RZbEMsALQ9y+XHCZ7qs6sg+gM73hmx6OgltCkH2RbiiIlZi15Q3qSylRGFjehkVgXJWoUzc1iQFI/gbBwS4nknU/uvu2Dk7XzFDG4876H4jQsxIBx5BRR7JLg6aTQnpgcxcGDf4Qb3t7FjQXhe8f+2QVx6t77wD/BjdO3NU49KHFlRsOZrYXKeIodM0C0/ViKZEIrQ+uORCoKoVX29vtPfHZy/h749YZi9G+//+E6eGh8JtUGpdneMlniCO3xx3+vvV7WaM890dsPr8bvHdtp3L/zvs9Hio2jWyawrDK3Ol5aem42ArRXYZZNiAzJelaNAPMWXkGOZMa511a4gEoIAebbCRyhm6rd5+N0cpSRu404WkDa99b92DpVDmjuTiNU+/DMn32yqB1tby93pkh6hLwftWARzKBbKRLQIwqpup9RYwBzPDOcVj/Phuj1Fov0ftEeTKUym9MsPSFZNAWQnpA95hAQ4HCFCOamfEqLlEpejgZW3bpvL7buUywsEn/x9U9fFDn40AOr8eSpRVRjpnby0GX1fm5v/mUkNz4JYZnsR1bIiqpQyaVGFupKkoTAMha1eMmWXJ7AKi0u/nzy5Ne+mDAAd3/ioXhq46a0MJ5GbamRWQyutP3ST9efffZfXVcXxp5SAfrw4dW4tTGqkRnDwqjtoPaUn443TMMyyOX+EFymLpy5V9YSvYchiyRShk+MllTa/ApnDEAwJXclqxZAZqjr4sJiaL/9tU+ne+75HXTxF3H82P+4y+D/y3imd1Ru6pWVr+KJJ05gOn0Bo9HNWFo6HbeWNhvvAkwhEh4dSoFVckOyQHjOEZmRVETJEaLnGiZnRibTQshpuwt1xZyefv9dLdaeemU4uPJVHHrqKZw6BeR334g8fQk3/PxmvPWtL2A63Q8A+Hk8iRueB5aWzlYSuvzh3aV7H2VN72oerkWuOFQI515G85Y8sMV5XxDRCrn1HJKC2sUx0tZPb2zf+tancH3K5106bnvgS3FBm/jg+25LJYK4vtSz9pypv+Ojq9GqqnaxVhaCIWYqEtZQaPr8HC5PpXf3AFKkMrERrcPXAiz1pOkkFzRSu4CQLtaTugCPq97sAKJK7xyP05/92SfLzX7/F2O3vR3Jqg+hA8JC94a/nx1DdOQa3VLq1+dIzLlazmUEbwQFF5OZw71qjTlJiAakHCwtLXXpO8eODl7jmza1sMdzknf+8h/UnG7WnQQTS+GCaCheZiO5e5m0szcMDxFaB6oy20PTdp+/sy1e1Ztn8+wlNM0qTmEUbTSF5y0AN6KbCtWIeL1mgQFvbuxBCpCwcfpIWqiqVHEUnUqSEucKpm+cNwIAFkZwn0YFQZkweCJyP7tj9QoYyLOFNM71dbzK97x5MSkir+lV13SlLzTNSd3Dug3Ys55k8dTuvvsLcbqUa4rRlWvKakE1jMsGi29UDy+tgvv0K0Z8ZSoDK7Xff/wzgyeyZ/bOdRNQDbhCsL1q15988lPJlqYTVwbcACpRliC0hUhub8whEwAwZjGatlMxkBp20p7ZO+f6M2DAdWUkdwzW8WOfQ6VQBrUJUBn821Nb3mCHRMDidP/gQQ4YMBjJaxmOrXfsXyfREoI8tyAmgE3eWBWcUvXuFk9GHF4ddtGAAdcx9nDvdnEVn/0T4ODB31rHzTdPRtMKojcio8rgovoVxq2PjMmLE8AAAQPhIafOLL4zvYSfDCHbgAGDkbyWURj+pXJ5971faLfVJUITB1tKs7GjkQyw0PMIPeNiZf5FT8iAj6v2J9/9Egbaz4ABg5HcAyhhr003k42r1mVl1oappaueKSSr62btuzWB+oL1J0s+MhJV+v7XPp0GAzlgwGAk9whKG9R3voN06PDqV7gxWoZCkdYnI5RBVIno0jYtmlTDtEKoIS2e71wUknAwvQVvb3eH/QMGDLg+cR2f8B1y9eHDR3DsGLCychxPPPEubL79/Vi8qUL1/MsrgB4skwYt7hr3+coQmv3/SJDyQ89Mfv+xYfsMGDAYyesahw6tIi8urNB8RVINsgyYkkXAcYZgq9RPV2AS+I+fmXx6bQi1Bwy4/mFv3o++iuPHj2I00jq8F5OVWgkTQC3K5Lu2/NEExDqE8nVenfGeAwYMuPIIb96PfgyA8NO/+debbzsQlggtGQ0kNmU4AQAkN0GcELkEcIngEsg2yCfPn/i3x4ftM2DA9Y/qzf3x+1EEeGQdABysqcKlZFEkj/1osEgBYplr7azaYesMGPBmshIDcOjQKjDeX3O0VUuGqTxWYHSgVL5JmDnkARtL9pW//tqnBvrPgAGDJ/lmgXD8OAGgPXRotc1LoQYswlGbAepHJcBDDXo73dhOwx0zYMBgJN+UDnU/ML194IEv4YReSkvTUeOqEukQHUa2B3SiJC0HDBgwhNtvdtz24Ucix7mhW7lTLKf8trdMnv2T3x4WZ8CANwFsWILXDsO//53PpMoXJoSD6KKE+NbnXxiWZsCAwUgOmI1CCFSUhTJQVcL+/cPKDBgwhNsD5jh4/yosI1ZYArCB45MjaVi6AQMGDBgwYMCAAQMGDBgwYMCAAQMGDBgwYMCAAQMGDBgwYMCAAdcG/n9aNmZerr1ylQAAAABJRU5ErkJggg==';
function generateReportCard(roll){
  const s = getStudent(roll);
  if(!s){ alert('Student not found.'); return; }
  const results = s.results || [];
  const resultRows = results.map(r => {
    const p = resultPct(r);
    return `<tr class="${isPass(p)?'':'rc-fail'}"><td>${r.exam}</td><td>${r.subject}</td><td style="text-align:center;">${r.obtained}/${r.total}</td><td style="text-align:center;">${p}%</td><td style="text-align:center;">${resultGrade(p)}</td></tr>`;
  }).join('');
  const totObt = results.reduce((sum,r)=>sum+(Number(r.obtained)||0),0);
  const totMax = results.reduce((sum,r)=>sum+(Number(r.total)||0),0);
  const totPct = totMax ? Math.round((totObt/totMax)*100) : null;
  const totalRow = results.length ? `<tfoot><tr class="rc-total"><td colspan="2">Grand Total</td><td style="text-align:center;">${totObt}/${totMax}</td><td style="text-align:center;">${totPct}%</td><td style="text-align:center;">${resultGrade(totPct)}</td></tr></tfoot>` : '';
  const verdict = results.length ? `<div class="rc-verdict ${isPass(totPct)?'pass':'fail'}">Result: ${isPass(totPct)?'PASS':'FAIL'}</div>` : '';

  const body = `
    <div class="rc-header">
      <h1>Inspired Model School &amp; Girl College Larkana</h1>
      <h2>Student Report Card</h2>
    </div>
    <div class="rc-info">
      <div><span>Name:</span> ${s.name}</div>
      <div><span>Roll No:</span> ${s.roll}</div>
      <div><span>Class:</span> ${s.class}</div>
      <div><span>Father's Name:</span> ${s.father||'—'}</div>
      <div><span>Generated:</span> ${new Date().toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'})}</div>
    </div>

    <div class="rc-section">
      <h3>Academic Results</h3>
      <table>
        <thead><tr><th>Exam</th><th>Subject</th><th>Marks</th><th>%</th><th>Grade</th></tr></thead>
        <tbody>${resultRows || '<tr><td colspan="5">No results published yet.</td></tr>'}</tbody>
        ${totalRow}
      </table>
      ${verdict}
      <div class="rc-note">Passing marks: ${PASS_MARK}%. Below ${PASS_MARK}% is Fail.</div>
    </div>

    <div class="rc-signatures">
      <div class="rc-sign-box">
        <div class="rc-sign-ink"></div>
        <div class="rc-sign-line">Class Teacher's Signature</div>
      </div>
      <div class="rc-sign-box">
        <div class="rc-sign-ink"><img src="${DIRECTOR_SIGNATURE}" alt=""></div>
        <div class="rc-sign-line">Director's Signature</div>
      </div>
    </div>
  `;
  openReportCardWindow(`Report Card — ${s.name}`, body);
}
function resultGrade(pct){
  if(pct>=90) return 'A+';
  if(pct>=80) return 'A';
  if(pct>=70) return 'B';
  if(pct>=60) return 'C';
  if(pct>=50) return 'D';
  if(pct>=30) return 'E';
  return 'F';
}
const PASS_MARK = 30;
function isPass(pct){ return Number(pct) >= PASS_MARK; }
function openReportCardWindow(title, bodyHtml){
  const w = window.open('', '_blank');
  w.document.write(`
    <html>
    <head>
      <title>${title}</title>
      <style>
        body{ font-family: Georgia, 'Times New Roman', serif; padding:30px; color:#2A211C; max-width:750px; margin:0 auto; }
        .rc-header{ text-align:center; border-bottom:3px solid #C79A3E; padding-bottom:14px; margin-bottom:20px; }
        .rc-header h1{ color:#82182B; margin:0 0 4px; font-size:26px; }
        .rc-sub{ font-size:12.5px; color:#5b4f45; margin-bottom:8px; }
        .rc-header h2{ font-size:16px; margin:10px 0 0; color:#2A211C; text-transform:uppercase; letter-spacing:1px; }
        .rc-info{ display:grid; grid-template-columns:1fr 1fr; gap:6px 24px; margin-bottom:20px; font-size:14px; }
        .rc-info span{ font-weight:bold; color:#5b4f45; }
        .rc-section{ margin-bottom:22px; }
        .rc-section h3{ color:#82182B; border-bottom:1px solid #d9c9a3; padding-bottom:4px; font-size:15px; }
        table{ width:100%; border-collapse:collapse; font-size:13px; margin-top:8px; }
        th, td{ border:1px solid #999; padding:6px 8px; text-align:left; }
        th{ background:#F6EFE1; }
        .rc-att-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin-top:10px; }
        .rc-att-box{ text-align:center; padding:12px 6px; border:1px solid #d9c9a3; border-radius:14px; background:#F6EFE1; }
        .rc-att-box.ok{ background:#e3f0e4; }
        .rc-att-box.due{ background:#f6dede; }
        .rc-att-num{ font-size:22px; font-weight:bold; color:#2A211C; }
        .rc-att-label{ font-size:11px; text-transform:uppercase; color:#5b4f45; margin-top:2px; }
        .rc-avg{ margin-top:8px; font-size:14px; text-align:right; }
        img{ -webkit-print-color-adjust:exact; print-color-adjust:exact; }
        .rc-summary-table td:first-child{ font-weight:bold; width:60%; }
        .rc-signatures{ display:flex; justify-content:space-between; margin-top:50px; }
        .rc-sign-box{ width:45%; }
        .rc-sign-ink{ height:58px; display:flex; align-items:flex-end; justify-content:center; }
        .rc-sign-ink img{ max-height:64px; max-width:88%; margin-bottom:-7px; }
        .rc-sign-line{ border-top:1px solid #333; text-align:center; padding-top:6px; font-size:12.5px; color:#5b4f45; }
        tfoot .rc-total td{ background:#F6EFE1; font-weight:bold; border-top:2px solid #82182B; }
        tr.rc-fail td{ color:#A32020; }
        .rc-verdict{ margin-top:10px; font-size:15px; font-weight:bold; text-align:right; letter-spacing:.5px; }
        .rc-verdict.pass{ color:#1F6B3B; }
        .rc-verdict.fail{ color:#A32020; }
        .rc-note{ margin-top:4px; font-size:11.5px; color:#7a6a5d; text-align:right; font-style:italic; }
        @media print{ button{ display:none; } }
      </style>
    </head>
    <body>
      ${bodyHtml}
      <script>window.onload = function(){ window.print(); }<\/script>
    </body>
    </html>
  `);
  w.document.close();
}
function openPrintWindow(title, bodyHtml){
  const w = window.open('', '_blank');
  w.document.write(`
    <html>
    <head>
      <title>${title}</title>
      <style>
        body{ font-family: Georgia, 'Times New Roman', serif; padding:24px; color:#1a1a1a; }
        h1{ font-size:20px; margin-bottom:2px; }
        h2{ font-size:14px; font-weight:normal; margin-top:0; color:#444; }
        table{ width:100%; border-collapse:collapse; margin-top:16px; font-size:13px; }
        th, td{ border:1px solid #999; padding:6px 8px; text-align:left; }
        th{ background:#eee; }
        .meta{ margin-bottom:6px; font-size:13px; color:#333; }
        .sign-col{ width:120px; }
        @media print{ button{ display:none; } }
      </style>
    </head>
    <body>
      ${bodyHtml}
      <script>window.onload = function(){ window.print(); }<\/script>
    </body>
    </html>
  `);
  w.document.close();
}
function printStudentList(){
  const list = studentsFilteredList();
  const rows = list.map(s => `
    <tr><td>${s.roll}</td><td>${s.name}</td><td>${s.class}</td><td>${s.phone}</td><td><span style=\"color:var(--ink-soft);\">\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022</span></td></tr>
  `).join('');
  const body = `
    <h1>Inspired Model School &amp; Girl College Larkana</h1>
    <h2>Student List — Login Credentials</h2>
    <div class="meta">Printed: ${new Date().toLocaleString()} &nbsp;|&nbsp; Total students: ${list.length}</div>
    <table>
      <thead><tr><th>Roll No.</th><th>Name</th><th>Class</th><th>Phone</th><th>Password</th></tr></thead>
      <tbody>${rows || '<tr><td colspan="5">No students found.</td></tr>'}</tbody>
    </table>
  `;
  openPrintWindow('Student List', body);
}
function printAttendance(){
  let list = DB.students.filter(s=>matchStudent(s, searchQuery.attendance));
  if(attendanceClassFilter !== 'All Classes') list = list.filter(s=>s.class===attendanceClassFilter);
  const rows = list.map((s,i) => {
    const todays = (s.attendance||[]).find(a=>a.date===attendanceDate);
    const status = todays ? todays.status : '';
    return `<tr><td>${i+1}</td><td>${s.roll}</td><td>${s.name}</td><td>${status}</td><td class="sign-col"></td></tr>`;
  }).join('');
  const body = `
    <h1>Inspired Model School &amp; Girl College Larkana</h1>
    <h2>Daily Attendance Sheet</h2>
    <div class="meta">Class: <b>${attendanceClassFilter}</b> &nbsp;|&nbsp; Date: <b>${attendanceDate}</b> &nbsp;|&nbsp; Total students: ${list.length}</div>
    <table>
      <thead><tr><th>#</th><th>Roll No.</th><th>Name</th><th>Status</th><th>Signature</th></tr></thead>
      <tbody>${rows || '<tr><td colspan="5">No students found for this class.</td></tr>'}</tbody>
    </table>
  `;
  openPrintWindow('Attendance Sheet', body);
}
function attendanceClassOptions(){
  const classes = Array.from(new Set(DB.students.map(s=>s.class))).sort();
  return ['All Classes', ...classes];
}
function setAttendanceClass(cls){
  attendanceClassFilter = cls;
  refreshAttendanceTable();
  ensureDefaultPresent();
}
function setAttendanceDate(date){
  attendanceDate = date;
  refreshAttendanceTable();
  ensureDefaultPresent();
}
async function ensureDefaultPresent(){
  let list = DB.students.filter(s=>matchStudent(s, searchQuery.attendance));
  if(attendanceClassFilter !== 'All Classes') list = list.filter(s=>s.class===attendanceClassFilter);
  const needsDefault = list.filter(s => !(s.attendance||[]).find(a=>a.date===attendanceDate));
  if(!needsDefault.length) return;
  try{
    await Promise.all(needsDefault.map(s => {
      const updated = [...(s.attendance||[]), { date:attendanceDate, status:'Present' }];
      return sb.from('students').update({ attendance: updated }).eq('roll', s.roll);
    }));
  } catch(err){ console.error('Auto-present marking failed for some students:', err); }
}
function quickMarkAttendance(roll, status){
  const s = getStudent(roll);
  const current = s.attendance || [];
  const idx = current.findIndex(a=>a.date===attendanceDate);
  let updated;
  if(idx>-1){
    updated = [...current];
    updated[idx] = { date:attendanceDate, status };
  } else {
    updated = [...current, { date:attendanceDate, status }];
  }
  sb.from('students').update({ attendance: updated }).eq('roll', roll).then(({error})=>{
    if(error){ console.error(error); alert('Could not save: ' + error.message); }
  });
}
let resultsClassFilter = 'All Classes';
function setResultsClass(cls){
  resultsClassFilter = cls;
  refreshResultsTable();
}
function resultsTableRows(){
  let list = DB.students.filter(s=>matchStudent(s, searchQuery.results));
  if(resultsClassFilter !== 'All Classes') list = list.filter(s=>s.class===resultsClassFilter);
  list = sortByField(list, sortState.results, {
    name: s=>s.name.toLowerCase(), roll: s=>rollKey(s.roll),
    default: s=>rollKey(s.roll)
  });
  const rows = list.map(s => `
    <tr class="ledger-row">
      <td data-label="Roll No." class="mono">${s.roll}</td><td data-label="Name">${s.name}</td>
      <td data-label="Records">${s.results.length} results</td>
      <td data-label="Action">
        <button class="btn small" onclick="openResultModal('${s.roll}')">+ Add Result</button>
        <button class="btn small" onclick="viewResultHistory('${s.roll}')">Result History</button>
      </td>
    </tr>`).join('');
  return rows || `<tr><td colspan="4" class="empty-state">No matching students.</td></tr>`;
}
function refreshResultsTable(){ document.getElementById('resultsTbody').innerHTML = resultsTableRows(); }
function expensesTableRows(){
  let list = [...DB.expenses].filter(e=>matchExpense(e, searchQuery.expenses) && expenseInPeriod(e));
  list = sortByField(list, sortState.expenses, {
    date: e=>e.date||'', amount: e=>Number(e.amount||0),
    default: e=>e.date||''
  });
  const rows = list.map(e => `
    <tr class="ledger-row">
      <td data-label="Date">${e.date||''}</td><td data-label="Category">${e.category||''}</td><td data-label="Description">${e.description||''}</td>
      <td data-label="Amount">${fmtMoney(e.amount)}</td>
      <td data-label="Action"><button class="btn small danger" onclick="deleteExpense(${e.id})">Delete</button></td>
    </tr>`).join('');
  return rows || `<tr><td colspan="5" class="empty-state">No matching expenses.</td></tr>`;
}
function refreshExpensesTable(){ document.getElementById('expensesTbody').innerHTML = expensesTableRows(); }

/* ================= TEMPORARY: Quick-Fill Father's Name (auto-expires after 4 days) ================= */
const FATHER_QUICKFILL_EXPIRES = new Date('2026-07-16T23:59:59');
function fatherQuickFillActive(){ return new Date() < FATHER_QUICKFILL_EXPIRES; }
async function saveFatherQuickFill(roll){
  const input = document.getElementById(`fqf_${roll}`);
  const value = input.value.trim();
  if(!value){ alert("Please enter a father's name before saving."); return; }
  try{
    const { error } = await sb.from('students').update({ father: value }).eq('roll', roll);
    if(error) throw error;
  } catch(err){ console.error(err); alert("Could not save: " + err.message); }
}
function renderFatherQuickFill(){
  if(!fatherQuickFillActive()) return '';
  const missing = DB.students.filter(s => !s.father || !s.father.trim());
  if(!missing.length) return '';
  const daysLeft = Math.ceil((FATHER_QUICKFILL_EXPIRES - new Date()) / (1000*60*60*24));
  const rows = missing.map(s => `
    <tr class="ledger-row">
      <td class="mono">${s.roll}</td><td>${s.name}</td><td>${s.class}</td>
      <td><input id="fqf_${s.roll}" placeholder="Enter father's name" style="width:100%;padding:6px 8px;border:1px solid var(--line);border-radius:10px;"></td>
      <td><button class="btn small gold" onclick="saveFatherQuickFill('${s.roll}')">Save</button></td>
    </tr>`).join('');
  return `
  <div class="card">
    <h3>⏱ Quick-Fill Father's Name <span style="font-size:12.5px; font-weight:normal; color:var(--ink-soft);">(temporary — available for ${daysLeft} more day${daysLeft!==1?'s':''})</span></h3>
    <div style="font-size:13px; color:var(--ink-soft); margin-bottom:10px;">Showing ${missing.length} student${missing.length!==1?'s':''} with no father's name on file. This tool will disappear automatically after ${FATHER_QUICKFILL_EXPIRES.toLocaleDateString('en-US',{month:'long', day:'numeric'})}.</div>
    <table><thead><tr><th>Roll No.</th><th>Name</th><th>Class</th><th>Father's Name</th><th></th></tr></thead>
    <tbody>${rows}</tbody></table>
  </div>`;
}

function renderAdminStudents(){
  return `
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
      <h3 style="margin:0;">All Students (${DB.students.length})</h3>
      <div class="kebab-wrap">
        <button class="kebab-btn" onclick="toggleKebabMenu('studentsKebab')">⋮</button>
        <div class="kebab-menu" id="studentsKebab">
          <div class="kebab-label">Sort By</div>
          <button class="${sortState.students==='name'?'active':''}" onclick="setSortBy('students','name')">Name (A–Z)</button>
          <button class="${sortState.students==='name-desc'?'active':''}" onclick="setSortBy('students','name-desc')">Name (Z–A)</button>
          <button class="${sortState.students==='roll'?'active':''}" onclick="setSortBy('students','roll')">Roll No. (A–Z)</button>
          <button class="${sortState.students==='class'?'active':''}" onclick="setSortBy('students','class')">Class (A–Z)</button>
          <div class="kebab-divider"></div>
          <button onclick="printStudentList()">🖨 Print List</button>
        </div>
      </div>
    </div>
    <div class="actions-row" style="margin-top:12px;">
      <button class="btn gold" onclick="openAddStudent()">+ Add Student</button>
    </div>
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Class</label>
    <select onchange="setStudentsClass(this.value)" style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:14px;">${attendanceClassOptions().map(c=>`<option value="${c}" ${c===studentsClassFilter?'selected':''}>${c}</option>`).join('')}</select>
    <div class="search-bar"><input type="text" placeholder="Search by name, roll no. or class..." value="${searchQuery.students}" oninput="updateSearch('students', this.value)"></div>
    <table><thead><tr><th>Roll No.</th><th>Name</th><th>Class</th><th>Phone</th><th>Actions</th></tr></thead>
    <tbody id="studentsTbody">${studentsTableRows()}</tbody></table>
  </div>
  ${renderFatherQuickFill()}
  <div class="card">
    <h3>Import Students from Excel</h3>
    <label>Class for this import</label>
    <select id="importClass">
      <option value="Play Group">Play Group</option>
      <option value="Nursery">Nursery</option>
      <option value="Prep">Prep</option>
      <option value="Class 1">Class 1</option>
      <option value="Class 2">Class 2</option>
      <option value="Class 3">Class 3</option>
      <option value="Class 4">Class 4</option>
      <option value="Class 5">Class 5</option>
      <option value="Class 6">Class 6</option>
      <option value="Class 7">Class 7</option>
      <option value="Class 8">Class 8</option>
      <option value="Class 9">Class 9</option>
      <option value="Class 10">Class 10</option>
    </select>
    <label>Fee Month / Installment for this import</label>
    <input id="importMonth" type="text" placeholder="e.g. June 2026" value="${new Date().toLocaleString('en-US',{month:'long'})} ${new Date().getFullYear()}">
    <input type="file" id="csvFileInput" accept=".xlsx,.xls" onchange="handleCsvUpload(event)">
  </div>
  <div class="card">
    <h3>Database Setup (one-time)</h3>
    <div class="actions-row"><button class="btn" onclick="migrateSeedData()">Upload Starter Data to the server</button></div>
  </div>`;
}

function renderPendingInstallmentReceipts(){
  const pending = [];
  DB.students.forEach(s => {
    (s.fees||[]).forEach(f => {
      if(f.pendingReceiptUrl) pending.push({ student:s, fee:f });
    });
  });
  if(!pending.length) return '';
  const rows = pending.map(({student, fee}) => `
    <div class="card" style="margin-bottom:10px; background:#fff3cd; border:1px solid #ffc107; color:#856404;">
      <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:10px; align-items:center;">
        <div>
          <b>${student.name}</b> (${student.roll}) — ${fee.month}<br>
          <span style="font-size:12.5px; color:#856404;">Rs. ${(fee.amount||0).toLocaleString()} · Class: ${student.class}</span>
        </div>
        <div class="actions-row">
          <button class="btn small" onclick="openAssignmentFileViewer('${fee.pendingReceiptUrl}', 'Receipt — ${student.name}')">📄 View Receipt</button>
          <button class="btn small gold" onclick="confirmInstallmentReceipt('${student.roll}', '${fee.month}')">✓ Confirm Payment</button>
          <button class="btn small danger" onclick="rejectInstallmentReceipt('${student.roll}', '${fee.month}')">✗ Reject</button>
        </div>
      </div>
    </div>`).join('');
  return `<div class="card"><h3>⏳ Pending Installment Receipts (${pending.length})</h3></div>${rows}`;
}
async function confirmInstallmentReceipt(roll, month){
  if(!confirm(`Confirm this payment as received? This marks "${month}" as Paid for ${roll}.`)) return;
  const s = getStudent(roll);
  const today = new Date().toISOString().slice(0,10);
  const updatedFees = s.fees.map(f => f.month===month ? { ...f, status:'Paid', date:today, pendingReceiptUrl:null } : f);
  const { error } = await sb.from('students').update({ fees: updatedFees }).eq('roll', roll);
  if(error){ console.error(error); alert('Could not confirm payment: ' + error.message); return; }
  await refreshStudentsFromServer();
  renderPage();
}
async function rejectInstallmentReceipt(roll, month){
  if(!confirm(`Reject this receipt? The student will need to upload a new one.`)) return;
  const s = getStudent(roll);
  const updatedFees = s.fees.map(f => f.month===month ? { ...f, pendingReceiptUrl:null } : f);
  const { error } = await sb.from('students').update({ fees: updatedFees }).eq('roll', roll);
  if(error){ console.error(error); alert('Could not reject receipt: ' + error.message); return; }
  await refreshStudentsFromServer();
  renderPage();
}
function renderAdminFees(){
  const classOpts = feeClassOptions().map(c=>`<option value="${c}" ${c===feeClassFilter?'selected':''}>${c}</option>`).join('');
  const months = feeMonthColumns();
  const monthHeaders = months.map(m=>`<th title="Click to delete this month for everyone" style="cursor:pointer;" onclick="deleteMonth('${m}')">${feeMonthLabel(m)} 🗑</th>`).join('');
  return `
  ${renderPendingInstallmentReceipts()}
  <div id="feeSummaryWrap">${feeSummaryHtml()}</div>
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
      <h3 style="margin:0;">Fee Ledger</h3>
      <div class="kebab-wrap">
        <button class="kebab-btn" onclick="toggleKebabMenu('feesKebab')">⋮</button>
        <div class="kebab-menu" id="feesKebab">
          <div class="kebab-label">Sort By</div>
          <button class="${sortState.fees==='name'?'active':''}" onclick="setSortBy('fees','name')">Name (A–Z)</button>
          <button class="${sortState.fees==='roll'?'active':''}" onclick="setSortBy('fees','roll')">Roll No. (A–Z)</button>
          <button class="${sortState.fees==='balance-desc'?'active':''}" onclick="setSortBy('fees','balance-desc')">Balance (High–Low)</button>
          <button class="${sortState.fees==='balance'?'active':''}" onclick="setSortBy('fees','balance')">Balance (Low–High)</button>
          <div class="kebab-divider"></div>
          <button onclick="printClassFeeRecord()">🖨 Print Fee Ledger</button>
        </div>
      </div>
    </div>
    <div class="row2" style="align-items:flex-end; margin-top:12px;">
      <div>
        <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Class</label>
        <select onchange="setFeeClass(this.value)" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;">${classOpts}</select>
      </div>
      <div class="search-bar" style="margin-bottom:0;"><input type="text" placeholder="Name, roll, father..." value="${searchQuery.fees}" oninput="updateSearch('fees', this.value)"></div>
    </div>
    <div class="actions-row">
      <button class="btn gold" onclick="addNewMonth()">+ Add Month</button>
      <button class="btn gold" onclick="generatePendingFees()">✏ Generate Pending Fees</button>
    </div>
    <table><thead><tr><th>Roll</th><th>Student</th><th>Class</th><th>Fee/mo</th>${monthHeaders}<th>Balance</th></tr></thead>
    <tbody id="feesTbody">${feesTableRows()}</tbody></table>
  </div>
  <div class="card">
    <h3>Import a Month's Fees from Excel</h3>
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Month / Installment to save this as</label>
    <input id="feeImportMonth" placeholder="e.g. August 2026" style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:14px;">
    <input type="file" id="feeImportFileInput" accept=".xlsx,.xls" onchange="handleFeeImportUpload(event)">
  </div>`;
}

/* ================= ANNOUNCEMENTS =================
   Director + permitted staff/teachers post announcements to all students or one class.
   Students see them in a read-only notice board. Real-time via the server.
   Push notification hook is included but dormant until the Edge Function is set up. */
let announcementsCache = [];
let chAnnouncements = null;

function announceClassList(){
  // unique class names from loaded students, for the target dropdown
  const set = new Set();
  (DB.students||[]).forEach(s => { if(s.class) set.add(s.class); });
  return Array.from(set).sort();
}

/* ----- Announcement popup on app open (students only) ----- */
function maybeShowAnnouncementPopup(){
  if(!SESSION || SESSION.role!=='student') return;
  if(!announcementsCache || !announcementsCache.length) return;
  // latest announcement visible to this student
  const relevant = announcementsCache.filter(announceVisibleToStudent);
  if(!relevant.length) return;
  const latest = relevant[0]; // cache is ordered newest-first
  const seenKey = 'ia_ann_seen_' + ((DB.myStudent&&DB.myStudent.roll)||'x');
  const lastSeen = localStorage.getItem(seenKey);
  if(lastSeen === String(latest.id)) return; // already saw this one
  // show it
  document.getElementById('annPopupTitle').textContent = latest.title || 'Announcement';
  document.getElementById('annPopupBody').textContent = latest.body || '';
  const d = new Date(latest.created_at);
  const meta = (latest.posted_by ? latest.posted_by + ' · ' : '') +
    d.toLocaleDateString('en-US',{weekday:'short', month:'short', day:'numeric', year:'numeric'});
  document.getElementById('annPopupMeta').textContent = meta;
  document.getElementById('annPopupOverlay').classList.add('show');
  // remember it so it won't pop again until a newer one arrives
  localStorage.setItem(seenKey, String(latest.id));
}
function dismissAnnPopup(){
  const el = document.getElementById('annPopupOverlay');
  if(el) el.classList.remove('show');
}

async function loadAnnouncements(){
  if(!DATA_READY || !sb) return;
  const { data, error } = await sb.from('announcements').select('*').order('created_at', {ascending:false});
  if(error){ console.error('announcements load error', error); return; }
  announcementsCache = data || [];
  if(typeof refreshBell === 'function') refreshBell();
  // refresh whichever view is open
  if(currentTab==='announce'){
    const c = document.querySelector('.main .content') || document.getElementById('pageContent');
    if(SESSION && SESSION.role==='student') { const el=document.getElementById('annBoard'); if(el) el.innerHTML = studentAnnouncementsListHtml(); }
    else { const el=document.getElementById('annManageList'); if(el) el.innerHTML = adminAnnouncementsListHtml(); }
  }
  // On first load this session for a student, show the latest as a popup
  if(!window.__annPopupChecked && SESSION && SESSION.role==='student'){
    window.__annPopupChecked = true;
    maybeShowAnnouncementPopup();
  }
}

function startAnnouncementsListener(){
  if(!DATA_READY || !sb || chAnnouncements) return;
  chAnnouncements = sb.channel('announcements-all')
    .on('postgres_changes', {event:'*', schema:'public', table:'announcements'}, loadAnnouncements)
    .subscribe();
}

function announceVisibleToStudent(a){
  const target = (a.target_class || 'ALL');
  if(target === 'ALL') return true;
  const myClass = (DB.myStudent && DB.myStudent.class) || '';
  return myClass === target;
}

/* ---------- STUDENT VIEW (read-only board) ---------- */
function renderStudentAnnouncements(){
  loadAnnouncements();
  startAnnouncementsListener();
  return `
  <div class="card">
    <h3 style="margin:0 0 4px;">📢 Announcements</h3>
    <p style="color:var(--ink-soft); font-size:13.5px; margin:0 0 14px;">Notices from Inspired Model School &amp; GC.</p>
    <div id="annBoard">${studentAnnouncementsListHtml()}</div>
  </div>`;
}
function studentAnnouncementsListHtml(){
  const list = announcementsCache.filter(announceVisibleToStudent);
  if(!list.length) return `<div style="text-align:center; color:var(--ink-soft); padding:30px; font-size:14px;">No announcements yet.</div>`;
  return list.map(a => {
    const d = new Date(a.created_at);
    const dateStr = d.toLocaleDateString('en-US',{weekday:'short', month:'short', day:'numeric', year:'numeric'}) + ' · ' + d.toLocaleTimeString('en-US',{hour:'numeric', minute:'2-digit'});
    const tag = (a.target_class && a.target_class!=='ALL') ? `<span style="font-size:11px; background:#e9f0f7; color:#2c6fbf; padding:2px 8px; border-radius:20px; margin-left:8px;">${a.target_class}</span>` : '';
    return `<div style="border:1px solid var(--line); border-left:4px solid var(--maroon); border-radius:10px; padding:14px 16px; margin-bottom:12px; background:var(--white);">
      <div style="font-weight:700; font-size:15.5px; color:var(--maroon);">${escapeHtmlAnn(a.title)}${tag}</div>
      <div style="font-size:14px; color:var(--ink); margin:6px 0; white-space:pre-wrap;">${escapeHtmlAnn(a.body)}</div>
      <div style="font-size:12px; color:var(--ink-soft);">${a.posted_by ? escapeHtmlAnn(a.posted_by)+' · ' : ''}${dateStr}</div>
    </div>`;
  }).join('');
}

/* ---------- ADMIN / STAFF / TEACHER VIEW (post + manage) ---------- */
function renderAdminAnnouncements(){
  loadAnnouncements();
  startAnnouncementsListener();
  const classes = announceClassList();
  const classOptions = ['<option value="ALL">All students</option>']
    .concat(classes.map(c => `<option value="${escapeHtmlAnn(c)}">${escapeHtmlAnn(c)}</option>`)).join('');
  return `
  <div class="card">
    <h3 style="margin:0 0 12px;">📢 Post an Announcement</h3>
    <div style="display:grid; gap:10px; max-width:640px;">
      <div>
        <label style="font-size:12px; color:var(--ink-soft); display:block; margin-bottom:3px;">Title</label>
        <input id="annTitle" placeholder="e.g. Holiday Notice" style="width:100%; padding:10px 12px; border:1px solid var(--line); border-radius:8px; font-family:inherit; font-size:14px;">
      </div>
      <div>
        <label style="font-size:12px; color:var(--ink-soft); display:block; margin-bottom:3px;">Message</label>
        <textarea id="annBody" rows="4" placeholder="Write the announcement here…" style="width:100%; padding:10px 12px; border:1px solid var(--line); border-radius:8px; font-family:inherit; font-size:14px; resize:vertical;"></textarea>
      </div>
      <div>
        <label style="font-size:12px; color:var(--ink-soft); display:block; margin-bottom:3px;">Send to</label>
        <select id="annTarget" style="width:100%; padding:10px 12px; border:1px solid var(--line); border-radius:8px; font-family:inherit; font-size:14px;">${classOptions}</select>
      </div>
      <label style="display:flex; align-items:center; gap:8px; font-size:13.5px; color:var(--ink); cursor:pointer;">
        <input type="checkbox" id="annPush" checked style="width:16px; height:16px;">
        Also send as phone notification
      </label>
      <div id="annPushNote" style="font-size:12px; color:#b5730f; background:#faf0dd; border:1px solid #efd9a8; border-radius:8px; padding:8px 10px;">
        Note: phone notifications require the Firebase send function to be set up. Until then, the announcement still posts to the notice board (students see it in-app), but no push is sent.
      </div>
      <button onclick="postAnnouncement()" style="background:var(--maroon); color:#fff; border:none; padding:11px 18px; border-radius:9px; font-family:inherit; font-size:14px; font-weight:600; cursor:pointer; justify-self:start;">Post Announcement</button>
    </div>
  </div>
  <div class="card">
    <h3 style="margin:0 0 12px;">Posted Announcements</h3>
    <div id="annManageList">${adminAnnouncementsListHtml()}</div>
  </div>`;
}
function adminAnnouncementsListHtml(){
  if(!announcementsCache.length) return `<div style="text-align:center; color:var(--ink-soft); padding:24px; font-size:13.5px;">Nothing posted yet.</div>`;
  return announcementsCache.map(a => {
    const d = new Date(a.created_at);
    const dateStr = d.toLocaleDateString('en-US',{month:'short', day:'numeric', year:'numeric'}) + ' · ' + d.toLocaleTimeString('en-US',{hour:'numeric', minute:'2-digit'});
    const tag = (a.target_class && a.target_class!=='ALL') ? a.target_class : 'All students';
    return `<div style="border:1px solid var(--line); border-radius:10px; padding:12px 14px; margin-bottom:10px; display:flex; justify-content:space-between; gap:12px; align-items:flex-start;">
      <div style="flex:1;">
        <div style="font-weight:700; font-size:14.5px; color:var(--maroon);">${escapeHtmlAnn(a.title)}</div>
        <div style="font-size:13.5px; color:var(--ink); margin:4px 0; white-space:pre-wrap;">${escapeHtmlAnn(a.body)}</div>
        <div style="font-size:12px; color:var(--ink-soft);">${tag} · ${a.posted_by ? escapeHtmlAnn(a.posted_by)+' · ' : ''}${dateStr}</div>
      </div>
      <button onclick="deleteAnnouncement('${a.id}')" style="background:#f8e7e5; color:#b5312a; border:1px solid #f0c4c0; padding:6px 10px; border-radius:8px; font-family:inherit; font-size:12px; font-weight:600; cursor:pointer; white-space:nowrap;">Delete</button>
    </div>`;
  }).join('');
}

async function postAnnouncement(){
  const title = document.getElementById('annTitle').value.trim();
  const body = document.getElementById('annBody').value.trim();
  const target = document.getElementById('annTarget').value;
  const wantPush = document.getElementById('annPush').checked;
  if(!title || !body){ alert('Please enter both a title and a message.'); return; }
  const postedBy = (SESSION.role==='admin') ? 'Director' : (SESSION.name || SESSION.username || 'Staff');

  const row = { title, body, target_class: target, posted_by: postedBy };
  try{
    const { error } = await sb.from('announcements').insert(row);
    if(error) throw error;
    document.getElementById('annTitle').value='';
    document.getElementById('annBody').value='';
    // Push hook — dormant until Edge Function exists
    if(wantPush){ trySendAnnouncementPush(title, body, target); }
    loadAnnouncements();
    alert('Announcement posted.');
  }catch(err){
    console.error('post announcement failed', err);
    alert('Could not post the announcement. Please check your connection and try again.');
  }
}

async function deleteAnnouncement(id){
  if(!confirm('Delete this announcement?')) return;
  try{
    const { error } = await sb.from('announcements').delete().eq('id', id);
    if(error) throw error;
    loadAnnouncements();
  }catch(err){ console.error(err); alert('Could not delete. Try again.'); }
}

/* Push hook — will call the Edge Function once it's deployed.
   For now it silently no-ops if the function/URL isn't configured. */
const NOTIFY_FUNCTION_URL = ""; // to be filled once the send-notification Edge Function is deployed
async function trySendAnnouncementPush(title, body, target){
  if(!NOTIFY_FUNCTION_URL) return; // dormant until set up
  try{
    await fetch(NOTIFY_FUNCTION_URL, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ title, body, target_class: target })
    });
  }catch(err){ console.error('push send failed', err); }
}

function escapeHtmlAnn(s){
  return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

/* ================= GATE SCANNER =================
   RFID/QR gate attendance. The card is encoded with the student's ROLL NUMBER.
   A USB RFID reader (or QR scanner) types the roll number + Enter into the scan box.
   On scan we mark the student Present for TODAY using the same the server attendance
   model the rest of the portal uses, so it flows into every attendance view. */
let gateScanFeed = [];   // {roll,name,time,kind}  kind: ok|dup|err  (session only)
let gateTodayKey = null;

function gateToday(){
  const d = new Date();
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
}
function gateNowTime(){
  const d = new Date(); let h=d.getHours(); const ap=h>=12?'PM':'AM'; h=h%12||12;
  return h+':'+String(d.getMinutes()).padStart(2,'0')+' '+ap;
}
function gatePresentCountToday(){
  const t = gateToday();
  return DB.students.filter(s => (s.attendance||[]).some(a=>a.date===t && a.status==='Present')).length;
}

function renderGateScanner(){
  gateTodayKey = gateToday();
  const total = DB.students.length;
  const present = gatePresentCountToday();
  const dateLabel = new Date().toLocaleDateString('en-US',{weekday:'long', month:'long', day:'numeric', year:'numeric'});
  return `
  <div class="card">
    <h3 style="margin:0 0 4px;">📟 Gate Scanner</h3>
    <p style="color:var(--ink-soft); font-size:13.5px; margin:0 0 16px;">
      Tap a student's RFID card on the reader. Each student's card must have its <b>RFID code registered</b> in their profile (Manage Students). Each tap marks the student <b>Present</b> for today and appears instantly in the Attendance section.
    </p>

    <div style="display:grid; grid-template-columns:1.1fr .9fr; gap:16px;" class="gate-grid">
      <div>
        <input id="gateScanInput" autocomplete="off" placeholder="Waiting for card tap…"
          style="width:100%; font-size:22px; padding:16px 18px; border:2px dashed var(--line); border-radius:12px; text-align:center; letter-spacing:1px; outline:none;"
          oninput="gateOnInput(event)" onkeydown="gateOnKey(event)">
        <div style="font-size:12px; color:var(--ink-soft); text-align:center; margin-top:8px;">
          Keep this box focused. The reader types the roll number and presses Enter automatically.
        </div>

        <div id="gateStatus" style="margin-top:16px; border-radius:12px; padding:22px; text-align:center; min-height:140px; display:flex; flex-direction:column; align-items:center; justify-content:center; background:#faf9f4; border:1px solid var(--line);">
          <div style="font-size:16px; font-weight:600; color:var(--ink-soft);">Ready to scan</div>
          <div style="font-size:13px; color:var(--ink-soft); margin-top:4px;">${dateLabel}</div>
        </div>

        <div style="display:flex; gap:10px; margin-top:14px;">
          <div style="flex:1; background:#e4f2e9; border:1px solid #bfe0cd; border-radius:10px; padding:12px; text-align:center;">
            <div id="gatePresent" style="font-size:26px; font-weight:700; color:#1d7a4d;">${present}</div>
            <div style="font-size:11px; text-transform:uppercase; letter-spacing:.4px; color:#1d7a4d;">Present today</div>
          </div>
          <div style="flex:1; background:#faf9f4; border:1px solid var(--line); border-radius:10px; padding:12px; text-align:center;">
            <div id="gateAbsent" style="font-size:26px; font-weight:700; color:#b5312a;">${Math.max(0,total-present)}</div>
            <div style="font-size:11px; text-transform:uppercase; letter-spacing:.4px; color:var(--ink-soft);">Not yet in</div>
          </div>
          <div style="flex:1; background:#faf9f4; border:1px solid var(--line); border-radius:10px; padding:12px; text-align:center;">
            <div style="font-size:26px; font-weight:700;">${total}</div>
            <div style="font-size:11px; text-transform:uppercase; letter-spacing:.4px; color:var(--ink-soft);">Total</div>
          </div>
        </div>
      </div>

      <div>
        <h4 style="margin:0 0 8px; font-size:13px; text-transform:uppercase; letter-spacing:.5px; color:var(--ink-soft);">This session's scans</h4>
        <div style="border:1px solid var(--line); border-radius:10px; max-height:360px; overflow-y:auto;">
          <table style="width:100%; border-collapse:collapse; font-size:13px;">
            <thead><tr>
              <th style="text-align:left; padding:8px 10px; border-bottom:1px solid var(--line); font-size:11px; text-transform:uppercase; color:var(--ink-soft);">Time</th>
              <th style="text-align:left; padding:8px 10px; border-bottom:1px solid var(--line); font-size:11px; text-transform:uppercase; color:var(--ink-soft);">Name</th>
              <th style="text-align:left; padding:8px 10px; border-bottom:1px solid var(--line); font-size:11px; text-transform:uppercase; color:var(--ink-soft);">Status</th>
            </tr></thead>
            <tbody id="gateFeedBody">
              <tr><td colspan="3" class="empty-state" style="text-align:center; padding:24px; color:var(--ink-soft);">No scans yet this session.</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>`;
}

function gateStartFocus(){
  setTimeout(function(){ var el=document.getElementById('gateScanInput'); if(el) el.focus(); }, 60);
  if(!window.__gateFocusGuard){
    window.__gateFocusGuard = setInterval(function(){
      if(typeof currentTab==='undefined' || currentTab!=='gatescan') return;
      var el=document.getElementById('gateScanInput');
      var a=document.activeElement;
      if(el && a && !a.matches('input,select,textarea,button')) el.focus();
    }, 1500);
  }
}

function gateOnKey(e){
  if(e.key==='Enter'){
    const box = e.target;
    const code = box.value.trim();
    box.value='';
    if(code) gateHandleScan(code);
  }
}
function gateOnInput(e){ /* reserved: some readers send no Enter; handled by key */ }

async function gateHandleScan(code){
  // Primary match: RFID card code (case-insensitive hex). Fallback: roll number.
  const codeLc = code.toLowerCase();
  let s = DB.students.find(x => (x.cardId||'').toLowerCase() === codeLc && x.cardId);
  if(!s){
    s = DB.students.find(x => x.roll === code);
  }
  if(!s){
    s = DB.students.find(x => x.roll.toLowerCase() === codeLc);
  }
  if(!s){
    gateShowStatus('err', { title:'Card not recognised', sub:'Card “'+code+'” is not linked to any student' });
    gatePushFeed({ time:gateNowTime(), name:'Unknown ('+code+')', kind:'err' });
    return;
  }
  const today = gateToday();
  const existing = (s.attendance||[]).find(a => a.date === today);
  if(existing && existing.status==='Present'){
    const feeStatusDup = (()=>{
    const fees = s.fees || [];
    const due = fees.filter(f=>f.status==='Due');
    return due.length === 0 ? 'Paid' : 'Due ('+due.length+' month'+(due.length>1?'s':'')+' unpaid)';
  })();
  gateShowStatus('dup', { title:s.name, sub:'Roll '+s.roll, big:'Already marked present today', feeStatus: feeStatusDup });
    gatePushFeed({ time:gateNowTime(), name:s.name, kind:'dup' });
    return;
  }
  // mark present — same model & the server call the portal uses everywhere
  const current = s.attendance || [];
  const idx = current.findIndex(a => a.date === today);
  let updated;
  if(idx > -1){ updated = [...current]; updated[idx] = { date:today, status:'Present' }; }
  else { updated = [...current, { date:today, status:'Present' }]; }

  // optimistic local update so counts move instantly
  s.attendance = updated;
  const feeStatusGate = (()=>{
    const fees = s.fees || [];
    const due = fees.filter(f=>f.status==='Due');
    return due.length === 0 ? 'Paid' : 'Due ('+due.length+' month'+(due.length>1?'s':'')+' unpaid)';
  })();
  gateShowStatus('ok', { title:s.name, sub:'Roll '+s.roll+' • '+gateNowTime(), big:'Marked present', feeStatus: feeStatusGate });
  gatePushFeed({ time:gateNowTime(), name:s.name, kind:'ok' });
  gateUpdateCounts();

  if(DATA_READY && sb){
    try{
      const { error } = await sb.from('students').update({ attendance: updated }).eq('roll', s.roll);
      if(error) throw error;
    }catch(err){
      console.error('Gate scan save failed:', err);
      gateShowStatus('err', { title:s.name, sub:'Roll '+s.roll, big:'⚠ Save failed — check connection & tap again' });
      // revert optimistic change so it isn't silently lost
      s.attendance = current;
      gateUpdateCounts();
    }
  }
}

function gateShowStatus(kind, d){
  const el = document.getElementById('gateStatus');
  if(!el) return;
  const styles = {
    ok:  { bg:'#e4f2e9', bd:'#bfe0cd', tc:'#1d7a4d' },
    dup: { bg:'#faf0dd', bd:'#efd9a8', tc:'#b5730f' },
    err: { bg:'#f8e7e5', bd:'#f0c4c0', tc:'#b5312a' }
  }[kind] || { bg:'#faf9f4', bd:'var(--line)', tc:'var(--ink)' };
  el.style.background = styles.bg;
  el.style.borderColor = styles.bd;
  let html = '';
  const initial = (d.title && /^[A-Za-z]/.test(d.title)) ? d.title[0].toUpperCase() : '?';
  if(kind==='ok' || kind==='dup'){
    html += '<div style="width:64px; height:64px; border-radius:50%; background:#fff; border:3px solid '+styles.bd+'; display:flex; align-items:center; justify-content:center; font-size:26px; font-weight:700; color:'+styles.tc+'; margin-bottom:8px;">'+initial+'</div>';
  }
  html += '<div style="font-size:21px; font-weight:700; color:'+styles.tc+';">'+d.title+'</div>';
  if(d.sub) html += '<div style="font-size:13.5px; color:var(--ink-soft); margin-top:2px;">'+d.sub+'</div>';
  if(d.big) html += '<div style="font-size:15px; font-weight:600; color:'+styles.tc+'; margin-top:6px;">'+d.big+'</div>';
  if(d.feeStatus !== undefined){
    const feeColor = d.feeStatus === 'Paid'
      ? 'background:#e4f2e9; color:#1d7a4d; border:1px solid #bfe0cd;'
      : 'background:#f8e7e5; color:#b5312a; border:1px solid #f0c4c0;';
    const feeIcon = d.feeStatus === 'Paid' ? '✅' : '⚠️';
    html += '<div style="margin-top:10px; display:inline-block; padding:6px 16px; border-radius:20px; font-size:14px; font-weight:700; '+feeColor+'">'+feeIcon+' Fee: '+d.feeStatus+'</div>';
    if(d.feeStatus !== 'Paid'){
      html += '<div style="font-size:12px; color:#b5312a; margin-top:4px;">⚠️ Please pay fee at the office</div>';
    }
  }
  el.innerHTML = html;
}

function gatePushFeed(row){
  gateScanFeed.unshift(row);
  if(gateScanFeed.length > 200) gateScanFeed.pop();
  const tb = document.getElementById('gateFeedBody');
  if(!tb) return;
  const tagStyle = {
    ok:'background:#e4f2e9;color:#1d7a4d;', dup:'background:#faf0dd;color:#b5730f;', err:'background:#f8e7e5;color:#b5312a;'
  }[row.kind] || '';
  const label = { ok:'Present', dup:'Duplicate', err:'Not found' }[row.kind] || '';
  tb.innerHTML = gateScanFeed.map(r => {
    const ts = { ok:'background:#e4f2e9;color:#1d7a4d;', dup:'background:#faf0dd;color:#b5730f;', err:'background:#f8e7e5;color:#b5312a;' }[r.kind] || '';
    const lb = { ok:'Present', dup:'Duplicate', err:'Not found' }[r.kind] || '';
    return '<tr><td style="padding:8px 10px; border-bottom:1px solid var(--line); font-variant-numeric:tabular-nums;">'+r.time+'</td>'+
           '<td style="padding:8px 10px; border-bottom:1px solid var(--line);">'+r.name+'</td>'+
           '<td style="padding:8px 10px; border-bottom:1px solid var(--line);"><span style="display:inline-block; font-size:11px; font-weight:600; padding:2px 8px; border-radius:20px; '+ts+'">'+lb+'</span></td></tr>';
  }).join('');
}

function gateUpdateCounts(){
  const total = DB.students.length;
  const present = gatePresentCountToday();
  const p = document.getElementById('gatePresent');
  const a = document.getElementById('gateAbsent');
  if(p) p.textContent = present;
  if(a) a.textContent = Math.max(0, total - present);
}

function renderAdminAttendance(){
  const classOpts = attendanceClassOptions().map(c=>`<option value="${c}" ${c===attendanceClassFilter?'selected':''}>${c}</option>`).join('');
  ensureDefaultPresent();
  return `<div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
      <h3 style="margin:0;">Attendance</h3>
      <div class="kebab-wrap">
        <button class="kebab-btn" onclick="toggleKebabMenu('attendanceKebab')">⋮</button>
        <div class="kebab-menu" id="attendanceKebab">
          <div class="kebab-label">Sort By</div>
          <button class="${sortState.attendance==='name'?'active':''}" onclick="setSortBy('attendance','name')">Name (A–Z)</button>
          <button class="${sortState.attendance==='roll'?'active':''}" onclick="setSortBy('attendance','roll')">Roll No. (A–Z)</button>
          <button class="${sortState.attendance==='pct-desc'?'active':''}" onclick="setSortBy('attendance','pct-desc')">Attendance % (High–Low)</button>
          <button class="${sortState.attendance==='pct'?'active':''}" onclick="setSortBy('attendance','pct')">Attendance % (Low–High)</button>
          <div class="kebab-divider"></div>
          <button onclick="printAttendance()">🖨 Print Attendance Sheet</button>
        </div>
      </div>
    </div>
    <div class="row2" style="margin:12px 0 14px;">
      <div>
        <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Class</label>
        <select onchange="setAttendanceClass(this.value)" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;">${classOpts}</select>
      </div>
      <div>
        <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Date</label>
        <input type="date" value="${attendanceDate}" onchange="setAttendanceDate(this.value)" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;">
      </div>
    </div>
    <div class="search-bar"><input type="text" placeholder="Search by name, roll no. or class..." value="${searchQuery.attendance}" oninput="updateSearch('attendance', this.value)"></div>
    <table><thead><tr><th>Roll No.</th><th>Name</th><th>Class</th><th>Attendance %</th><th>Today's Status</th><th>Mark</th></tr></thead>
    <tbody id="attendanceTbody">${attendanceTableRows()}</tbody></table>
  </div>`;
}

function renderAdminResults(){
  const quizzes = DB.quizzes || [];
  const quizSummaryRows = quizzes.map(q => {
    const attempts = (DB.quizAttempts||[]).filter(a=>a.quizId===q.id);
    const avg = attempts.length ? Math.round(attempts.reduce((s,a)=>s+a.percentage,0)/attempts.length) : null;
    return `<tr class="ledger-row">
      <td>${q.title}</td><td>${q.subject}</td><td>${q.cls}</td>
      <td>${attempts.length}</td><td>${avg!==null?avg+'%':'—'}</td>
      <td><button class="btn small" onclick="quizResultsViewId=${q.id}; goTab('quizzes');">View</button></td>
    </tr>`;
  }).join('');
  return `
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
      <h3 style="margin:0;">Results — All Students</h3>
      <div class="kebab-wrap">
        <button class="kebab-btn" onclick="toggleKebabMenu('resultsKebab')">⋮</button>
        <div class="kebab-menu" id="resultsKebab">
          <div class="kebab-label">Sort By</div>
          <button class="${sortState.results==='name'?'active':''}" onclick="setSortBy('results','name')">Name (A–Z)</button>
          <button class="${sortState.results==='roll'?'active':''}" onclick="setSortBy('results','roll')">Roll No. (A–Z)</button>
          <div class="kebab-divider"></div>
          <button class="danger" onclick="deleteExam()">🗑 Delete an Exam (all students)</button>
        </div>
      </div>
    </div>
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin:12px 0 4px;">Class</label>
    <select onchange="setResultsClass(this.value)" style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:14px;">${attendanceClassOptions().map(c=>`<option value="${c}" ${c===resultsClassFilter?'selected':''}>${c}</option>`).join('')}</select>
    <div class="search-bar"><input type="text" placeholder="Search by name, roll no. or class..." value="${searchQuery.results}" oninput="updateSearch('results', this.value)"></div>
    <table><thead><tr><th>Roll No.</th><th>Name</th><th>Records</th><th>Action</th></tr></thead>
    <tbody id="resultsTbody">${resultsTableRows()}</tbody></table>
  </div>
  <div class="card">
    <h3>Online Quiz Results</h3>
    <table><thead><tr><th>Quiz</th><th>Subject</th><th>Class</th><th>Attempts</th><th>Avg %</th><th></th></tr></thead>
    <tbody>${quizSummaryRows || '<tr><td colspan="6" class="empty-state">No quizzes created yet.</td></tr>'}</tbody></table>
  </div>
  <div class="card">
    <h3>Import Results from Excel or Word</h3>
    <div class="row2">
      <div><label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Exam Name</label><input id="excelExamName" placeholder="e.g. 1st Monthly Test" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;"></div>
      <div><label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Subject</label><input id="excelSubject" placeholder="e.g. Combined / Physics" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;"></div>
    </div>
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Total Marks (max possible, for register-style files only)</label>
    <input id="excelTotalMarks" type="number" value="100" style="width:100%;max-width:200px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:14px;">
    <input type="file" id="resultsFileInput" accept=".xlsx,.xls,.docx,.doc" onchange="handleResultsFileUpload(event)">
  </div>
  <div class="card">
    <h3>Import Results from PDF</h3>
    <div class="row2">
      <div><label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Exam Name</label><input id="pdfExamName" placeholder="e.g. 7th Weekly Test" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;"></div>
      <div><label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Subject</label><input id="pdfSubject" placeholder="e.g. Combined / Physics" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;"></div>
    </div>
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Total Marks (max possible)</label>
    <input id="pdfTotalMarks" type="number" value="200" style="width:100%;max-width:200px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:14px;">
    <input type="file" id="resultsPdfInput" accept=".pdf" onchange="handleResultsPdfUpload(event)">
  </div>`;
}

function renderAdminExpenses(){
  const periodTotal = DB.expenses.filter(expenseInPeriod).reduce((sum,e)=>sum+Number(e.amount||0),0);
  return `
  ${periodSelectorHtml()}
  <div class="grid-cards">
    <div class="stat due"><div class="label">Total Expenses${dashboardPeriodMode!=='all'?' ('+dashboardPeriodValue+')':''}</div><div class="value">${fmtMoney(periodTotal)}</div></div>
  </div>
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
      <h3 style="margin:0;">All Expenses (${DB.expenses.length})</h3>
      <div class="kebab-wrap">
        <button class="kebab-btn" onclick="toggleKebabMenu('expensesKebab')">⋮</button>
        <div class="kebab-menu" id="expensesKebab">
          <div class="kebab-label">Sort By</div>
          <button class="${sortState.expenses==='date-desc'?'active':''}" onclick="setSortBy('expenses','date-desc')">Date (Newest First)</button>
          <button class="${sortState.expenses==='date'?'active':''}" onclick="setSortBy('expenses','date')">Date (Oldest First)</button>
          <button class="${sortState.expenses==='amount-desc'?'active':''}" onclick="setSortBy('expenses','amount-desc')">Amount (High–Low)</button>
          <button class="${sortState.expenses==='amount'?'active':''}" onclick="setSortBy('expenses','amount')">Amount (Low–High)</button>
        </div>
      </div>
    </div>
    <div class="actions-row" style="margin-top:12px;"><button class="btn gold" onclick="openAddExpense()">+ Add Expense</button></div>
    <div class="search-bar"><input type="text" placeholder="Search by category, description or date..." value="${searchQuery.expenses}" oninput="updateSearch('expenses', this.value)"></div>
    <table><thead><tr><th>Date</th><th>Category</th><th>Description</th><th>Amount</th><th>Action</th></tr></thead>
    <tbody id="expensesTbody">${expensesTableRows()}</tbody></table>
  </div>
  <div class="card">
    <h3>Import Expenses from Excel</h3>
    <input type="file" id="expenseFileInput" accept=".xlsx,.xls" onchange="handleExpenseExcelUpload(event)">
  </div>`;
}

/* ================= LOGIN DATA ================= */
function generatePassword(){
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'; // no 0/O/1/l/I to avoid confusion
  let pass = '';
  for(let i=0;i<8;i++) pass += chars[Math.floor(Math.random()*chars.length)];
  return pass;
}
let loginsClassFilter = 'All Classes';
function setLoginsClass(cls){
  loginsClassFilter = cls;
  refreshLoginsTable();
}
function loginsFilteredList(){
  let list = DB.students.filter(s=>matchStudent(s, searchQuery.logins));
  if(loginsClassFilter !== 'All Classes') list = list.filter(s=>s.class===loginsClassFilter);
  return list;
}
function loginsTableRows(){
  let list = loginsFilteredList();
  list = sortByField(list, sortState.logins, {
    name: s=>s.name.toLowerCase(), roll: s=>rollKey(s.roll),
    default: s=>rollKey(s.roll)
  });
  const rows = list.map(s => `
    <tr class="ledger-row">
      <td data-label="Roll No." class="mono">${s.roll}</td><td data-label="Name">${s.name}</td><td data-label="Class">${s.class}</td>
      <td data-label="Password" class="mono"><span style=\"color:var(--ink-soft);\">\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022</span></td>
      <td data-label="Action"><button class="btn small" onclick="regenerateStudentPassword('${s.roll}')">Regenerate</button></td>
    </tr>`).join('');
  return rows || `<tr><td colspan="5" class="empty-state">No matching students.</td></tr>`;
}
function refreshLoginsTable(){ document.getElementById('loginsTbody').innerHTML = loginsTableRows(); }
function renderAdminLogins(){
  return `<div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
      <h3 style="margin:0;">Student Login Data (${DB.students.length})</h3>
      <div class="kebab-wrap">
        <button class="kebab-btn" onclick="toggleKebabMenu('loginsKebab')">⋮</button>
        <div class="kebab-menu" id="loginsKebab">
          <div class="kebab-label">Sort By</div>
          <button class="${sortState.logins==='name'?'active':''}" onclick="setSortBy('logins','name')">Name (A–Z)</button>
          <button class="${sortState.logins==='roll'?'active':''}" onclick="setSortBy('logins','roll')">Roll No. (A–Z)</button>
          <div class="kebab-divider"></div>
          <button onclick="exportLoginData()">⬇ Export Login Data</button>
          <div class="kebab-divider"></div>
          <button class="danger" onclick="resetAllPasswordsToRoll()">Reset All Passwords to Roll Number</button>
          <button class="danger" onclick="regenerateAllPasswords()">Regenerate All Passwords (Random)</button>
        </div>
      </div>
    </div>
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin:12px 0 4px;">Class</label>
    <select onchange="setLoginsClass(this.value)" style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;margin-bottom:14px;">${attendanceClassOptions().map(c=>`<option value="${c}" ${c===loginsClassFilter?'selected':''}>${c}</option>`).join('')}</select>
    <div class="search-bar"><input type="text" placeholder="Search by name, roll no. or class..." value="${searchQuery.logins}" oninput="updateSearch('logins', this.value)"></div>
    <table><thead><tr><th>Roll No.</th><th>Name</th><th>Class</th><th>Password</th><th>Action</th></tr></thead>
    <tbody id="loginsTbody">${loginsTableRows()}</tbody></table>
  </div>`;
}
function exportLoginData(){
  const list = loginsFilteredList();
  if(!list.length){ alert('No students to export.'); return; }
  const csv = 'roll,name,class\n' + list.map(s=>`${s.roll},"${s.name}",${s.class}`).join('\n');
  const blob = new Blob([csv], {type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `login_data_${new Date().toISOString().slice(0,10)}.csv`;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
async function resetAllPasswordsToRoll(){
  if(!confirm(`This sets every one of your ${DB.students.length} students' passwords back to their own roll number (e.g. roll IMS-101 → password IMS-101), replacing whatever password they currently have. Continue?`)) return;
  try{
    for(const s of DB.students){
      const { error } = await sb.from('students').update({ password: s.roll }).eq('roll', s.roll);
      if(error) throw error;
    }
  } catch(err){ console.error(err); alert('Something went wrong partway through: ' + err.message + '\n\nSome passwords may already be reset — check the Login Data list.'); return; }
  alert('Done. Every student\'s password is now set to their own roll number.');
}
function regenerateStudentPassword(roll){
  if(!confirm(`Generate a new password for ${roll}? The old password will stop working immediately.`)) return;
  const newPass = generatePassword();
  sb.from('students').update({ password: newPass }).eq('roll', roll).then(({error})=>{
    if(error){ console.error(error); alert('Could not update password: ' + error.message); return; }
    alert(`New password for ${roll}: ${newPass}\n\nMake sure to share this with the student.`);
  });
}
async function regenerateAllPasswords(){
  if(!confirm(`This gives every one of your ${DB.students.length} students a brand-new random password, replacing their old ones (which stop working immediately). You'll get a downloadable list afterward. Continue?`)) return;
  const rows = [];
  for(const s of DB.students){
    const newPass = generatePassword();
    rows.push({ roll:s.roll, name:s.name, password:newPass });
  }
  try{
    for(const r of rows){
      const { error } = await sb.from('students').update({ password:r.password }).eq('roll', r.roll);
      if(error) throw error;
    }
  } catch(err){ console.error(err); alert('Something went wrong partway through: ' + err.message + '\n\nSome passwords may already be changed — check the Login Data list.'); return; }
  const csv = 'roll,name,password\n' + rows.map(r=>`${r.roll},"${r.name}",${r.password}`).join('\n');
  const blob = new Blob([csv], {type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'student_passwords.csv';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
  alert('All passwords regenerated. A CSV file with the new passwords has been downloaded — keep it somewhere safe.');
}

/* ================= TEACHER-FACING VIEWS ================= */
/* ================= LIVE CLASS ================= */
function liveClassHostKey(){ return SESSION.username || 'director'; }
function renderHostLiveClass(){
  const hostId = liveClassHostKey();
  const mine = DB.liveClasses.find(lc => lc.hostName === hostId);
  if(mine){
    return `<div class="card">
      <h3>Live Now — ${mine.class} · ${mine.subject}</h3>
      <div class="actions-row"><button class="btn danger" onclick="endLiveClass(${mine.id})">End Class</button></div>
      <div class="live-controls" style="display:flex; gap:10px; margin:12px 0; flex-wrap:wrap;">
        <button class="btn small" onclick="toggleLiveFullscreen('jitsiHost')">🖥️ Fullscreen</button>
        <button class="btn small" onclick="alert('Click the screen-share icon inside the video controls (bottom toolbar) to share your screen with the class.')">📺 Share Screen</button>
      </div>
      <iframe id="jitsiHost" src="https://meet.jit.si/${mine.roomName}#config.prejoinPageEnabled=false" style="width:100%;height:70vh;border:0;border-radius:10px;box-shadow:var(--shadow);" allow="camera; microphone; fullscreen; display-capture" allowfullscreen webkitallowfullscreen mozallowfullscreen></iframe>
    </div>`;
  }
  const classOpts = attendanceClassOptions().map(c=>`<option value="${c}">${c}</option>`).join('');
  const others = DB.liveClasses.filter(lc => lc.hostName !== hostId);
  const othersHtml = others.length ? `
    <div class="card"><h3>Other Live Classes Right Now</h3>
      ${others.map(lc=>`<div class="ledger-row" style="padding:8px 0;">${lc.class} — ${lc.subject}</div>`).join('')}
    </div>` : '';
  return `
  <div class="card">
    <h3>Start a Live Class</h3>
    <div class="row2">
      <div><label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Class</label><select id="lc_class" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;">${classOpts}</select></div>
      <div><label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Subject</label><input id="lc_subject" placeholder="e.g. Physics" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;"></div>
    </div>
    <div class="actions-row" style="margin-top:14px;"><button class="btn gold" onclick="startLiveClass()">▶ Start Live Class</button></div>
  </div>
  ${othersHtml}`;
}
async function startLiveClass(){
  const cls = document.getElementById('lc_class').value;
  const subject = document.getElementById('lc_subject').value.trim() || 'General';
  const roomName = 'inspired-academy-larkana-' + Math.random().toString(36).slice(2,10);
  const hostId = liveClassHostKey();
  const { error } = await sb.from('live_classes').insert({ class:cls, subject, room_name:roomName, host_name:hostId, active:true });
  if(error){ console.error(error); alert('Could not start class: ' + error.message); return; }
}
function endLiveClass(id){
  if(!confirm('End this live class for everyone?')) return;
  sb.from('live_classes').update({ active:false }).eq('id', id).then(({error})=>{
    if(error){ console.error(error); alert('Could not end class: ' + error.message); }
  });
}
function renderStudentLiveClass(){
  const s = getStudent(SESSION.roll);
  const live = DB.liveClasses.filter(lc => lc.class===s.class || lc.class==='All Classes');
  const noteHtml = renderDirectorNote(academySettings.liveClassNote);
  if(!live.length){
    return `${noteHtml}<div class="card"><h3>Live Class</h3><div class="empty-state">No live class right now. Check back once your teacher starts one — this page updates automatically.</div></div>`;
  }
  return noteHtml + live.map((lc, idx) => `
    <div class="card">
      <h3>🔴 Live Now — ${lc.subject}</h3>
      <div class="live-controls">
        <button class="live-btn" onclick="toggleLiveFullscreen('jitsi${idx}')">🖥️ Fullscreen</button>
        <button class="live-btn" onclick="alert('Press the screen share button in the Jitsi controls (top right) to share your screen.')">📺 Share Screen</button>
        <button class="live-btn" onclick="alert('Use the audio/video buttons in Jitsi controls to manage your devices.')">🎤 Mute/Unmute</button>
      </div>
      <iframe id="jitsi${idx}" src="https://meet.jit.si/${lc.roomName}#config.prejoinPageEnabled=false" style="width:100%;height:70vh;border:0;border-radius:10px;box-shadow:var(--shadow);" allow="camera; microphone; fullscreen; display-capture" allowfullscreen webkitallowfullscreen mozallowfullscreen></iframe>
    </div>`).join('');
}

function toggleLiveFullscreen(iframeId){
  const iframe = document.getElementById(iframeId);
  if(iframe.requestFullscreen){
    iframe.requestFullscreen().catch(err => alert('Fullscreen request failed: ' + err.message));
  } else if(iframe.webkitRequestFullscreen){
    iframe.webkitRequestFullscreen();
  } else {
    alert('Fullscreen not supported on this device');
  }
}

function renderTeacherDashboard(){
  const totalStudents = DB.students.length;
  const canSeeFees = SESSION.role==='teacher' ? false
    : SESSION.role==='staff' ? (SESSION.permissions||[]).includes('fees')
    : true;
  // Quick actions — respects each role's permissions
  const qaAllowed = SESSION.role==='teacher' ? (SESSION.permissions || TEACHER_DEFAULT_PERMISSIONS)
                  : SESSION.role==='staff'   ? (SESSION.permissions || [])
                  : null;                     // admin / director = full access
  const qaCan = k => qaAllowed === null ? true : qaAllowed.includes(k);
  const qaItems = [
    ['students',    '\u{1F465}', 'Manage Students',    qaCan('students')],
    ['gatescan',    '\u{1F4DF}', 'Gate Scanner',       qaCan('attendance')],
    ['teachergate', '\u{1F3EB}', 'Teacher Attendance', qaCan('teachergate')],
    ['attendance',  '\u{1F5D3}', 'Mark Attendance',    qaCan('attendance')],
    ['results',     '\u{1F4CA}', 'Results',            qaCan('results')],
    ['materials',   '\u{1F4DA}', 'Study Material',     qaCan('materials')],
    ['assignments', '\u{1F4C4}', 'Assignments',        qaCan('assignments')],
    ['announce',    '\u{1F4E2}', 'Announcements',      qaCan('announce')],
    ['fees',        '\u{1F4B0}', 'Fee Ledger',         canSeeFees],
    ['expenses',    '\u{1F4B5}', 'Expenses',           canSeeFees && qaCan('expenses')],
    ['reports',     '\u{1F4CB}', 'Reports',            qaCan('reports')],
    ['quizzes',     '\u{1F4DD}', 'Online Quiz',        qaCan('quizzes')],
    ['admissions',  '\u{1F4DD}', 'Admissions',         qaCan('admissions')]
  ];
  const qaTiles = qaItems.filter(x => x[3]).map(function(it){
    return '<div class="quick-tile" onclick="goTab(\'' + it[0] + '\')">'
         + '<div class="quick-icon">' + it[1] + '</div>'
         + '<div class="quick-label">' + it[2] + '</div></div>';
  }).join('');
  return `
  <div class="grid-cards">
    <div class="stat"><div class="label">Total Students</div><div class="value">${totalStudents}</div></div>
    <div class="stat"><div class="label">Study Materials</div><div class="value">${DB.materials.length}</div></div>
  </div>
  <div class="card"><h3>Quick Actions</h3>
    <div class="quick-grid">${qaTiles}</div>
  </div>`;
}
function renderTeacherStudents(){
  const list = DB.students.filter(s=>matchStudent(s, searchQuery.students));
  const rows = list.map(s => `
    <tr class="ledger-row">
      <td data-label="Roll No." class="mono">${s.roll}</td><td data-label="Name">${s.name}</td><td data-label="Class">${s.class}</td><td data-label="Phone">${s.phone}</td>
    </tr>`).join('') || `<tr><td colspan="4" class="empty-state">No matching students.</td></tr>`;
  return `<div class="card"><h3>All Students (${DB.students.length})</h3>
    <div class="search-bar"><input type="text" placeholder="Search by name, roll no. or class..." value="${searchQuery.students}" oninput="updateSearch('students', this.value)"></div>
    <table><thead><tr><th>Roll No.</th><th>Name</th><th>Class</th><th>Phone</th></tr></thead>
    <tbody id="studentsTbody">${rows}</tbody></table>
  </div>`;
}
function renderTeacherProfile(){
  const t = DB.teachers.find(x=>x.username===SESSION.username) || {};
  return `<div class="card"><h3>My Profile</h3>
    <table>
      <tr class="ledger-row"><td><b>Username</b></td><td class="mono">${SESSION.username}</td></tr>
      <tr class="ledger-row"><td><b>Name</b></td><td>${t.name||''}</td></tr>
      <tr class="ledger-row"><td><b>Subject</b></td><td>${t.subject||''}</td></tr>
    </table>
  </div>
  <div class="card"><h3>Change Username</h3>
    ${changeUsernameFormHtml('teacher', SESSION.username)}
  </div>
  <div class="card"><h3>Change Password</h3>
    ${changePasswordFormHtml('teacher')}
  </div>`;
}
function renderStaffProfile(){
  const a = DB.admins.find(x=>x.username===SESSION.username) || {};
  const allowed = SESSION.permissions || [];
  const permLabels = STAFF_PERMISSION_ITEMS.filter(([key])=>allowed.includes(key)).map(([,label])=>label);
  return `<div class="card"><h3>My Profile</h3>
    <table>
      <tr class="ledger-row"><td><b>Username</b></td><td class="mono">${SESSION.username}</td></tr>
      <tr class="ledger-row"><td><b>Name</b></td><td>${a.name||''}</td></tr>
      <tr class="ledger-row"><td><b>Access Granted</b></td><td>${permLabels.join(', ') || 'None yet — contact the Director'}</td></tr>
    </table>
  </div>
  <div class="card"><h3>Change Username</h3>
    ${changeUsernameFormHtml('staff', SESSION.username)}
  </div>
  <div class="card"><h3>Change Password</h3>
    ${changePasswordFormHtml('staff')}
  </div>`;
}

/* ================= MANAGE TEACHERS (Director only) ================= */
function renderAdminTeachers(){
  return `
  <div class="card">
    <h3>Add Teacher</h3>
    <div class="row2">
      <div><label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Username</label><input id="newTeacherUser" placeholder="e.g. sir.muneer" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;"></div>
      <div><label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Full Name</label><input id="newTeacherName" placeholder="e.g. Muneer Ahmed" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;"></div>
    </div>
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Subject (optional)</label>
    <div class="row2"><div><input id="newTeacherSubject" placeholder="e.g. Physics" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;"></div><div><label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">RFID Card ID</label><input id="newTeacherCard" placeholder="Tap card here to fill" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;"></div></div><div style="margin-bottom:14px;"></div>
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:8px;">Allow access to:</label>
    <div id="newTeacherPerms" style="margin-bottom:14px;">${permCheckboxesHtml('newTeacherPerm', TEACHER_DEFAULT_PERMISSIONS, TEACHER_PERMISSION_ITEMS)}</div>
    <div class="actions-row"><button class="btn gold" onclick="addTeacher()">+ Add Teacher</button></div>
  </div>
  <div class="card">
    <h3>All Teachers (${DB.teachers.length})</h3>
    <div id="teachersListWrap">${teachersListHtml()}</div>
  </div>`;
}
function teachersListHtml(){
  if(!DB.teachers.length) return `<div class="empty-state">No teacher accounts yet. Add one above.</div>`;
  return DB.teachers.map(t => `
    <div class="card" style="background:var(--light-gray); margin-bottom:14px;">
      <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:10px;">
        <div>
          <b>${t.name}</b> <span class="mono" style="color:var(--ink-soft); font-size:13px;">(${t.username})</span>${t.subject ? ` — ${t.subject}` : ''}<br>
          <span class="mono" style="font-size:13px;">Password: ${t.password}</span><br>
          <span class="mono" style="font-size:13px;">RFID Card: ${t.cardId ? t.cardId : '<i style="color:var(--due-ink);">not set</i>'}</span>
        </div>
        <div style="display:flex; gap:8px;">
          <button class="btn small" onclick="setTeacherCard('${t.username}')">Set Card</button>
          <button class="btn small" onclick="regenerateTeacherPassword('${t.username}')">New Password</button>
          <button class="btn small danger" onclick="deleteTeacher('${t.username}')">Delete</button>
        </div>
      </div>
      <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin:12px 0 8px;">Allow access to:</label>
      <div id="teacherPerms_${t.username}">${permCheckboxesHtml('editTeacherPerm_'+t.username, t.permissions||TEACHER_DEFAULT_PERMISSIONS, TEACHER_PERMISSION_ITEMS)}</div>
      <div class="actions-row" style="margin-top:8px;"><button class="btn small gold" onclick="saveTeacherPermissions('${t.username}')">Save Permissions</button></div>
    </div>`).join('');
}
async function addTeacher(){
  const username = document.getElementById('newTeacherUser').value.trim();
  const name = document.getElementById('newTeacherName').value.trim();
  const subject = document.getElementById('newTeacherSubject').value.trim();
  if(!username || !name){ alert('Please enter a username and name.'); return; }
  const { data: existing } = await sb.from('teachers').select('username').eq('username', username).maybeSingle();
  if(existing){ alert('A teacher with this username already exists.'); return; }
  const permissions = TEACHER_PERMISSION_ITEMS.filter(([key]) => document.getElementById('newTeacherPerm_'+key).checked).map(([key])=>key);
  const password = generatePassword();
  const card_id = (document.getElementById('newTeacherCard')?.value || '').trim();
  const { error } = await sb.from('teachers').insert({ username, name, subject, password, permissions, card_id, attendance: [] });
  if(error){ console.error(error); alert('Could not add teacher: ' + error.message); return; }
  document.getElementById('newTeacherUser').value='';
  document.getElementById('newTeacherName').value='';
  document.getElementById('newTeacherSubject').value='';
  alert(`Teacher account created.\nUsername: ${username}\nPassword: ${password}\n\nMake sure to share these with them.`);
}
function saveTeacherPermissions(username){
  const permissions = TEACHER_PERMISSION_ITEMS.filter(([key]) => document.getElementById('editTeacherPerm_'+username+'_'+key).checked).map(([key])=>key);
  sb.from('teachers').update({ permissions }).eq('username', username).then(({error})=>{
    if(error){ console.error(error); alert('Could not update permissions: ' + error.message); return; }
    alert('Permissions updated.');
  });
}
function regenerateTeacherPassword(username){
  if(!confirm(`Generate a new password for ${username}? Their old password will stop working immediately.`)) return;
  const newPass = generatePassword();
  sb.from('teachers').update({ password:newPass }).eq('username', username).then(({error})=>{
    if(error){ console.error(error); alert('Could not update password: ' + error.message); return; }
    alert(`New password for ${username}: ${newPass}`);
  });
}
function deleteTeacher(username){
  if(!confirm(`Delete teacher account ${username}? This cannot be undone.`)) return;
  sb.from('teachers').delete().eq('username', username).then(({error})=>{
    if(error){ console.error(error); alert('Could not delete: ' + error.message); }
  });
}

/* ================= MANAGE ADMINS (Director only) ================= */
function permCheckboxesHtml(idPrefix, checkedKeys, items){
  items = items || STAFF_PERMISSION_ITEMS;
  return items.map(([key,label]) => `
    <label style="display:flex; align-items:center; gap:6px; font-size:13px; font-weight:400; text-transform:none; margin-bottom:6px;">
      <input type="checkbox" id="${idPrefix}_${key}" ${checkedKeys.includes(key)?'checked':''} style="width:auto;">
      ${label}
    </label>`).join('');
}
function renderAdminAdmins(){
  return `
  <div class="card">
    <h3>Add Admin</h3>
    <div class="row2">
      <div><label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Username</label><input id="newAdminUser" placeholder="e.g. office.clerk" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;"></div>
      <div><label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Full Name</label><input id="newAdminName" placeholder="e.g. Ahsan Khan" style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;"></div>
    </div>
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:8px;">Allow access to:</label>
    <div id="newAdminPerms" style="margin-bottom:14px;">${permCheckboxesHtml('newAdminPerm', [])}</div>
    <div class="actions-row"><button class="btn gold" onclick="addAdmin()">+ Add Admin</button></div>
  </div>
  <div class="card">
    <h3>All Admins (${DB.admins.length})</h3>
    <div id="adminsListWrap">${adminsListHtml()}</div>
  </div>`;
}
function adminsListHtml(){
  if(!DB.admins.length) return `<div class="empty-state">No admin accounts yet. Add one above.</div>`;
  return DB.admins.map(a => `
    <div class="card" style="background:var(--light-gray); margin-bottom:14px;">
      <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:10px;">
        <div>
          <b>${a.name}</b> <span class="mono" style="color:var(--ink-soft); font-size:13px;">(${a.username})</span><br>
          <span class="mono" style="font-size:13px;">Password: ${a.password}</span>
        </div>
        <div style="display:flex; gap:8px;">
          <button class="btn small" onclick="regenerateAdminPassword('${a.username}')">New Password</button>
          <button class="btn small danger" onclick="deleteAdmin('${a.username}')">Delete</button>
        </div>
      </div>
      <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin:12px 0 8px;">Allow access to:</label>
      <div id="adminPerms_${a.username}">${permCheckboxesHtml('editAdminPerm_'+a.username, a.permissions||[])}</div>
      <div class="actions-row" style="margin-top:8px;"><button class="btn small gold" onclick="saveAdminPermissions('${a.username}')">Save Permissions</button></div>
    </div>`).join('');
}
async function addAdmin(){
  const username = document.getElementById('newAdminUser').value.trim();
  const name = document.getElementById('newAdminName').value.trim();
  if(!username || !name){ alert('Please enter a username and name.'); return; }
  const { data: existing } = await sb.from('admins').select('username').eq('username', username).maybeSingle();
  if(existing){ alert('An admin with this username already exists.'); return; }
  const permissions = STAFF_PERMISSION_ITEMS.filter(([key]) => document.getElementById('newAdminPerm_'+key).checked).map(([key])=>key);
  const password = generatePassword();
  const { error } = await sb.from('admins').insert({ username, name, permissions, password });
  if(error){ console.error(error); alert('Could not add admin: ' + error.message); return; }
  document.getElementById('newAdminUser').value='';
  document.getElementById('newAdminName').value='';
  alert(`Admin account created.\nUsername: ${username}\nPassword: ${password}\n\nMake sure to share these with them.`);
}
function saveAdminPermissions(username){
  const permissions = STAFF_PERMISSION_ITEMS.filter(([key]) => document.getElementById('editAdminPerm_'+username+'_'+key).checked).map(([key])=>key);
  sb.from('admins').update({ permissions }).eq('username', username).then(({error})=>{
    if(error){ console.error(error); alert('Could not update permissions: ' + error.message); return; }
    alert('Permissions updated.');
  });
}
function regenerateAdminPassword(username){
  if(!confirm(`Generate a new password for ${username}? Their old password will stop working immediately.`)) return;
  const newPass = generatePassword();
  sb.from('admins').update({ password:newPass }).eq('username', username).then(({error})=>{
    if(error){ console.error(error); alert('Could not update password: ' + error.message); return; }
    alert(`New password for ${username}: ${newPass}`);
  });
}
function deleteAdmin(username){
  if(!confirm(`Delete admin account ${username}? This cannot be undone.`)) return;
  sb.from('admins').delete().eq('username', username).then(({error})=>{
    if(error){ console.error(error); alert('Could not delete: ' + error.message); }
  });
}

/* ================= ADMISSIONS (Director) ================= */
let admissionsClassFilter = 'All Classes';
function setAdmissionsClass(cls){
  admissionsClassFilter = cls;
  renderPage();
}
function renderAdminAdmissions(){
  let apps = DB.admissionApplications;
  if(admissionsClassFilter !== 'All Classes') apps = apps.filter(a=>a.classApplied===admissionsClassFilter);
  const pending = apps.filter(a=>a.status==='Pending');
  const reviewed = apps.filter(a=>a.status!=='Pending');
  const rowHtml = (a, showActions) => `
    <div class="card" style="background:var(--light-gray); margin-bottom:14px;">
      <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:10px;">
        <div>
          <b>${a.name}</b> <span style="color:var(--ink-soft); font-size:13px;">applying for ${a.classApplied}</span><br>
          <span style="font-size:13.5px;">Father: ${a.fatherName} · Phone: ${a.phone}${a.email ? ' · Email: '+a.email : ''}${a.installmentPlan ? ' · Payment Plan: '+a.installmentPlan+' installment'+(a.installmentPlan>1?'s':'')+' (Rs. '+Math.round(45000/a.installmentPlan).toLocaleString()+' each)' : ''}</span><br>
          ${a.previousSchool ? `<span style="font-size:13px; color:var(--ink-soft);">Previous school: ${a.previousSchool}</span><br>` : ''}
          ${a.address ? `<span style="font-size:13px; color:var(--ink-soft);">Address: ${a.address}</span><br>` : ''}
          ${a.notes ? `<span style="font-size:13px; color:var(--ink-soft); font-style:italic;">"${a.notes}"</span><br>` : ''}
          ${a.receiptUrl ? `<a href="${a.receiptUrl}" target="_blank" rel="noopener" class="btn small" style="display:inline-block; margin-top:6px;">🧾 View Fee Receipt</a><br>` : `<span style="font-size:12px; color:var(--ink-soft);">No receipt uploaded</span><br>`}
          <span style="font-size:12px; color:var(--ink-soft);">Submitted: ${new Date(a.submittedAt).toLocaleString()} · Status: <b>${a.status}</b></span>
        </div>
        ${showActions ? `
        <div style="display:flex; gap:8px; align-items:flex-start;">
          <button class="btn small gold" onclick="approveAdmission(${a.id})">Approve → Add as Student</button>
          <button class="btn small danger" onclick="rejectAdmission(${a.id})">Reject</button>
        </div>` : `<div style="display:flex; gap:8px; align-items:flex-start;">
          ${a.email ? `<button class="btn small" onclick="resendApprovalEmail(${a.id})">✉️ Resend Email</button>` : ''}
          <button class="btn small danger" onclick="deleteApprovedAdmission(${a.id})">🗑️ Delete</button>
        </div>`}
      </div>
    </div>`;
  return `
  <div class="card">
    <h3>Filter</h3>
    <label style="font-size:12px;text-transform:uppercase;color:var(--ink-soft);display:block;margin-bottom:4px;">Class Applied For</label>
    <select onchange="setAdmissionsClass(this.value)" style="width:100%;max-width:320px;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;">${attendanceClassOptions().map(c=>`<option value="${c}" ${c===admissionsClassFilter?'selected':''}>${c}</option>`).join('')}</select>
  </div>
  <div class="card">
    <h3>Pending Applications (${pending.length})</h3>
    ${pending.length ? pending.map(a=>rowHtml(a,true)).join('') : '<div class="empty-state">No pending applications right now.</div>'}
  </div>
  <div class="card">
    <h3>Approved Applications (${reviewed.length})</h3>
    ${reviewed.length ? reviewed.map(a=>rowHtml(a,false)).join('') : '<div class="empty-state">No approved applications yet.</div>'}
  </div>`;
}
async function approveAdmission(id){
  const app = DB.admissionApplications.find(a=>a.id===id);
  if(!app) return;
  if(!confirm(`Approve ${app.name} and add them as a student in ${app.classApplied}? This will create their login automatically${app.email ? ' and email it to them' : ''}.`)) return;
  try{
    const { prefix, next } = nextRollForClass(app.classApplied);
    const roll = `${prefix}${next}`;
    const today = new Date().toISOString().slice(0,10);
    let feeAmount, fees;
    if(app.installmentPlan === 2){
      const dueDate = new Date(); dueDate.setMonth(dueDate.getMonth()+2);
      feeAmount = 45000;
      fees = [
        { month:'Installment 1', status:'Paid', date:today, amount:22500 },
        { month:'Installment 2', status:'Due', dueDate:dueDate.toISOString().slice(0,10), amount:22500 }
      ];
    } else if(app.installmentPlan === 1){
      feeAmount = 45000;
      fees = [ { month:'Full Payment', status:'Paid', date:today, amount:45000 } ];
    } else {
      feeAmount = 4500;
      fees = [];
    }
    const { error: insErr } = await sb.from('students').insert({
      roll, password:roll, name:app.name, class:app.classApplied,
      father:app.fatherName, phone:app.phone, email:app.email||null, fee_amount:feeAmount,
      fees, attendance:[], results:[], installment_plan:app.installmentPlan||null
    });
    if(insErr) throw insErr;
    const { error: updErr } = await sb.from('admission_applications').update({ status:'Approved', approved_roll:roll }).eq('id', id);
    if(updErr) throw updErr;

    const emailResult = await sendApprovalEmail(app, roll);
    let emailNote;
    if(emailResult.sent) emailNote = `\n\n✅ Login details have been emailed to ${app.email}.`;
    else if(emailResult.reason==='no-email') emailNote = `\n\n⚠️ No email was on file, so no email was sent — please share the login details with them directly.`;
    else if(emailResult.reason==='not-configured') emailNote = `\n\n⚠️ Email sending isn't set up yet (EmailJS not configured) — please share the login details with them directly.`;
    else emailNote = `\n\n⚠️ Could not send the email automatically — please share the login details with them directly.`;
    alert(`${app.name} has been added as a student.\nRoll Number: ${roll}\nPassword: ${roll}${emailNote}`);
  } catch(err){ console.error(err); alert('Could not approve this application: ' + err.message); }
}
async function resendApprovalEmail(id){
  const app = DB.admissionApplications.find(a=>a.id===id);
  if(!app) return;
  if(!app.email){ alert('No email is on file for this application.'); return; }
  // Older approved records made before this feature may not have approved_roll saved — fall back to matching by phone/name.
  let roll = app.approvedRoll;
  if(!roll){
    const match = DB.students.find(s => s.phone===app.phone && s.name===app.name);
    roll = match ? match.roll : null;
  }
  if(!roll){ alert('Could not find this student\'s roll number to resend. Please share their login details manually.'); return; }
  const result = await sendApprovalEmail(app, roll);
  if(result.sent) alert(`Email resent to ${app.email}.`);
  else if(result.reason==='not-configured') alert('Email sending isn\'t set up yet (EmailJS not configured) — see the setup notes near the top of the file.');
  else alert('Could not send the email. Check the browser console (F12) for details.');
}
function rejectAdmission(id){
  if(!confirm('Reject and delete this application? This cannot be undone.')) return;
  sb.from('admission_applications').delete().eq('id', id).then(({error})=>{
    if(error){ console.error(error); alert('Could not reject: ' + error.message); }
  });
}

function deleteApprovedAdmission(id){
  const app = DB.admissionApplications.find(a=>a.id===id);
  if(!app) return;
  if(!confirm(`Delete the approved admission for ${app.name}? This cannot be undone.`)) return;
  sb.from('admission_applications').delete().eq('id', id).then(({error})=>{
    if(error){ console.error(error); alert('Could not delete: ' + error.message); }
    else{ renderPage(); }
  });
}

/* ================= DIRECTOR ACCOUNT ================= */
function renderAdminAccount(){
  const s = academySettings;
  return `<div class="card"><h3>My Account</h3>
  </div>
  <div class="card"><h3>Change Username</h3>
    ${changeUsernameFormHtml('admin', DB.admin.username)}
  </div>
  <div class="card">
    <h3>Admission Note</h3>
    <div class="csv-drop" style="margin-bottom:14px;">This message shows to everyone on the public "Apply for Admission" form — use it for announcements like which classes are currently open, deadlines, or special instructions. Leave blank to hide it.</div>
    <textarea id="set_admissionNote" placeholder="e.g. Admissions currently open for Class IX and Entrance only. Bring original documents on your first day." style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;font-family:inherit;height:90px;resize:vertical;">${s.admissionNote||''}</textarea>
    <div class="actions-row" style="margin-top:14px;"><button class="btn gold" onclick="saveAcademySettings()">Save Admission Note</button></div>
  </div>
  <div class="card">
    <h3>Notes to Students</h3>
    <div class="csv-drop" style="margin-bottom:14px;">These messages show as a read-only notice on the matching student page — students can see them but can't edit them. Leave any field blank to hide that notice.</div>
    <label>Attendance Page Note</label>
    <textarea id="set_attendanceNote" placeholder="e.g. Attendance below 75% may affect your eligibility for the final exam." style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;font-family:inherit;height:70px;resize:vertical;margin-bottom:14px;">${s.attendanceNote||''}</textarea>
    <label>Assignments Page Note</label>
    <textarea id="set_assignmentsNote" placeholder="e.g. Late submissions will not be accepted after the due date." style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;font-family:inherit;height:70px;resize:vertical;margin-bottom:14px;">${s.assignmentsNote||''}</textarea>
    <label>Live Class Page Note</label>
    <textarea id="set_liveClassNote" placeholder="e.g. Live classes start sharp at 5:00 PM — please join 5 minutes early." style="width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:10px;font-size:14px;font-family:inherit;height:70px;resize:vertical;">${s.liveClassNote||''}</textarea>
    <div class="actions-row" style="margin-top:14px;"><button class="btn gold" onclick="saveAcademySettings()">Save Notes to Students</button></div>
  </div>
  <div class="card">
    <h3>Bank Details for New Admissions</h3>
    <div class="csv-drop" style="margin-bottom:14px;">These details show to applicants on the "Apply for Admission" form, telling them exactly where to deposit their fee before uploading a receipt. Leave any field blank to hide it.</div>
    <div class="row2">
      <div><label>Bank Name</label><input id="set_bankName" value="${s.bankName||''}" placeholder="e.g. HBL"></div>
      <div><label>Branch</label><input id="set_bankBranch" value="${s.bankBranch||''}" placeholder="e.g. Larkana Branch"></div>
    </div>
    <div class="row2">
      <div><label>Account Title</label><input id="set_accountTitle" value="${s.accountTitle||''}" placeholder="e.g. Inspired Model School &amp; Girl College Larkana"></div>
      <div><label>Account Number / IBAN</label><input id="set_accountNumber" value="${s.accountNumber||''}" placeholder="e.g. PK00HABB0000000000000000"></div>
    </div>
    <label>Easypaisa Number (optional)</label><input id="set_easypaisaNumber" value="${s.easypaisaNumber||''}" placeholder="e.g. 0300-1234567">
    <div class="actions-row" style="margin-top:14px;"><button class="btn gold" onclick="saveAcademySettings()">Save Bank Details</button></div>
  </div>
  <div class="card"><h3>Change Password</h3>
    ${changePasswordFormHtml('admin')}
  </div>`;
}
async function saveAcademySettings(){
  const payload = {
    bank_name: document.getElementById('set_bankName').value.trim(),
    bank_branch: document.getElementById('set_bankBranch').value.trim(),
    account_title: document.getElementById('set_accountTitle').value.trim(),
    account_number: document.getElementById('set_accountNumber').value.trim(),
    easypaisa_number: document.getElementById('set_easypaisaNumber').value.trim(),
    admission_note: document.getElementById('set_admissionNote').value.trim(),
    attendance_note: document.getElementById('set_attendanceNote').value.trim(),
    assignments_note: document.getElementById('set_assignmentsNote').value.trim(),
    live_class_note: document.getElementById('set_liveClassNote').value.trim()
  };
  const { error } = await sb.from('academy_settings').update(payload).eq('id', 1);
  if(error){ console.error(error); alert('Could not save: ' + error.message); return; }
  alert('Saved.');
}


function openModal(id){
  document.getElementById(id).classList.add('show');
  if(id === 'admissionApplyOverlay') updateAdmInstallmentVisibility();
}
function closeModal(id){ document.getElementById(id).classList.remove('show'); }

function autoFillRollForNewStudent(){
  const original = document.getElementById('editRollOriginal').value;
  if(original) return; // don't touch roll number while editing an existing student
  const cls = document.getElementById('f_class').value;
  const { prefix, next } = nextRollForClass(cls);
  document.getElementById('f_roll').value = `${prefix}${next}`;
}
function openAddStudent(){
  document.getElementById('studentModalTitle').textContent='Add Student';
  ['f_roll','f_pass','f_name','f_father','f_phone','f_cardid','f_feeamount'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('editRollOriginal').value='';
  document.getElementById('f_class').value='9th Girls';
  autoFillRollForNewStudent();
  openModal('studentModalOverlay');
}
function editStudent(roll){
  const s = getStudent(roll);
  document.getElementById('studentModalTitle').textContent='Edit Student';
  document.getElementById('editRollOriginal').value = roll;
  document.getElementById('f_roll').value = s.roll;
  document.getElementById('f_pass').value = s.password;
  document.getElementById('f_name').value = s.name;
  document.getElementById('f_class').value = s.class;
  document.getElementById('f_father').value = s.father;
  document.getElementById('f_phone').value = s.phone;
  document.getElementById('f_cardid').value = s.cardId || '';
  document.getElementById('f_feeamount').value = s.feeAmount;
  openModal('studentModalOverlay');
}
function captureCardId(){
  const input = document.getElementById('f_cardid');
  const hint = document.getElementById('cardCaptureHint');
  input.value = '';
  input.focus();
  input.placeholder = 'Waiting for card tap…';
  if(hint){ hint.textContent = 'Ready — tap the card on the reader now.'; hint.style.color = '#1d7a4d'; }
  // The reader types the code + Enter into the focused field. On Enter, finalize.
  const onKey = (e) => {
    if(e.key === 'Enter'){
      e.preventDefault();
      input.value = input.value.trim();
      input.placeholder = 'e.g. 020034C8B2 — tap card to capture';
      if(hint){ hint.textContent = input.value ? ('Captured: ' + input.value) : 'No code captured — try again.'; hint.style.color = 'var(--ink-soft)'; }
      input.removeEventListener('keydown', onKey);
    }
  };
  input.addEventListener('keydown', onKey);
}
function saveStudent(){
  const original = document.getElementById('editRollOriginal').value;
  const roll = document.getElementById('f_roll').value.trim();
  const pass = document.getElementById('f_pass').value.trim() || roll;
  const name = document.getElementById('f_name').value.trim();
  if(!roll || !name){ alert('Roll number and name are required.'); return; }
  const data = {
    password:pass, name,
    class: document.getElementById('f_class').value,
    father: document.getElementById('f_father').value.trim(),
    phone: document.getElementById('f_phone').value.trim(),
    card_id: document.getElementById('f_cardid').value.trim(),
    fee_amount: Number(document.getElementById('f_feeamount').value)||0
  };
  const saveBtn = document.querySelector('#studentModalOverlay .btn.gold');
  saveBtn.disabled = true;
  (async () => {
    try{
      if(original){
        if(original === roll){
          const { error } = await sb.from('students').update(data).eq('roll', original);
          if(error) throw error;
        } else {
          const { data: oldRow } = await sb.from('students').select('*').eq('roll', original).maybeSingle();
          const { data: existing } = await sb.from('students').select('roll').eq('roll', roll).maybeSingle();
          if(existing){ alert('A student with this roll number already exists.'); saveBtn.disabled=false; return; }
          const { error: insErr } = await sb.from('students').insert({
            roll, ...data,
            fees: oldRow ? oldRow.fees : [], attendance: oldRow ? oldRow.attendance : [], results: oldRow ? oldRow.results : []
          });
          if(insErr) throw insErr;
          const { error: delErr } = await sb.from('students').delete().eq('roll', original);
          if(delErr) throw delErr;
        }
      } else {
        const { data: existing } = await sb.from('students').select('roll').eq('roll', roll).maybeSingle();
        if(existing){ alert('A student with this roll number already exists.'); saveBtn.disabled=false; return; }
        const { error } = await sb.from('students').insert({ roll, ...data, fees:[], attendance:[], results:[] });
        if(error) throw error;
      }
      closeModal('studentModalOverlay');
    } catch(err){ console.error(err); alert('Could not save: ' + err.message); }
    finally{ saveBtn.disabled = false; }
  })();
}
function deleteStudent(roll){
  if(!confirm(`Delete student ${roll}? This cannot be undone.`)) return;
  sb.from('students').delete().eq('roll', roll).then(({error})=>{
    if(error){ console.error(error); alert('Could not delete: ' + error.message); }
  });
}

function setFeeStatusBtn(val){
  document.getElementById('fee_status').value = val;
  document.getElementById('feeStatusPaid').style.opacity = val==='Paid' ? '1' : '0.4';
  document.getElementById('feeStatusDue').style.opacity  = val==='Due'  ? '1' : '0.4';
}
function openFeeModal(roll, month){
  const s = getStudent(roll);
  document.getElementById('fee_roll').value = roll;
  const existing = month ? (s.fees||[]).find(f=>f.month===month) : null;
  document.getElementById('fee_month').value = month || '';
  const amt = existing ? existing.amount : (s.feeAmount || '');
  document.getElementById('fee_amount').value = amt;
  const status = existing ? existing.status : 'Due';
  document.getElementById('fee_status').value = status;
  document.getElementById('fee_date').value = existing ? (existing.date||'') : new Date().toISOString().slice(0,10);
  // Show student info
  const info = document.getElementById('feeStudentInfo');
  if(info) info.innerHTML = `<b>${s.name}</b> &nbsp;|&nbsp; Roll: ${s.roll} &nbsp;|&nbsp; Class: ${s.class} &nbsp;|&nbsp; Fee/mo: Rs.${s.feeAmount||0}`;
  // Highlight status buttons
  setFeeStatusBtn(status);
  // Update title
  const title = document.getElementById('feeModalTitle');
  if(title) title.textContent = month ? '💰 Fee Entry — ' + month : '💰 Add Fee Entry';
  openModal('feeModalOverlay');
}
function saveFeeEntry(){
  const roll = document.getElementById('fee_roll').value;
  const month = document.getElementById('fee_month').value.trim();
  if(!month){ alert('Please enter a month.'); return; }
  const amount = Number(document.getElementById('fee_amount').value)||0;
  if(!amount){ alert('Please enter the amount.'); return; }
  const entry = {
    month, amount,
    status: document.getElementById('fee_status').value,
    date: document.getElementById('fee_date').value
  };
  const s = getStudent(roll);
  const current = s.fees || [];
  const idx = current.findIndex(f=>f.month===month);
  const updated = idx>-1 ? current.map((f,i)=>i===idx?entry:f) : [...current, entry];
  // Update local DB immediately
  s.fees = updated;
  closeModal('feeModalOverlay');
  renderPage();
  // Save to the server
  if(sb){
    sb.from('students').update({ fees: updated }).eq('roll', roll).then(({error})=>{
      if(error){ console.error(error); alert('Could not save to database: ' + error.message); }
    });
  }
}

function openAttModal(roll){
  document.getElementById('att_roll').value = roll;
  document.getElementById('att_date').value = new Date().toISOString().slice(0,10);
  document.getElementById('att_status').value='Present';
  openModal('attModalOverlay');
}
function saveAttendance(){
  const roll = document.getElementById('att_roll').value;
  const entry = { date:document.getElementById('att_date').value, status:document.getElementById('att_status').value };
  const current = getStudent(roll).attendance || [];
  sb.from('students').update({ attendance: [...current, entry] }).eq('roll', roll).then(({error})=>{
    if(error){ console.error(error); alert('Could not save: ' + error.message); return; }
    closeModal('attModalOverlay');
  });
}

function viewResultHistory(roll){
  const s = getStudent(roll);
  document.getElementById('resultHistoryTitle').textContent = `Result History — ${s.name} (${s.roll})`;
  const rows = (s.results||[]).map((r,i) => `
    <tr class="ledger-row">
      <td>${r.exam}</td><td>${r.subject}</td><td>${r.obtained}</td><td>${r.total}</td>
      <td><button class="btn small danger" onclick="deleteResultEntry('${s.roll}', ${i})">Delete</button></td>
    </tr>`).join('');
  document.getElementById('resultHistoryTbody').innerHTML = rows || `<tr><td colspan="5" class="empty-state">No result records for this student yet.</td></tr>`;
  openModal('resultHistoryModalOverlay');
}
function deleteResultEntry(roll, idx){
  const s = getStudent(roll);
  const entry = s.results[idx];
  if(!entry) return;
  if(!confirm(`Delete the "${entry.exam}" (${entry.subject}) result for ${s.name}? This cannot be undone.`)) return;
  const updated = s.results.filter((r,i) => i!==idx);
  sb.from('students').update({ results: updated }).eq('roll', roll).then(async ({error})=>{
    if(error){ console.error(error); alert('Could not delete: ' + error.message); return; }
    await refreshStudentsFromServer();
    viewResultHistory(roll);
  });
}
async function deleteExam(){
  const exam = prompt('Delete which exam? Type the exam name exactly as it appears (e.g. "1st Monthly Test"). This removes it for every student who has it — leave subject blank to remove all subjects for this exam, or you\'ll be asked next.');
  if(!exam || !exam.trim()) return;
  const examTrim = exam.trim();
  const subject = prompt('Optional: limit this to one subject only (e.g. "Physics"). Leave blank to delete this exam across all subjects.') || '';
  const subjectTrim = subject.trim();
  const matches = (r) => r.exam.trim().toLowerCase()===examTrim.toLowerCase() && (!subjectTrim || r.subject.trim().toLowerCase()===subjectTrim.toLowerCase());
  const affected = DB.students.filter(s => (s.results||[]).some(matches));
  if(!affected.length){ alert(`No students have a result matching "${examTrim}"${subjectTrim?(' / '+subjectTrim):''}.`); return; }
  if(!confirm(`This removes "${examTrim}"${subjectTrim?(' ('+subjectTrim+')'):' (all subjects)'} from ${affected.length} student(s). This cannot be undone. Continue?`)) return;
  try{
    for(const s of affected){
      const updated = s.results.filter(r => !matches(r));
      const { error } = await sb.from('students').update({ results: updated }).eq('roll', s.roll);
      if(error) throw error;
    }
    await refreshStudentsFromServer();
    alert(`Done. Removed "${examTrim}"${subjectTrim?(' ('+subjectTrim+')'):''} from ${affected.length} student(s).`);
  } catch(err){ console.error(err); alert('Something went wrong partway through: ' + err.message); }
}
/* Default subject sets — edit any row, or add your own */
const SUBJECTS_SENIOR = ['English','Urdu','Sindhi','Mathematics','Physics','Chemistry','Biology','Islamiyat','Pakistan Studies','Computer Science'];
const SUBJECTS_MIDDLE = ['English','Urdu','Sindhi','Mathematics','Science','Islamiyat','Social Studies','Computer Science'];
const SUBJECTS_JUNIOR = ['English','Urdu','Sindhi','Mathematics','Science','Islamiyat','General Knowledge','Drawing'];

function subjectsForClass(cls){
  const c = String(cls||'');
  if(/9|10|First Year|Matric/i.test(c)) return SUBJECTS_SENIOR;
  if(/[6-8]/.test(c)) return SUBJECTS_MIDDLE;
  return SUBJECTS_JUNIOR;
}

function resultRowHtml(subject, obtained, total){
  const esc = v => String(v==null?'':v).replace(/"/g,'&quot;');
  return '<div class="res-row">'
       + '<input class="res-subj" placeholder="Subject" value="'+esc(subject)+'">'
       + '<input class="res-obt" type="number" inputmode="numeric" placeholder="—" value="'+esc(obtained)+'">'
       + '<input class="res-tot" type="number" inputmode="numeric" value="'+esc(total)+'">'
       + '<button type="button" class="res-x" title="Remove this subject" onclick="removeResultRow(this)">✕</button>'
       + '</div>';
}

function addResultRow(subject){
  const total = document.getElementById('res_total_all').value || 100;
  const wrap = document.getElementById('res_rows');
  wrap.insertAdjacentHTML('beforeend', resultRowHtml(subject||'', '', total));
  if(!subject){
    const rows = wrap.querySelectorAll('.res-row');
    const last = rows[rows.length-1];
    if(last) last.querySelector('.res-subj').focus();
  }
}

function removeResultRow(btn){
  const row = btn.closest('.res-row');
  if(row) row.remove();
}

function applyTotalToAll(){
  const t = document.getElementById('res_total_all').value;
  document.querySelectorAll('#res_rows .res-tot').forEach(el => { el.value = t; });
}

function openResultModal(roll){
  const s = getStudent(roll);
  document.getElementById('res_roll').value = roll;
  document.getElementById('res_exam').value = '';
  document.getElementById('res_total_all').value = 100;
  document.getElementById('res_error').textContent = '';
  const info = document.getElementById('res_student_info');
  if(info && s) info.innerHTML = '<b>'+s.name+'</b> &nbsp;|&nbsp; '+s.roll+' &nbsp;|&nbsp; '+s.class;
  const wrap = document.getElementById('res_rows');
  wrap.innerHTML = subjectsForClass(s && s.class).map(sub => resultRowHtml(sub,'',100)).join('');
  openModal('resultModalOverlay');
}
function saveResult(){
  const err  = document.getElementById('res_error');
  const roll = document.getElementById('res_roll').value;
  const exam = document.getElementById('res_exam').value.trim();
  err.textContent = '';
  if(!exam){ err.textContent = 'Please enter the exam or term name.'; return; }

  const entries = [];
  const seen = new Set();
  let bad = '';
  document.querySelectorAll('#res_rows .res-row').forEach(row => {
    const subject = row.querySelector('.res-subj').value.trim();
    const obtRaw  = row.querySelector('.res-obt').value.trim();
    const totRaw  = row.querySelector('.res-tot').value.trim();
    if(!subject || obtRaw === '') return;            // blank row = skip
    const obtained = Number(obtRaw);
    const total    = Number(totRaw) || 100;
    if(isNaN(obtained)){ bad = bad || subject + ': marks must be a number'; return; }
    if(obtained > total){ bad = bad || subject + ': ' + obtained + ' is more than the total of ' + total; return; }
    if(obtained < 0){ bad = bad || subject + ': marks cannot be negative'; return; }
    const key = subject.toLowerCase();
    if(seen.has(key)){ bad = bad || subject + ' is listed twice'; return; }
    seen.add(key);
    entries.push({ exam, subject, obtained, total });
  });

  if(bad){ err.textContent = bad; return; }
  if(!entries.length){ err.textContent = 'Enter marks for at least one subject.'; return; }

  // replace any existing marks for the same exam + subject instead of duplicating
  const s = getStudent(roll);
  const current = s.results || [];
  const kept = current.filter(r => !entries.some(e =>
    String(r.exam).toLowerCase() === String(e.exam).toLowerCase() &&
    String(r.subject).toLowerCase() === String(e.subject).toLowerCase()));
  const replaced = current.length - kept.length;
  const updated = [...kept, ...entries];

  s.results = updated;                    // show it straight away
  closeModal('resultModalOverlay');
  if(typeof refreshResultsTable === 'function') refreshResultsTable();

  if(sb){
    sb.from('students').update({ results: updated }).eq('roll', roll).then(({error})=>{
      if(error){ console.error(error); alert('Could not save to the database: ' + error.message); return; }
      alert('Saved ' + entries.length + ' subject' + (entries.length>1?'s':'') +
            ' for ' + exam + (replaced ? ' (' + replaced + ' existing updated)' : '') + '.');
    });
  }
}

async function uploadWithProgress(path, file, onProgress, bucket, isPublicApplicant){
  bucket = bucket || 'materials';
  if(file && file.size > 25 * 1024 * 1024){
    throw new Error('That file is larger than 25 MB. Please choose a smaller one.');
  }
  // Ask the server for a one-shot upload link for this single file.
  const link = await apiCall(
    { action: isPublicApplicant ? 'apply_upload_url' : 'upload_url', bucket, path },
    isPublicApplicant ? { noExpiry:true } : undefined);
  if(link.error) throw new Error(link.error.message);
  const uploadTarget = (DATA_URL.charAt(0) === '/' && link.data.signedPath)
    ? DATA_URL + link.data.signedPath
    : link.data.signedUrl;
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('PUT', uploadTarget, true);
    xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
    xhr.upload.onprogress = (e) => {
      if(e.lengthComputable && onProgress) onProgress(Math.round((e.loaded/e.total)*100));
    };
    xhr.onload = () => {
      if(xhr.status >= 200 && xhr.status < 300) resolve(link.data.path || path);
      else reject(new Error('Upload failed (' + xhr.status + '): ' + xhr.responseText));
    };
    xhr.onerror = () => reject(new Error('Network error during upload. Check your internet connection.'));
    xhr.send(file);
  });
}
function saveMaterial(){
  const title = document.getElementById('mat_title').value.trim();
  const subject = document.getElementById('mat_subject').value.trim();
  const cls = document.getElementById('mat_class').value;
  const fileInput = document.getElementById('mat_file');
  if(!title){ alert('Please enter a title.'); return; }
  const saveBtn = document.querySelector('#materialModalOverlay .btn.gold');
  const progWrap = document.getElementById('mat_progress_wrap');
  const progBar = document.getElementById('mat_progress_bar');
  const progText = document.getElementById('mat_progress_text');
  saveBtn.disabled = true; saveBtn.textContent = 'Uploading...';
  const finish = async (fileURL, fileName) => {
    const { error } = await sb.from('materials').insert({
      title, subject, cls, file_url: fileURL||null, file_name: fileName||null,
      uploaded_date: new Date().toISOString().slice(0,10)
    });
    saveBtn.disabled=false; saveBtn.textContent='Upload';
    progWrap.classList.add('section-hidden'); progBar.style.width='0%'; progText.textContent='0%';
    if(error){ console.error(error); alert('Could not save: ' + error.message); return; }
    closeModal('materialModalOverlay');
    document.getElementById('mat_title').value=''; document.getElementById('mat_subject').value=''; fileInput.value='';
  };
  if(fileInput.files && fileInput.files[0]){
    const file = fileInput.files[0];
    const path = `${Date.now()}_${file.name}`;
    progWrap.classList.remove('section-hidden');
    uploadWithProgress(path, file, (pct) => {
      progBar.style.width = pct + '%';
      progText.textContent = pct + '% uploaded' + (pct===100 ? ' — finishing up...' : '');
    }).then((storedMatPath) => {
      const fileURL = `${DATA_URL}/storage/v1/object/public/materials/${storedMatPath || path}`;
      finish(fileURL, file.name);
    }).catch(err => {
      console.error(err);
      alert('Could not upload the file: ' + err.message);
      saveBtn.disabled=false; saveBtn.textContent='Upload';
      progWrap.classList.add('section-hidden'); progBar.style.width='0%'; progText.textContent='0%';
    });
  } else {
    finish(null, null);
  }
}
function deleteMaterial(id){
  if(!confirm('Delete this study material?')) return;
  sb.from('materials').delete().eq('id', id).then(({error})=>{
    if(error){ console.error(error); alert('Could not delete: ' + error.message); }
  });
}

/* ================= EXPENSES ================= */
function openAddExpense(){
  document.getElementById('exp_date').value = new Date().toISOString().slice(0,10);
  document.getElementById('exp_category').value='';
  document.getElementById('exp_description').value='';
  document.getElementById('exp_amount').value='';
  openModal('expenseModalOverlay');
}
function saveExpense(){
  const date = document.getElementById('exp_date').value;
  const category = document.getElementById('exp_category').value.trim();
  const description = document.getElementById('exp_description').value.trim();
  const amount = Number(document.getElementById('exp_amount').value)||0;
  if(!category || !amount){ alert('Please enter a category and amount.'); return; }
  sb.from('expenses').insert({ date, category, description, amount }).then(({error})=>{
    if(error){ console.error(error); alert('Could not save: ' + error.message); return; }
    closeModal('expenseModalOverlay');
  });
}
function deleteExpense(id){
  if(!confirm('Delete this expense record?')) return;
  sb.from('expenses').delete().eq('id', id).then(({error})=>{
    if(error){ console.error(error); alert('Could not delete: ' + error.message); }
  });
}
async function extractPdfLines(arrayBuffer){
  const lib = await getPdfLib();
  const doc = await lib.getDocument({data: arrayBuffer}).promise;
  const lines = [];
  for(let p=1; p<=doc.numPages; p++){
    const page = await doc.getPage(p);
    const content = await page.getTextContent();
    const byY = {};
    content.items.forEach(item => {
      const y = Math.round(item.transform[5]);
      if(!byY[y]) byY[y] = [];
      byY[y].push({ x:item.transform[4], str:item.str });
    });
    const ys = Object.keys(byY).map(Number).sort((a,b)=>b-a);
    ys.forEach(y => {
      const line = byY[y].sort((a,b)=>a.x-b.x).map(i=>i.str).join(' ').replace(/\s+/g,' ').trim();
      if(line) lines.push(line);
    });
  }
  return lines;
}
function parseResultPdfLines(lines){
  const rows = [];
  const rowPattern = /^(\d+)\s+([A-Za-z][A-Za-z.\s']*?)\s+(\d{1,3})\s+(\d{1,3})\s+(\d{1,2})\s+(\d{1,3})(?:\s+\d+(?:st|nd|rd|th))?$/i;
  for(const line of lines){
    const m = line.match(rowPattern);
    if(!m) continue;
    const [, sno, name, sheet1, sheet2, grace, total] = m;
    rows.push({ name: name.trim(), obtained: Number(total) });
  }
  return rows;
}
async function importNameTotalResults(parsed, examName, subject, totalMarks){
  let added=0, noMatch=0, ambiguous=0;
  const ambiguousNames = [], noMatchNames = [];
  try{
    for(const r of parsed){
      const matches = DB.students.filter(s => s.name.trim().toLowerCase() === r.name.toLowerCase());
      if(matches.length === 0){ noMatch++; noMatchNames.push(r.name); continue; }
      if(matches.length > 1){ ambiguous++; ambiguousNames.push(r.name); continue; }
      const student = matches[0];
      const updated = [...(student.results||[]), { exam:examName, subject, obtained:r.obtained, total:totalMarks }];
      const { error } = await sb.from('students').update({ results: updated }).eq('roll', student.roll);
      if(error) throw error;
      added++;
    }
    let msg = `Import complete: ${added} result(s) added.`;
    if(noMatch) msg += `\n\n${noMatch} name(s) didn't match any student: ${noMatchNames.join(', ')}`;
    if(ambiguous) msg += `\n\n${ambiguous} name(s) matched more than one student (skipped — add manually): ${ambiguousNames.join(', ')}`;
    alert(msg);
  } catch(err){ console.error(err); alert('Could not save some results: ' + err.message); }
}
async function handleResultsPdfUpload(evt){
  const file = evt.target.files[0];
  if(!file) return;
  const examName = document.getElementById('pdfExamName').value.trim() || 'Imported Exam';
  const subject = document.getElementById('pdfSubject').value.trim() || 'Combined';
  const totalMarks = Number(document.getElementById('pdfTotalMarks').value) || 200;
  const reader = new FileReader();
  reader.onload = async e => {
    let lines;
    try{ lines = await extractPdfLines(e.target.result); }
    catch(err){ console.error(err); alert('Could not read this PDF file.'); evt.target.value=''; return; }
    const parsed = parseResultPdfLines(lines);
    if(!parsed.length){ alert('Could not find any result rows in this PDF. Make sure it lists S.No, Name, and marks per row.'); evt.target.value=''; return; }
    await importNameTotalResults(parsed, examName, subject, totalMarks);
    evt.target.value='';
  };
  reader.readAsArrayBuffer(file);
}

async function processResultRows(rawRows){
  const byRoll = {}; // roll -> array of new result entries
  let skipped = 0, notFound = 0, ambiguous = 0;
  const notFoundNames = [], ambiguousNames = [];
  for(const raw of rawRows){
    const row = {};
    Object.keys(raw).forEach(k => row[k.trim().toLowerCase()] = String(raw[k]).trim());
    const name = row.name;
    const roll = row.roll;
    const exam = row.exam;
    const subject = row.subject;
    const obtained = Number(String(row.obtained||'').replace(/[^0-9.]/g,''));
    const total = Number(String(row.total||'').replace(/[^0-9.]/g,'')) || 100;
    if(!name || !exam || !subject){ skipped++; continue; }

    let student = null;
    if(roll){
      // If a roll number is provided, use it as the most precise match.
      student = DB.students.find(s=>s.roll.toLowerCase()===roll.toLowerCase());
    }
    if(!student){
      // Fall back to matching by name (case-insensitive).
      const matches = DB.students.filter(s=>s.name.trim().toLowerCase()===name.toLowerCase());
      if(matches.length === 0){ notFound++; notFoundNames.push(name); continue; }
      if(matches.length > 1){ ambiguous++; ambiguousNames.push(name); continue; }
      student = matches[0];
    }

    if(!byRoll[student.roll]) byRoll[student.roll] = [];
    byRoll[student.roll].push({ exam, subject, obtained, total });
  }

  const rollsToUpdate = Object.keys(byRoll);
  if(!rollsToUpdate.length){
    let msg = `Nothing to import. ${skipped} row(s) missing data.`;
    if(notFound) msg += `\n\n${notFound} name(s) didn't match any student: ${notFoundNames.join(', ')}`;
    if(ambiguous) msg += `\n\n${ambiguous} name(s) matched more than one student (skipped — add manually): ${ambiguousNames.join(', ')}`;
    alert(msg);
    return;
  }
  try{
    for(const roll of rollsToUpdate){
      const student = DB.students.find(s=>s.roll===roll);
      const updated = [...(student.results||[]), ...byRoll[roll]];
      const { error } = await sb.from('students').update({ results: updated }).eq('roll', roll);
      if(error) throw error;
    }
    const totalAdded = rollsToUpdate.reduce((sum,r)=>sum+byRoll[r].length,0);
    let msg = `Import complete: ${totalAdded} result(s) added across ${rollsToUpdate.length} student(s). ${skipped} row(s) skipped (missing data).`;
    if(notFound) msg += `\n\n${notFound} name(s) didn't match any student: ${notFoundNames.join(', ')}`;
    if(ambiguous) msg += `\n\n${ambiguous} name(s) matched more than one student (skipped — add manually): ${ambiguousNames.join(', ')}`;
    alert(msg);
  } catch(err){ console.error(err); alert('Could not save some results: ' + err.message); }
}

function wordTableToRows(html){
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const table = doc.querySelector('table');
  if(!table) return null;
  const trs = Array.from(table.querySelectorAll('tr'));
  if(trs.length < 2) return null;
  const headers = Array.from(trs[0].querySelectorAll('th,td')).map(td => td.textContent.trim().toLowerCase());
  const rows = [];
  for(let i=1;i<trs.length;i++){
    const cells = Array.from(trs[i].querySelectorAll('th,td')).map(td => td.textContent.trim());
    if(!cells.some(c=>c)) continue;
    const obj = {};
    headers.forEach((h,idx) => obj[h] = cells[idx] ?? '');
    rows.push(obj);
  }
  return rows;
}

function parseRawRegisterSheet(sheet){
  const gridRows = XLSX.utils.sheet_to_json(sheet, {header:1, defval:'', raw:false});
  let nameCol=-1, totalCol=-1, headerIdx=-1;
  for(let i=0;i<gridRows.length;i++){
    const row = gridRows[i];
    const nc = row.findIndex(c=>String(c).trim().toLowerCase()==='name');
    if(nc>-1){
      nameCol = nc; headerIdx = i;
      const tc = row.findIndex(c=>String(c).trim().toLowerCase()==='total');
      totalCol = tc>-1 ? tc : nc+1;
      break;
    }
  }
  if(nameCol===-1) return null;
  const results = [];
  for(let i=headerIdx+1;i<gridRows.length;i++){
    const row = gridRows[i];
    const name = String(row[nameCol]||'').trim();
    if(!name) continue;
    if(/total|sub|gross|share/i.test(name)) continue;
    const totalRaw = row[totalCol];
    const obtained = Number(String(totalRaw).replace(/[^0-9.]/g,''));
    results.push({ name, obtained });
  }
  return results;
}
function handleResultsFileUpload(evt){
  const file = evt.target.files[0];
  if(!file) return;
  const name = file.name.toLowerCase();
  const reader = new FileReader();

  if(name.endsWith('.doc') && !name.endsWith('.docx')){
    alert('This is an older .doc file, which can\'t be read directly. Please open it in Word (or Google Docs), then use "Save As" / "Download" and choose the .docx format instead — then upload that file.');
    evt.target.value='';
    return;
  }

  if(name.endsWith('.docx')){
    reader.onload = async e => {
      try{
        const result = await mammoth.convertToHtml({ arrayBuffer: e.target.result });
        const rows = wordTableToRows(result.value);
        if(!rows){ alert('Could not find a table in this Word document. Make sure your results are in a table with a header row.'); evt.target.value=''; return; }
        const hasCleanFormat = rows.some(r => 'exam' in r);
        if(hasCleanFormat){
          await processResultRows(rows);
        } else {
          const examName = document.getElementById('excelExamName').value.trim() || 'Imported Exam';
          const subject = document.getElementById('excelSubject').value.trim() || 'Combined';
          const totalMarks = Number(document.getElementById('excelTotalMarks').value) || 100;
          const totalKey = Object.keys(rows[0]||{}).find(k => k==='total') || 'total';
          const nameKey = Object.keys(rows[0]||{}).find(k => k==='name') || 'name';
          const parsed = rows
            .filter(r => String(r[nameKey]||'').trim() && !/total|sub|gross|share/i.test(String(r[nameKey])))
            .map(r => ({ name: String(r[nameKey]).trim(), obtained: Number(String(r[totalKey]||'').replace(/[^0-9.]/g,'')) }));
          if(!parsed.length){ alert('Could not find a "Name" column with a "Total" (or similar) marks column in this table.'); evt.target.value=''; return; }
          await importNameTotalResults(parsed, examName, subject, totalMarks);
        }
      } catch(err){ console.error(err); alert('Could not read Word file: ' + err.message); }
      evt.target.value='';
    };
    reader.readAsArrayBuffer(file);
  } else {
    reader.onload = async e => {
      let wb;
      try{ wb = XLSX.read(e.target.result, {type:'array'}); }
      catch(err){ alert('Could not read Excel file. Please check the format.'); return; }
      const firstSheetName = wb.SheetNames.find(n => {
        const r = XLSX.utils.sheet_to_json(wb.Sheets[n], {header:1, defval:''});
        return r.some(row => row.some(c => String(c).trim().length));
      }) || wb.SheetNames[0];
      const objRows = XLSX.utils.sheet_to_json(wb.Sheets[firstSheetName], {defval:'', raw:false});
      if(!objRows.length){ alert('Excel file appears empty.'); evt.target.value=''; return; }
      const hasCleanFormat = objRows.length && Object.keys(objRows[0]).some(k=>k.trim().toLowerCase()==='exam');

      if(hasCleanFormat){
        await processResultRows(objRows);
      } else {
        const examName = document.getElementById('excelExamName').value.trim() || 'Imported Exam';
        const subject = document.getElementById('excelSubject').value.trim() || 'Combined';
        const totalMarks = Number(document.getElementById('excelTotalMarks').value) || 100;
        let allParsed = [];
        for(const sheetName of wb.SheetNames){
          const parsed = parseRawRegisterSheet(wb.Sheets[sheetName]);
          if(parsed) allParsed = allParsed.concat(parsed);
        }
        if(!allParsed.length){ alert('Could not find a "Name" column with a "Total" (or similar) marks column in this file. Make sure it has a header row with at least Name and Total.'); evt.target.value=''; return; }
        await importNameTotalResults(allParsed, examName, subject, totalMarks);
      }
      evt.target.value='';
    };
    reader.readAsArrayBuffer(file);
  }
}

function handleExpenseExcelUpload(evt){
  const file = evt.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = async e => {
    let wb;
    try{ wb = XLSX.read(e.target.result, {type:'array'}); }
    catch(err){ alert('Could not read Excel file. Please check the format.'); return; }
    const sheetName = wb.SheetNames.find(n => {
      const r = XLSX.utils.sheet_to_json(wb.Sheets[n], {header:1, defval:''});
      return r.some(row => row.some(c => String(c).trim().length));
    }) || wb.SheetNames[0];
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], {defval:'', raw:false});
    if(!rows.length){ alert('Excel file appears empty.'); return; }
    const toInsert = [];
    let skipped=0;
    for(const raw of rows){
      const row = {};
      Object.keys(raw).forEach(k => row[k.trim().toLowerCase()] = String(raw[k]).trim());
      const amount = Number(String(row.amount||'').replace(/[^0-9.]/g,''));
      if(!amount){ skipped++; continue; }
      let date = row.date || '';
      if(date && !isNaN(Date.parse(date)) && !/^\d{4}-\d{2}-\d{2}$/.test(date)){
        const d = new Date(date); date = d.toISOString().slice(0,10);
      }
      toInsert.push({ date, category: row.category || 'Uncategorized', description: row.description || '', amount });
    }
    try{
      for(let i=0;i<toInsert.length;i+=200){
        const chunk = toInsert.slice(i, i+200);
        const { error } = await sb.from('expenses').insert(chunk);
        if(error) throw error;
      }
      alert(`Import complete: ${toInsert.length} expense(s) added, ${skipped} skipped (missing amount).`);
    } catch(err){ console.error(err); alert('Could not save some records: ' + err.message); }
    evt.target.value='';
  };
  reader.readAsArrayBuffer(file);
}

/* ================= EXCEL IMPORT ================= */
const CLASS_CODE = {
  'Play Group':'PG','Nursery':'NUR','Prep':'PREP',
  'Class 1':'C1','Class 2':'C2','Class 3':'C3','Class 4':'C4',
  'Class 5':'C5','Class 6':'C6','Class 7':'C7','Class 8':'C8',
  'Class 9':'C9','Class 10':'C10','First Year':'F1'
};
function nextRollForClass(cls){
  const prefix = 'IMS-';
  let max = 1000;
  DB.students.forEach(s=>{
    if(s.roll.startsWith(prefix)){
      const n = parseInt(s.roll.slice(prefix.length),10);
      if(!isNaN(n) && n>max) max = n;
    }
  });
  return {prefix, next:max+1};
}
function handleCsvUpload(evt){
  const file = evt.target.files[0];
  if(!file) return;
  const importClass = document.getElementById('importClass').value;
  const importMonth = document.getElementById('importMonth').value.trim() || 'Unspecified';
  const reader = new FileReader();
  reader.onload = async e => {
    let wb;
    try{ wb = XLSX.read(e.target.result, {type:'array'}); }
    catch(err){ alert('Could not read Excel file. Please check the format.'); return; }
    const sheetName = wb.SheetNames.find(n => {
      const s = wb.Sheets[n];
      const r = XLSX.utils.sheet_to_json(s, {header:1, defval:''});
      return r.some(row => row.some(c => String(c).trim().length));
    }) || wb.SheetNames[0];
    const sheet = wb.Sheets[sheetName];
    const objRows = XLSX.utils.sheet_to_json(sheet, {defval:'', raw:false});
    const hasRollCol = objRows.length && Object.keys(objRows[0]).some(k=>k.trim().toLowerCase()==='roll');

    const toInsert = [];
    let skipped=0;

    if(hasRollCol){
      for(const raw of objRows){
        const row = {};
        Object.keys(raw).forEach(k => row[k.trim().toLowerCase()] = String(raw[k]).trim());
        if(!row.roll || !row.name){ skipped++; continue; }
        if(DB.students.find(s=>s.roll.toLowerCase()===row.roll.toLowerCase())){ skipped++; continue; }
        toInsert.push({
          roll:row.roll, name:row.name, class:row.class||importClass,
          father:row.father||'', phone:row.phone||'',
          password:row.password || row.roll,
          fee_amount:Number(row.feeamount)||0,
          fees:[], attendance:[], results:[]
        });
      }
    } else {
      const gridRows = XLSX.utils.sheet_to_json(sheet, {header:1, defval:'', raw:false});
      let nameCol=-1, headerIdx=-1;
      for(let i=0;i<gridRows.length;i++){
        const idx = gridRows[i].findIndex(c=>String(c).trim().toLowerCase()==='name');
        if(idx>-1){ nameCol=idx; headerIdx=i; break; }
      }
      if(nameCol===-1){ alert('Could not find a "Name" column in this sheet. Please check the file format.'); return; }
      const feeCol = nameCol+1;
      let {prefix, next} = nextRollForClass(importClass);
      for(let i=headerIdx+1;i<gridRows.length;i++){
        const row = gridRows[i];
        const name = String(row[nameCol]||'').trim();
        if(!name) continue;
        if(/total|sub|gross|share/i.test(name)) break;
        const feeRaw = row[feeCol];
        const feeNum = Number(String(feeRaw).replace(/[^0-9.]/g,''));
        const roll = `${prefix}${next}`; next++;
        toInsert.push({
          roll, password:roll, name, class:importClass,
          father:'', phone:'',
          fee_amount: feeNum>0 ? feeNum : 4500,
          fees: feeNum>0
            ? [{month:importMonth, amount:feeNum, status:'Paid', date:''}]
            : [{month:importMonth, amount:4500, status:'Due', date:''}],
          attendance:[], results:[]
        });
      }
    }

    try{
      for(let i=0;i<toInsert.length;i+=200){
        const chunk = toInsert.slice(i, i+200);
        const { error } = await sb.from('students').insert(chunk);
        if(error) throw error;
      }
      alert(`Import complete: ${toInsert.length} student(s) added, ${skipped} skipped (duplicate or missing data).`);
    } catch(err){ console.error(err); alert('Could not save some records: ' + err.message); }
    evt.target.value='';
  };
  reader.readAsArrayBuffer(file);
}



/* ================= SEED STUDENTS TO the server ================= */
async function seedStudents(){
  if(!sb){ alert('the server is not connected. Please add your URL and anon key first.'); return; }
  
  const confirmed = confirm(`Upload all ${DB.students.length} students to the server database?\n\nThis will add any students not already in the database.\nExisting students (same roll number) will be skipped.`);
  if(!confirmed) return;

  const btn = event.target;
  btn.disabled = true;
  btn.textContent = '⏳ Uploading...';

  try {
    let added = 0, skipped = 0, failed = 0;
    const CHUNK = 50;
    
    for(let i = 0; i < DB.students.length; i += CHUNK){
      const chunk = DB.students.slice(i, i + CHUNK).map(s => ({
        roll: s.roll,
        name: s.name,
        class: s.class,
        father: s.father || '',
        phone: s.phone || '',
        password: s.password || s.roll,
        fee_amount: s.feeAmount || 0,
        fees: s.fees || [],
        attendance: s.attendance || [],
        results: s.results || []
      }));

      const { data, error } = await sb.from('students').upsert(chunk, { onConflict: 'roll', ignoreDuplicates: true });
      
      if(error){
        console.error('Chunk error:', error);
        failed += chunk.length;
      } else {
        added += chunk.length;
      }

      // Update button progress
      btn.textContent = `⏳ Uploading... ${Math.min(i + CHUNK, DB.students.length)}/${DB.students.length}`;
    }

    btn.textContent = '✅ Upload Complete!';
    btn.style.background = 'linear-gradient(135deg,#10B981,#34D399)';
    alert(`✅ Upload Complete!\n\n${added} students uploaded to the server.${failed > 0 ? '\n⚠️ ' + failed + ' failed — check console.' : ''}\n\nRefresh the page to load data from database.`);
    
  } catch(err){
    console.error(err);
    btn.textContent = '❌ Upload Failed';
    btn.disabled = false;
    alert('Upload failed: ' + err.message);
  }
}


/* ===================== TEACHER GATE SCANNER ===================== */

function teacherToday(){ return new Date().toISOString().slice(0,10); }
function teacherNowTime(){ return new Date().toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',second:'2-digit'}); }
function teacherNowDateTime(){ return new Date().toISOString(); }

let teacherGateInput = '';
let teacherGateTimer = null;
let teacherViewDate = teacherToday();   // which day the log below shows
let teacherViewMode = 'day';            // 'day' | 'range'
let teacherRangeFrom = '';
let teacherRangeTo = '';

function renderTeacherGate(){
  const today = teacherToday();
  const dateLabel = new Date().toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});
  const teachers = DB.teachers || [];
  const totalTeachers = teachers.length;

  // Live counters always reflect TODAY (the scanner is a live tool)
  let presentToday = 0, checkedOutToday = 0;
  teachers.forEach(t => {
    const todayRec = (t.attendance||[]).find(a => a.date === today);
    if(todayRec && todayRec.timeIn) presentToday++;
    if(todayRec && todayRec.timeOut) checkedOutToday++;
  });

  // ---- the log below can show any past day, or a date range ----
  const inRange = d => teacherViewMode === 'range'
    ? (!teacherRangeFrom || d >= teacherRangeFrom) && (!teacherRangeTo || d <= teacherRangeTo)
    : d === teacherViewDate;

  const log = [];
  teachers.forEach(t => {
    (t.attendance||[]).forEach(rec => {
      if(rec && rec.date && inRange(rec.date)){
        log.push({ name:t.name, subject:t.subject||'', ...rec });
      }
    });
  });
  log.sort((a,b) => a.date === b.date
    ? (a.timeIn||'').localeCompare(b.timeIn||'')
    : b.date.localeCompare(a.date));

  const showDateCol = teacherViewMode === 'range';
  const nCols = showDateCol ? 7 : 6;

  const emptyMsg = teacherViewMode === 'range'
    ? 'No teacher attendance recorded in this date range'
    : 'No teacher attendance recorded on ' + prettyDate(teacherViewDate);

  const logRows = log.length ? log.map(r => `
    <tr class="ledger-row">
      ${showDateCol ? `<td data-label="Date">${prettyDate(r.date)}</td>` : ''}
      <td data-label="Name"><b>${r.name}</b></td>
      <td data-label="Subject">${r.subject}</td>
      <td data-label="Time In"><span style="color:var(--ok-ink); font-weight:600;">🟢 ${r.timeIn||'–'}</span></td>
      <td data-label="Time Out"><span style="color:${r.timeOut?'var(--ok-ink)':'var(--due-ink)'}; font-weight:600;">${r.timeOut ? '🔴 '+r.timeOut : '–'}</span></td>
      <td data-label="Duration">${r.timeIn && r.timeOut ? calcDuration(r.timeIn, r.timeOut) : r.timeIn ? '⏳ Still in' : '–'}</td>
      <td data-label="Status">
        <span class="badge ${r.timeOut?'ok':'due'}">${r.timeOut?'Checked Out':'Checked In'}</span>
      </td>
    </tr>`).join('') : `<tr><td colspan="${nCols}" style="text-align:center; color:var(--ink-soft); padding:30px;">${emptyMsg}</td></tr>`;

  // summary for whatever span is being viewed
  const daysShown = new Set(log.map(r=>r.date)).size;
  const totalMins = log.reduce((s,r)=> s + (r.timeIn && r.timeOut ? durationMinutes(r.timeIn, r.timeOut) : 0), 0);
  const spanLabel = teacherViewMode === 'range'
    ? `${log.length} record${log.length===1?'':'s'} across ${daysShown} day${daysShown===1?'':'s'} • total ${fmtMins(totalMins)}`
    : `${log.length} teacher${log.length===1?'':'s'} • total ${fmtMins(totalMins)}`;

  return `
  <div class="card" style="margin-bottom:20px;">
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:16px;">
      <div>
        <h3 style="margin:0 0 4px;">🏫 Teacher Attendance Scanner</h3>
        <p style="color:var(--ink-soft); font-size:13px; margin:0;">${dateLabel}</p>
      </div>
      <div style="display:flex; gap:10px;">
        <div class="stat ok" style="padding:10px 18px; text-align:center;">
          <div class="label">Checked In</div>
          <div class="value">${presentToday}</div>
        </div>
        <div class="stat due" style="padding:10px 18px; text-align:center;">
          <div class="label">Checked Out</div>
          <div class="value">${checkedOutToday}</div>
        </div>
        <div class="stat" style="padding:10px 18px; text-align:center;">
          <div class="label">Total</div>
          <div class="value">${totalTeachers}</div>
        </div>
      </div>
    </div>

    <!-- Scanner input -->
    <div style="background:var(--bg); border:2px dashed var(--line); border-radius:14px; padding:24px; text-align:center; margin-bottom:20px;">
      <div style="font-size:32px; margin-bottom:8px;">📟</div>
      <p style="color:var(--ink-soft); font-size:14px; margin:0 0 12px;">Tap teacher's RFID card on the reader</p>
      <input id="teacherGateInput"
        style="position:absolute; opacity:0; width:1px; height:1px; pointer-events:none;"
        onkeydown="teacherGateKey(event)"
        autocomplete="off" />
      <div id="teacherGateStatus" style="min-height:80px; display:flex; align-items:center; justify-content:center;">
        <span style="color:var(--ink-soft); font-size:14px;">⏳ Waiting for card scan...</span>
      </div>
      <button class="btn" onclick="teacherGateStartFocus()" style="margin-top:8px; font-size:13px;">
        🎯 Click to Activate Scanner
      </button>
    </div>

    <!-- Manual entry -->
    <details style="margin-bottom:16px;">
      <summary style="cursor:pointer; color:var(--ink-soft); font-size:13px; padding:8px 0;">📝 Manual Entry (no RFID card)</summary>
      <div style="padding:12px 0; display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end;">
        <div style="flex:1; min-width:160px;">
          <label style="font-size:12px; color:var(--ink-soft);">Select Teacher</label>
          <select id="manualTeacherSel" class="form-input" style="margin-top:4px;">
            <option value="">— Select —</option>
            ${(DB.teachers||[]).map(t=>`<option value="${t.username}">${t.name}</option>`).join('')}
          </select>
        </div>
        <button class="btn gold" onclick="teacherManualCheckIn()">✅ Check In</button>
        <button class="btn" onclick="teacherManualCheckOut()">🔴 Check Out</button>
      </div>
    </details>
  </div>

  <!-- Attendance record -->
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:6px; flex-wrap:wrap; gap:8px;">
      <div>
        <h3 style="margin:0 0 2px;">📋 Attendance Record</h3>
        <p style="margin:0; font-size:12.5px; color:var(--ink-soft);">${spanLabel}</p>
      </div>
      <button class="btn" onclick="exportTeacherRecord()">⬇️ Export</button>
    </div>

    <!-- date controls -->
    <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center; padding:12px 0 14px; border-bottom:1px solid var(--line); margin-bottom:14px;">
      ${teacherViewMode === 'day' ? `
        <button class="btn small" onclick="teacherShiftDay(-1)">‹ Prev</button>
        <input type="date" value="${teacherViewDate}" max="${today}"
               onchange="teacherSetDate(this.value)"
               style="padding:7px 10px; border:1px solid var(--line); border-radius:8px; font-size:13.5px;">
        <button class="btn small" onclick="teacherShiftDay(1)" ${teacherViewDate >= today ? 'disabled' : ''}>Next ›</button>
        <button class="btn small" onclick="teacherSetDate('${today}')" ${teacherViewDate === today ? 'disabled' : ''}>Today</button>
        <span style="flex:1;"></span>
        <button class="btn small" onclick="teacherUseRange()">📅 Date range</button>
      ` : `
        <label style="font-size:12px; color:var(--ink-soft);">From</label>
        <input type="date" value="${teacherRangeFrom}" max="${today}" onchange="teacherSetRange('from', this.value)"
               style="padding:7px 10px; border:1px solid var(--line); border-radius:8px; font-size:13.5px;">
        <label style="font-size:12px; color:var(--ink-soft);">To</label>
        <input type="date" value="${teacherRangeTo}" max="${today}" onchange="teacherSetRange('to', this.value)"
               style="padding:7px 10px; border:1px solid var(--line); border-radius:8px; font-size:13.5px;">
        <span style="flex:1;"></span>
        <button class="btn small" onclick="teacherUseDay()">← Single day</button>
      `}
    </div>

    <div class="table-wrap">
      <table>
        <thead><tr>
          ${showDateCol ? '<th>Date</th>' : ''}
          <th>Name</th><th>Subject</th><th>Time In</th><th>Time Out</th><th>Duration</th><th>Status</th>
        </tr></thead>
        <tbody>${logRows}</tbody>
      </table>
    </div>
  </div>`;
}

function calcDuration(timeIn, timeOut){
  try {
    const today = teacherToday();
    const a = new Date(today + 'T' + convertTo24(timeIn));
    const b = new Date(today + 'T' + convertTo24(timeOut));
    const diff = Math.floor((b - a) / 60000);
    if(diff < 0) return '–';
    const h = Math.floor(diff/60);
    const m = diff % 60;
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  } catch(e){ return '–'; }
}

function convertTo24(timeStr){
  if(!timeStr) return '00:00:00';
  // Handle "02:30:15 PM" format
  const m = timeStr.match(/(\d+):(\d+):(\d+)\s*(AM|PM)/i);
  if(!m) return timeStr;
  let h = parseInt(m[1]);
  const min = m[2], sec = m[3], ampm = m[4].toUpperCase();
  if(ampm === 'PM' && h !== 12) h += 12;
  if(ampm === 'AM' && h === 12) h = 0;
  return `${String(h).padStart(2,'0')}:${min}:${sec}`;
}

function teacherGateStartFocus(){
  const el = document.getElementById('teacherGateInput');
  if(el) el.focus();
}

function teacherGateKey(e){
  clearTimeout(teacherGateTimer);
  if(e.key === 'Enter'){
    const code = teacherGateInput.trim();
    teacherGateInput = '';
    if(code) teacherHandleScan(code);
    return;
  }
  if(e.key.length === 1) teacherGateInput += e.key;
  teacherGateTimer = setTimeout(()=>{
    const code = teacherGateInput.trim();
    teacherGateInput = '';
    if(code.length >= 4) teacherHandleScan(code);
  }, 300);
}

function teacherHandleScan(cardId){
  const teachers = DB.teachers || [];
  const t = teachers.find(t => (t.cardId||'').trim() === cardId.trim() && (t.cardId||'').trim() !== '');
  if(!t){
    teacherShowStatus('error', `❌ Unknown card: ${cardId}`, '#f44336');
    return;
  }
  teacherRecordAttendance(t);
}

function teacherRecordAttendance(t){
  const today = teacherToday();
  const nowTime = teacherNowTime();
  const attendance = t.attendance ? [...t.attendance] : [];
  const idx = attendance.findIndex(a => a.date === today);

  if(idx === -1){
    // First scan = Check In
    attendance.push({ date: today, timeIn: nowTime, timeOut: null });
    t.attendance = attendance;
    teacherShowStatus('ok',
      `<b style="font-size:18px;">${t.name}</b><br>
       <span style="color:var(--ink-soft); font-size:13px;">${t.subject||''}</span><br>
       <span style="color:#4caf50; font-size:20px; font-weight:700; margin-top:8px; display:block;">🟢 Checked In</span>
       <span style="font-size:15px;">Time: ${nowTime}</span>`, '#4caf50');
  } else if(!attendance[idx].timeOut){
    // Second scan = Check Out
    attendance[idx].timeOut = nowTime;
    t.attendance = attendance;
    const dur = calcDuration(attendance[idx].timeIn, nowTime);
    teacherShowStatus('out',
      `<b style="font-size:18px;">${t.name}</b><br>
       <span style="color:var(--ink-soft); font-size:13px;">${t.subject||''}</span><br>
       <span style="color:#f44336; font-size:20px; font-weight:700; margin-top:8px; display:block;">🔴 Checked Out</span>
       <span style="font-size:15px;">Time: ${nowTime} &nbsp;|&nbsp; Duration: ${dur}</span>`, '#f44336');
  } else {
    // Already checked out
    teacherShowStatus('dup',
      `<b>${t.name}</b> already checked out today at ${attendance[idx].timeOut}`, '#ff9800');
    return;
  }

  // Save to the server
  if(sb){
    sb.from('teachers').update({ attendance: t.attendance }).eq('username', t.username)
      .then(({error}) => { if(error) console.error('Teacher attendance save error:', error); });
  }

  // Refresh page after 2.5s
  setTimeout(() => { teacherViewMode='day'; teacherViewDate=teacherToday(); renderPage(); teacherGateStartFocus(); }, 2500);
}

function teacherShowStatus(type, html, color='#00BFA5'){
  const el = document.getElementById('teacherGateStatus');
  if(!el) return;
  el.innerHTML = `<div style="text-align:center; padding:10px; border:2px solid ${color}; border-radius:12px; background:${color}15; width:100%; line-height:1.6;">${html}</div>`;
}

function teacherManualCheckIn(){
  const sel = document.getElementById('manualTeacherSel');
  if(!sel || !sel.value) { alert('Please select a teacher'); return; }
  const t = (DB.teachers||[]).find(t => t.username === sel.value);
  if(t) teacherRecordAttendance(t);
}

function teacherManualCheckOut(){
  const sel = document.getElementById('manualTeacherSel');
  if(!sel || !sel.value) { alert('Please select a teacher'); return; }
  const t = (DB.teachers||[]).find(t => t.username === sel.value);
  if(!t) return;
  const today = teacherToday();
  const attendance = t.attendance ? [...t.attendance] : [];
  const idx = attendance.findIndex(a => a.date === today);
  if(idx === -1){ alert(t.name + ' has not checked in today.'); return; }
  if(attendance[idx].timeOut){ alert(t.name + ' already checked out at ' + attendance[idx].timeOut); return; }
  const nowTime = teacherNowTime();
  attendance[idx].timeOut = nowTime;
  t.attendance = attendance;
  const dur = calcDuration(attendance[idx].timeIn, nowTime);
  alert(t.name + ' checked out at ' + nowTime + ' | Duration: ' + dur);
  if(sb){
    sb.from('teachers').update({ attendance: t.attendance }).eq('username', t.username)
      .then(({error}) => { if(error) console.error(error); else renderPage(); });
  } else { renderPage(); }
}

function prettyDate(d){
  if(!d) return '–';
  try { return new Date(d+'T00:00:00').toLocaleDateString('en-US',{weekday:'short', month:'short', day:'numeric', year:'numeric'}); }
  catch(e){ return d; }
}
function durationMinutes(timeIn, timeOut){
  try{
    const a = new Date('2000-01-01T'+convertTo24(timeIn));
    const b = new Date('2000-01-01T'+convertTo24(timeOut));
    const m = Math.floor((b-a)/60000);
    return m > 0 ? m : 0;
  }catch(e){ return 0; }
}
function fmtMins(m){
  if(!m) return '0m';
  const h = Math.floor(m/60), r = m%60;
  return h ? h+'h '+r+'m' : r+'m';
}
function teacherSetDate(d){
  if(!d) return;
  teacherViewDate = d; teacherViewMode = 'day';
  renderPage(); teacherGateStartFocus();
}
function teacherShiftDay(n){
  const d = new Date(teacherViewDate+'T00:00:00');
  d.setDate(d.getDate()+n);
  const iso = d.toISOString().slice(0,10);
  if(iso > teacherToday()) return;
  teacherSetDate(iso);
}
function teacherUseRange(){
  teacherViewMode = 'range';
  if(!teacherRangeTo)   teacherRangeTo   = teacherToday();
  if(!teacherRangeFrom){
    const d = new Date(); d.setDate(d.getDate()-6);
    teacherRangeFrom = d.toISOString().slice(0,10);
  }
  renderPage(); teacherGateStartFocus();
}
function teacherUseDay(){
  teacherViewMode = 'day';
  renderPage(); teacherGateStartFocus();
}
function teacherSetRange(which, val){
  if(which === 'from') teacherRangeFrom = val; else teacherRangeTo = val;
  renderPage(); teacherGateStartFocus();
}
function exportTeacherRecord(){
  const teachers = DB.teachers || [];
  const inRange = d => teacherViewMode === 'range'
    ? (!teacherRangeFrom || d >= teacherRangeFrom) && (!teacherRangeTo || d <= teacherRangeTo)
    : d === teacherViewDate;
  const rows = [['Date','Name','Subject','Phone','Time In','Time Out','Duration','Status']];
  const all = [];
  teachers.forEach(t => (t.attendance||[]).forEach(rec => {
    if(rec && rec.date && inRange(rec.date)) all.push({t, rec});
  }));
  all.sort((a,b) => a.rec.date === b.rec.date
    ? (a.rec.timeIn||'').localeCompare(b.rec.timeIn||'')
    : a.rec.date.localeCompare(b.rec.date));
  all.forEach(({t, rec}) => {
    const dur = rec.timeIn && rec.timeOut ? calcDuration(rec.timeIn, rec.timeOut) : '';
    rows.push([rec.date, t.name, t.subject||'', t.phone||'',
               rec.timeIn||'', rec.timeOut||'', dur,
               rec.timeOut ? 'Checked Out' : 'Checked In']);
  });
  if(rows.length === 1){ alert('Nothing to export for this selection.'); return; }
  const csv = rows.map(r => r.map(v => '"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n');
  const blob = new Blob([csv], {type:'text/csv'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = teacherViewMode === 'range'
    ? 'teacher_attendance_'+teacherRangeFrom+'_to_'+teacherRangeTo+'.csv'
    : 'teacher_attendance_'+teacherViewDate+'.csv';
  a.click();
}


/* ===================== REPORTS ===================== */
function renderReports(){
  const students = DB.students || [];
  const today = new Date().toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});

  // Class-wise breakdown
  const classMap = {};
  students.forEach(s => {
    if(!classMap[s.class]) classMap[s.class] = { total:0, collected:0, due:0 };
    classMap[s.class].total++;
    (s.fees||[]).forEach(f => {
      if(f.status==='Paid') classMap[s.class].collected += Number(f.amount||0);
      else classMap[s.class].due += Number(f.amount||0);
    });
  });

  const classOrder = ['Play Group','Nursery','Prep','Class 1','Class 2','Class 3','Class 4','Class 5','Class 6','Class 7','Class 8','Class 9','Class 10','First Year'];
  const sortedClasses = classOrder.filter(c => classMap[c]);

  const totalStudents = students.length;
  const totalCollected = students.reduce((sum,s)=>sum+feeCollectedFor(s),0);
  const totalDueAll = students.reduce((sum,s)=>sum+totalDue(s),0);

  function feeCollectedFor(s){ return (s.fees||[]).filter(f=>f.status==='Paid').reduce((sum,f)=>sum+Number(f.amount||0),0); }

  // Class rows
  const classRows = sortedClasses.map((cls,i) => {
    const d = classMap[cls];
    const pct = d.collected+d.due > 0 ? Math.round((d.collected/(d.collected+d.due))*100) : 0;
    return `<tr class="ledger-row">
      <td data-label="#"><b>${i+1}</b></td>
      <td data-label="Class"><b>${cls}</b></td>
      <td data-label="Students">${d.total}</td>
      <td data-label="Collected"><span style="color:var(--ok-ink); font-weight:600;">Rs. ${fmtMoney(d.collected)}</span></td>
      <td data-label="Due"><span style="color:var(--due-ink); font-weight:600;">Rs. ${fmtMoney(d.due)}</span></td>
      <td data-label="Recovery">
        <div style="display:flex; align-items:center; gap:8px;">
          <div style="flex:1; height:8px; background:var(--line); border-radius:4px;">
            <div style="width:${pct}%; height:8px; background:var(--ok-ink); border-radius:4px;"></div>
          </div>
          <span style="font-size:12px; min-width:32px;">${pct}%</span>
        </div>
      </td>
    </tr>`;
  }).join('');

  // Length-wise report (fee amount groups)
  const lengthMap = {};
  students.forEach(s => {
    const fa = Number(s.feeAmount||0);
    const key = fa > 0 ? 'Rs. '+fa+'/mo' : 'No Fee';
    if(!lengthMap[key]) lengthMap[key] = 0;
    lengthMap[key]++;
  });
  const lengthRows = Object.entries(lengthMap).sort((a,b)=>b[1]-a[1]).map(([fee,count]) =>
    `<tr class="ledger-row"><td data-label="Fee">${fee}</td><td data-label="Students">${count}</td>
     <td data-label="%">${Math.round((count/totalStudents)*100)}%</td></tr>`
  ).join('');

  // Fee status summary
  const paidAll = students.filter(s=>(s.fees||[]).every(f=>f.status==='Paid')||(s.fees||[]).length===0).length;
  const dueAll = totalStudents - paidAll;

  return `
  <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:20px;">
    <div>
      <h2 style="margin:0; font-family:var(--font-head);">📋 School Reports</h2>
      <p style="color:var(--ink-soft); font-size:13px; margin:4px 0 0;">${today}</p>
    </div>
    <button class="btn gold" onclick="exportFullReport()">⬇️ Export to CSV</button>
  </div>

  <!-- Summary Cards -->
  <div class="grid-cards" style="margin-bottom:24px;">
    <div class="stat"><div class="label">Total Students</div><div class="value">${totalStudents}</div></div>
    <div class="stat ok"><div class="label">Fee Collected</div><div class="value">${fmtMoney(totalCollected)}</div></div>
    <div class="stat due"><div class="label">Fee Due</div><div class="value">${fmtMoney(totalDueAll)}</div></div>
    <div class="stat ok"><div class="label">Fully Paid</div><div class="value">${paidAll}</div></div>
    <div class="stat due"><div class="label">Have Due</div><div class="value">${dueAll}</div></div>
  </div>

  <!-- Class-wise Report -->
  <div class="card" style="margin-bottom:20px;">
    <h3 style="margin:0 0 16px;">📊 Class-wise Report</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>#</th><th>Class</th><th>Students</th><th>Collected</th><th>Due</th><th>Recovery</th></tr></thead>
        <tbody>${classRows}</tbody>
        <tfoot><tr style="font-weight:700; background:var(--bg);">
          <td colspan="2"><b>TOTAL</b></td>
          <td>${totalStudents}</td>
          <td style="color:var(--ok-ink);">Rs. ${fmtMoney(totalCollected)}</td>
          <td style="color:var(--due-ink);">Rs. ${fmtMoney(totalDueAll)}</td>
          <td></td>
        </tr></tfoot>
      </table>
    </div>
  </div>

  <!-- Length-wise Report -->
  <div class="card">
    <h3 style="margin:0 0 16px;">📏 Fee Amount Distribution</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Monthly Fee</th><th>Students</th><th>Percentage</th></tr></thead>
        <tbody>${lengthRows}</tbody>
      </table>
    </div>
  </div>`;
}

function exportFullReport(){
  const students = DB.students || [];
  const classOrder = ['Play Group','Nursery','Prep','Class 1','Class 2','Class 3','Class 4','Class 5','Class 6','Class 7','Class 8','Class 9','Class 10','First Year'];
  const sorted = [...students].sort((a,b)=>{
    const ai = classOrder.indexOf(a.class), bi = classOrder.indexOf(b.class);
    return ai !== bi ? ai-bi : a.name.localeCompare(b.name);
  });
  const rows = [['Roll','Name','Class','Father','Phone','Fee/Month','Collected','Due','Fee Status']];
  sorted.forEach(s => {
    const collected = (s.fees||[]).filter(f=>f.status==='Paid').reduce((sum,f)=>sum+Number(f.amount||0),0);
    const due = (s.fees||[]).filter(f=>f.status==='Due').reduce((sum,f)=>sum+Number(f.amount||0),0);
    rows.push([s.roll,s.name,s.class,s.father||'',s.phone||'',s.feeAmount||0,collected,due,due>0?'Due':'Paid']);
  });
  const csv = rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n');
  const blob = new Blob([csv],{type:'text/csv'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'imsgc_report_'+new Date().toISOString().slice(0,10)+'.csv';
  a.click();
}


function previewReceipt(input){
  if(input.files && input.files[0]){
    const file = input.files[0];
    document.getElementById('adm_receipt_gallery').value = '';
    showReceiptPreview(file);
  }
}
function previewReceiptGallery(input){
  if(input.files && input.files[0]){
    const file = input.files[0];
    document.getElementById('adm_receipt').value = '';
    showReceiptPreview(file);
  }
}
function showReceiptPreview(file){
  const preview = document.getElementById('receipt_preview');
  const img = document.getElementById('receipt_preview_img');
  const name = document.getElementById('receipt_preview_name');
  if(!preview) return;
  name.textContent = file.name + ' (' + (file.size/1024).toFixed(1) + ' KB)';
  if(file.type.startsWith('image/')){
    const reader = new FileReader();
    reader.onload = e => { img.src = e.target.result; preview.style.display='block'; };
    reader.readAsDataURL(file);
  } else {
    img.style.display='none';
    preview.style.display='block';
  }
}


function setTeacherCard(username){
  const t = (DB.teachers||[]).find(t=>t.username===username);
  if(!t) return;
  const val = prompt('Tap the RFID card on the reader now, or type the card ID:', t.cardId||'');
  if(val===null) return;
  const card_id = val.trim();
  t.cardId = card_id;
  if(sb){
    sb.from('teachers').update({ card_id }).eq('username', username).then(({error})=>{
      if(error){ console.error(error); alert('Could not save card: '+error.message); return; }
      alert('RFID card saved for '+t.name);
      renderPage();
    });
  } else { renderPage(); }
}


/* ===== Phone "More" sheet ===== */
let moreNavItems = [];
function ensureMoreSheet(){
  if(document.getElementById('moreSheet')) return;
  const ov = document.createElement('div');
  ov.className='sheet-ov'; ov.id='moreSheetOv'; ov.onclick=closeMoreSheet;
  const sh = document.createElement('div');
  sh.className='sheet'; sh.id='moreSheet';
  document.body.appendChild(ov); document.body.appendChild(sh);
}
function openMoreSheet(){
  ensureMoreSheet();
  const SHORT_ICON = k => (typeof NAV_ICONS!=='undefined' && NAV_ICONS[k]) || '\u2022';
  const sh = document.getElementById('moreSheet');
  sh.innerHTML =
    '<div class="sheet-grab"></div>' +
    '<div class="sheet-grid">' +
    moreNavItems.map(function(it){
      return '<div class="sheet-tile '+(currentTab===it[0]?'active':'')+'" onclick="goTabFromSheet(\''+it[0]+'\')">'
           + '<div class="sheet-ico">'+SHORT_ICON(it[0])+'</div>'
           + '<div class="sheet-lbl">'+it[1]+'</div></div>';
    }).join('') +
    '</div>' +
    '<button class="sheet-out" onclick="closeMoreSheet(); logout();">Log out</button>';
  document.getElementById('moreSheetOv').classList.add('show');
  requestAnimationFrame(function(){ sh.classList.add('show'); });
}
function closeMoreSheet(){
  const sh=document.getElementById('moreSheet'), ov=document.getElementById('moreSheetOv');
  if(sh) sh.classList.remove('show');
  if(ov) ov.classList.remove('show');
}
function goTabFromSheet(k){ closeMoreSheet(); goTab(k); }


/* ===== Notification badge (unread announcements) ===== */
function announceSeenKey(){
  const who = (SESSION && (SESSION.roll || SESSION.username || SESSION.role)) || 'guest';
  return 'ims_seen_ann_' + who;
}
function unreadAnnouncements(){
  if(typeof announcementsCache === 'undefined' || !announcementsCache) return 0;
  let list = announcementsCache;
  if(SESSION && SESSION.role === 'student' && typeof announceVisibleToStudent === 'function'){
    list = list.filter(announceVisibleToStudent);
  }
  let seen = 0;
  try { seen = Number(localStorage.getItem(announceSeenKey()) || 0); } catch(e){}
  return list.filter(a => {
    const t = new Date(a.created_at || 0).getTime();
    return t > seen;
  }).length;
}
function refreshBell(){
  const dot = document.getElementById('bellDot');
  if(!dot) return;
  const n = unreadAnnouncements();
  if(n > 0){ dot.textContent = n > 9 ? '9+' : String(n); dot.classList.remove('section-hidden'); }
  else { dot.classList.add('section-hidden'); }
}
function markAnnouncementsSeen(){
  try { localStorage.setItem(announceSeenKey(), String(Date.now())); } catch(e){}
  refreshBell();
}


/* ===== Ask students to replace the default (roll number) password ===== */
function usingDefaultPassword(){
  // The server works this out at sign-in; the password itself never reaches us.
  return !!(SESSION && SESSION.role === 'student' && SESSION.defaultPassword);
}

function openPasswordPrompt(force){ maybeAskPasswordChange(force); }
function maybeAskPasswordChange(force){
  // A password that is still the roll number is not optional to change — the
  // server refuses to serve anything until it is changed, so there is no
  // "Not now" to offer here either.
  force = force || usingDefaultPassword();
  if(!force) return;
  const s = DB.myStudent || getStudent(SESSION.roll);
  let ov = document.getElementById('pwPromptOv');
  if(!ov){
    ov = document.createElement('div');
    ov.className = 'pwp-ov'; ov.id = 'pwPromptOv';
    document.body.appendChild(ov);
  }
  ov.innerHTML = `
    <div class="pwp" role="dialog" aria-modal="true">
      <h3>\u{1F510} Please change your password</h3>
      <div style="font-size:13.5px; color:var(--ink-soft);">Welcome, ${s.name}</div>
      <div class="pwp-why">
        Your password is still your roll number, <b>${s.roll}</b>.
        Anyone who knows your roll number can open your portal and see your
        fees, attendance and results. Set a password only you know.
      </div>
      <label>New password</label>
      <input id="pwp_new" type="password" autocomplete="new-password" placeholder="At least 6 characters">
      <label>Confirm new password</label>
      <input id="pwp_confirm" type="password" autocomplete="new-password" placeholder="Type it again">
      <div class="pwp-err" id="pwp_err"></div>
      <div class="pwp-actions">
        <button class="btn gold" onclick="savePromptedPassword()">Change Password</button>
        ${force ? '' : '<button class="btn pwp-later" onclick="skipPasswordPrompt()">Not now</button>'}
      </div>
    </div>`;
  ov.classList.add('show');
  setTimeout(()=>{ const el=document.getElementById('pwp_new'); if(el) el.focus(); }, 120);
}

function closePasswordPrompt(){
  const ov = document.getElementById('pwPromptOv');
  if(ov) ov.classList.remove('show');
}

function skipPasswordPrompt(){
  try{ sessionStorage.setItem('imsgc_pw_prompt_skipped','1'); }catch(e){}
  closePasswordPrompt();
}

async function savePromptedPassword(){
  const err  = document.getElementById('pwp_err');
  const next = document.getElementById('pwp_new').value;
  const conf = document.getElementById('pwp_confirm').value;
  const s = DB.myStudent || getStudent(SESSION.roll);
  err.textContent = '';
  if(!next || !conf){ err.textContent = 'Please fill in both boxes.'; return; }
  if(next !== conf){ err.textContent = 'The two passwords do not match.'; return; }
  if(next.length < 6){ err.textContent = 'Use at least 6 characters.'; return; }
  if(next.trim() === String(s.roll).trim()){ err.textContent = 'That is your roll number again \u2014 please pick something else.'; return; }
  try{
    // Their current password is still the roll number at this point.
    const r = await apiChangePassword(String(s.roll), next);
    if(!r.ok){ err.textContent = r.error.message; return; }
    if(SESSION) SESSION.defaultPassword = false;
    saveSession({ defaultPassword:false });
    closePasswordPrompt();
    alert('Password changed. Use your new password next time you sign in.');
    renderPage();
  }catch(e){
    console.error(e);
    err.textContent = 'Could not save: ' + (e.message || 'please try again.');
  }
}
