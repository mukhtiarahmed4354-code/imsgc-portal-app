package pk.imsgc.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.KeyEvent;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.JavascriptInterface;

import com.google.firebase.messaging.FirebaseMessaging;

import java.io.File;

public class MainActivity extends Activity {

    private static final String PORTAL_URL = "https://inspiredpk.com/";
    private static final int FILE_CHOOSER_REQUEST = 1001;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraImageUri;
    private String pushToken;
    private boolean pageReady;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!isConnected()) {
            showNoInternet();
            return;
        }

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setGeolocationEnabled(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("https://inspiredpk.com") ||
                    url.startsWith("https://inspiredmodelschool.netlify.app") ||
                    url.startsWith("https://xifnnabwzhnltmqrptgy.supabase.co")) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                pushTokenToPage();
            }
        });

        // Lets the portal read this phone's push token (for notifications).
        webView.addJavascriptInterface(new PushBridge(), "IMSNative");

        // Without this handler, <input type="file"> does nothing inside a WebView.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                                             ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                // cancel any chooser still pending
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                cameraImageUri = null;

                boolean wantsImage = acceptsImages(params);

                // "Take Photo" button (capture="environment") -> open the camera directly
                if (wantsImage && params.isCaptureEnabled()) {
                    Intent cam = buildCameraIntent();
                    if (cam != null && launch(cam)) return true;
                }

                // "Choose from Gallery" / any other upload -> file picker,
                // with the camera offered as an extra option for images
                Intent content;
                try {
                    content = params.createIntent();
                } catch (Exception e) {
                    content = new Intent(Intent.ACTION_GET_CONTENT);
                    content.addCategory(Intent.CATEGORY_OPENABLE);
                    content.setType("*/*");
                }

                Intent chooser = Intent.createChooser(content, "Choose file");
                if (wantsImage) {
                    Intent cam = buildCameraIntent();
                    if (cam != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{ cam });
                }

                if (launch(chooser)) return true;

                filePathCallback = null;
                return false;
            }
        });

        // Ask for notification permission on Android 13+.
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{ Manifest.permission.POST_NOTIFICATIONS }, 2001);
            }
        }

        // Fetch this device's Firebase push token, then hand it to the portal.
        try {
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult() != null) {
                    pushToken = task.getResult();
                    pushTokenToPage();
                }
            });
        } catch (Exception ignored) { }

        webView.loadUrl(PORTAL_URL);
    }

    // Pushes the token into the page so the portal can register it after login.
    private void pushTokenToPage() {
        if (webView == null || !pageReady || pushToken == null) return;
        final String t = pushToken.replace("\\", "\\\\").replace("'", "\\'");
        webView.post(() -> webView.evaluateJavascript(
                "window.__imsOnToken && window.__imsOnToken('" + t + "');", null));
    }

    // Exposed to the portal as window.IMSNative.getPushToken()
    public class PushBridge {
        @JavascriptInterface
        public String getPushToken() {
            if (pushToken != null) return pushToken;
            try {
                return getSharedPreferences("ims", MODE_PRIVATE).getString("push_token", "");
            } catch (Exception e) { return ""; }
        }
    }

    private boolean acceptsImages(WebChromeClient.FileChooserParams params) {
        String[] types = params.getAcceptTypes();
        if (types == null || types.length == 0) return true;
        for (String t : types) {
            if (t == null || t.trim().isEmpty()) return true;
            String s = t.toLowerCase();
            if (s.contains("image") || s.contains(".jpg") || s.contains(".jpeg") || s.contains(".png")) return true;
        }
        return false;
    }

    private Intent buildCameraIntent() {
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists()) dir.mkdirs();
            File photo = File.createTempFile("receipt_", ".jpg", dir);
            cameraImageUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri);
            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return cam;
        } catch (Exception e) {
            cameraImageUri = null;
            return null;
        }
    }

    private boolean launch(Intent intent) {
        try {
            startActivityForResult(intent, FILE_CHOOSER_REQUEST);
            return true;
        } catch (ActivityNotFoundException e) {
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != FILE_CHOOSER_REQUEST) {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }
        if (filePathCallback == null) return;

        Uri[] results = null;
        if (resultCode == RESULT_OK) {
            boolean pickedFile = data != null && (data.getData() != null || data.getClipData() != null);
            if (pickedFile) {
                results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            } else if (cameraImageUri != null) {
                results = new Uri[]{ cameraImageUri };   // photo taken with the camera
            }
        }
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
        cameraImageUri = null;
    }

    private boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm != null ? cm.getActiveNetworkInfo() : null;
        return info != null && info.isConnected();
    }

    private void showNoInternet() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(Color.parseColor("#0F1923"));
        layout.setPadding(60, 60, 60, 60);

        TextView emoji = new TextView(this);
        emoji.setText("\uD83D\uDCE1");
        emoji.setTextSize(64);
        emoji.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText("No Internet Connection");
        title.setTextSize(22);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 20, 0, 10);

        TextView msg = new TextView(this);
        msg.setText("Please connect to the internet to use the Inspired Model School portal.");
        msg.setTextSize(15);
        msg.setTextColor(Color.parseColor("#9AA0A6"));
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0, 0, 0, 30);

        Button retry = new Button(this);
        retry.setText("Retry");
        retry.setBackgroundColor(Color.parseColor("#00BFA5"));
        retry.setTextColor(Color.WHITE);
        retry.setTextSize(16);
        retry.setOnClickListener(v -> {
            finish();
            startActivity(getIntent());
        });

        layout.addView(emoji);
        layout.addView(title);
        layout.addView(msg);
        layout.addView(retry);
        setContentView(layout);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) webView.onPause();
    }
}
